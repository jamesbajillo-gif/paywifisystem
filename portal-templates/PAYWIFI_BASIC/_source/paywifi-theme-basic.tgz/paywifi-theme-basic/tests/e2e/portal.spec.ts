import { test, expect } from "@playwright/test";

/**
 * Visits every portal route and asserts the brief's two layout rules:
 *
 *   1) No horizontal overflow at the tested viewport.
 *   2) Vertical fit — content fits in one screen (with a small slack
 *      for browser chrome / sub-pixel rounding).
 *
 * Routes that need search params get them inline so each page renders
 * something meaningful instead of redirecting.
 *
 * The first-attempt-fail simulation in `portal-api.ts` is disabled for
 * the test suite (via the addInitScript below) so `/validate` lands on
 * the valid state deterministically.
 */
const ROUTES: { name: string; path: string }[] = [
  { name: "index",     path: "/" },
  { name: "plans",     path: "/plans" },
  { name: "checkout",  path: "/checkout?plan=day" },
  // `V`-prefix test code → synthetic "valid" voucher per validateVoucher's
  // test prefixes. ABCD1234 used to work via the default-valid fallback;
  // that's been removed now so PAYMENT REFERENCEs can't masquerade as
  // vouchers. Test prefixes are the only path that bypasses the store.
  { name: "validate",  path: "/validate?code=VTEST-CODE-1234" },
  { name: "result",    path: "/result?status=success&code=ABCD1234&phone=09171234567" },
  { name: "result-pending", path: "/result?status=pending&code=ABCD1234&planId=day&price=4.99" },
  { name: "admin",     path: "/admin" },
];

/**
 * Slack allowed on the vertical-fit check. Browser chrome (scrollbars,
 * sub-pixel layout) can push scrollHeight a few pixels past innerHeight
 * even when content visually fits. 12 px keeps the rule meaningful
 * without thrashing on rounding noise.
 */
const VERTICAL_SLACK = 12;

test.beforeEach(async ({ page }) => {
  // Pre-set the first-attempt sessionStorage flags so validateVoucher and
  // processPayment don't force a failure on their first call during tests.
  // This keeps `/validate?code=ABCD1234` deterministically on the valid path.
  await page.addInitScript(() => {
    try {
      window.sessionStorage.setItem("paywifi:dev:voucher_attempted", "1");
      window.sessionStorage.setItem("paywifi:dev:payment_attempted", "1");
    } catch {
      /* private mode — accept whatever the mock returns */
    }
  });
});

for (const route of ROUTES) {
  test(`${route.name} — layout fits & screenshot`, async ({ page }, testInfo) => {
    await page.goto(route.path, { waitUntil: "networkidle" });

    // Allow async UI (e.g. /validate mock 1.2s, /plans 300ms) to settle.
    await page.waitForTimeout(1700);

    const fit = await page.evaluate(() => {
      const html = document.documentElement;
      const body = document.body;
      return {
        scrollWidth: Math.max(html.scrollWidth, body.scrollWidth),
        scrollHeight: Math.max(html.scrollHeight, body.scrollHeight),
        clientWidth: Math.min(html.clientWidth, window.innerWidth),
        innerHeight: window.innerHeight,
      };
    });

    const horizontalDiff = fit.scrollWidth - fit.clientWidth;
    const verticalDiff = fit.scrollHeight - fit.innerHeight;

    expect
      .soft(
        horizontalDiff,
        `Horizontal overflow on ${route.path} — scrollWidth ${fit.scrollWidth} > clientWidth ${fit.clientWidth}`,
      )
      .toBeLessThanOrEqual(1);

    expect
      .soft(
        verticalDiff,
        `Vertical overflow on ${route.path} — scrollHeight ${fit.scrollHeight} > innerHeight ${fit.innerHeight} (slack ${VERTICAL_SLACK}px)`,
      )
      .toBeLessThanOrEqual(VERTICAL_SLACK);

    await page.screenshot({
      path: testInfo.outputPath(`${route.name}.png`),
      fullPage: true,
    });
  });
}
