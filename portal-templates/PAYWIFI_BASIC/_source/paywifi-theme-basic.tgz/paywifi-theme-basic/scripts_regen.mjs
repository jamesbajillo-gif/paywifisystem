import { generator } from "@tanstack/router-generator";
await generator({
  routesDirectory: "./src/routes",
  generatedRouteTree: "./src/routeTree.gen.ts",
});
console.log("regen done");
