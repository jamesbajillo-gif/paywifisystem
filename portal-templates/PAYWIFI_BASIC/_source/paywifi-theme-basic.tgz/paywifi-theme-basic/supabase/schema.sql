-- ============================================================
-- paywifi_basic Supabase schema
-- Run this in: Supabase SQL editor or via psql
-- All tables prefixed with paywifi_basic_
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ────────────────────────────────────────────────────────────
-- VOUCHERS  (shared/global across all captive portal instances)
-- Reads: NO system_id filter — vouchers are shared globally.
-- Writes: system_id stored for audit trail only.
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS paywifi_basic_vouchers (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  system_id          TEXT NOT NULL,          -- audit: which portal issued this
  code               TEXT NOT NULL DEFAULT '', -- the redeemable WiFi code
  payment_reference  TEXT,                  -- cashier lookup ID (cash only)
  plan_id            TEXT NOT NULL,
  issued_at          BIGINT NOT NULL,        -- epoch ms
  redeemed_at        BIGINT,
  voided_at          BIGINT,
  confirmed_at       BIGINT,                -- cash: when cashier confirmed
  expires_at         BIGINT,                -- pending cash TTL
  duration_minutes   INTEGER NOT NULL,
  transaction_id     TEXT,
  phone              TEXT,
  venue              TEXT NOT NULL DEFAULT 'default',
  store_id           TEXT,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Global lookup indices (no system_id filter on reads)
CREATE INDEX IF NOT EXISTS idx_paywifi_basic_vouchers_code
  ON paywifi_basic_vouchers (code) WHERE code != '';
CREATE INDEX IF NOT EXISTS idx_paywifi_basic_vouchers_ref
  ON paywifi_basic_vouchers (payment_reference) WHERE payment_reference IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_paywifi_basic_vouchers_venue
  ON paywifi_basic_vouchers (venue, issued_at DESC);
CREATE INDEX IF NOT EXISTS idx_paywifi_basic_vouchers_system
  ON paywifi_basic_vouchers (system_id, issued_at DESC);

-- ────────────────────────────────────────────────────────────
-- PHONE EDIT LOG  (per-system)
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS paywifi_basic_phone_edit_logs (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  system_id         TEXT NOT NULL,
  payment_reference TEXT NOT NULL,
  edits             BIGINT[] NOT NULL DEFAULT '{}',
  last_edit_at      BIGINT NOT NULL DEFAULT 0,
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (system_id, payment_reference)
);

-- ────────────────────────────────────────────────────────────
-- PLANS  (per-system; seeded from defaults on first boot)
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS paywifi_basic_plans (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  system_id        TEXT NOT NULL,
  plan_id          TEXT NOT NULL,       -- "hour" | "day" | "week" | custom
  name             TEXT NOT NULL,
  description      TEXT NOT NULL DEFAULT '',
  duration         TEXT NOT NULL,
  duration_minutes INTEGER NOT NULL,
  speed            TEXT,
  price            NUMERIC(10,2) NOT NULL,
  epayment_fee     NUMERIC(10,2),
  popular          BOOLEAN NOT NULL DEFAULT FALSE,
  sort_order       INTEGER NOT NULL DEFAULT 0,
  active           BOOLEAN NOT NULL DEFAULT TRUE,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (system_id, plan_id)
);

CREATE INDEX IF NOT EXISTS idx_paywifi_basic_plans_system
  ON paywifi_basic_plans (system_id, sort_order);

-- ────────────────────────────────────────────────────────────
-- STORES  (per-system)
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS paywifi_basic_stores (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  system_id  TEXT NOT NULL,
  store_id   TEXT NOT NULL,
  name       TEXT NOT NULL,
  active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (system_id, store_id)
);

CREATE INDEX IF NOT EXISTS idx_paywifi_basic_stores_system
  ON paywifi_basic_stores (system_id);

-- ────────────────────────────────────────────────────────────
-- XENDIT CONFIG  (per-system)
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS paywifi_basic_xendit_config (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  system_id       TEXT NOT NULL UNIQUE,
  enabled         BOOLEAN NOT NULL DEFAULT TRUE,
  active_channel  TEXT,
  api_key         TEXT NOT NULL DEFAULT '',
  webhook_token   TEXT NOT NULL DEFAULT '',
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ────────────────────────────────────────────────────────────
-- ANALYTICS EVENTS  (per-system)
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS paywifi_basic_analytics_events (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  system_id  TEXT NOT NULL,
  name       TEXT NOT NULL,
  venue      TEXT NOT NULL DEFAULT 'default',
  props      JSONB NOT NULL DEFAULT '{}',
  at         BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_paywifi_basic_analytics_system
  ON paywifi_basic_analytics_events (system_id, at DESC);
CREATE INDEX IF NOT EXISTS idx_paywifi_basic_analytics_name
  ON paywifi_basic_analytics_events (system_id, name, at DESC);

-- ────────────────────────────────────────────────────────────
-- OPERATOR CREDITS  (per-system)
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS paywifi_basic_credits (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  system_id        TEXT NOT NULL UNIQUE,
  balance          INTEGER NOT NULL DEFAULT 500,
  total_purchased  INTEGER NOT NULL DEFAULT 500,
  total_consumed   INTEGER NOT NULL DEFAULT 0,
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS paywifi_basic_credit_reloads (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  system_id       TEXT NOT NULL,
  package_id      TEXT NOT NULL,
  credits         INTEGER NOT NULL,
  price           NUMERIC(10,2) NOT NULL,
  method          TEXT NOT NULL DEFAULT 'gcash',
  status          TEXT NOT NULL DEFAULT 'pending',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  confirmed_at    TIMESTAMPTZ,
  transaction_ref TEXT
);

CREATE INDEX IF NOT EXISTS idx_paywifi_basic_credit_reloads_system
  ON paywifi_basic_credit_reloads (system_id, created_at DESC);

-- ────────────────────────────────────────────────────────────
-- REFUNDS  (per-system)
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS paywifi_basic_refunds (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  system_id    TEXT NOT NULL,
  voucher_code TEXT NOT NULL,
  plan_id      TEXT NOT NULL,
  sale_amount  NUMERIC(10,2) NOT NULL,
  reason       TEXT NOT NULL,
  notes        TEXT,
  status       TEXT NOT NULL DEFAULT 'pending',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  resolved_at  TIMESTAMPTZ,
  resolved_by  TEXT
);

CREATE INDEX IF NOT EXISTS idx_paywifi_basic_refunds_system
  ON paywifi_basic_refunds (system_id, created_at DESC);

-- ────────────────────────────────────────────────────────────
-- REFUND CONFIG  (per-system)
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS paywifi_basic_refund_config (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  system_id    TEXT NOT NULL UNIQUE,
  auto_approve BOOLEAN NOT NULL DEFAULT TRUE,
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ────────────────────────────────────────────────────────────
-- PENDING DIGITAL PAYMENTS  (per-system; short TTL records)
-- ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS paywifi_basic_pending_digital (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  system_id      TEXT NOT NULL,
  transaction_id TEXT NOT NULL,
  plan_id        TEXT NOT NULL,
  method         TEXT NOT NULL,
  venue          TEXT NOT NULL,
  issued_at      BIGINT NOT NULL,
  expires_at     BIGINT NOT NULL,
  code           TEXT NOT NULL,
  UNIQUE (system_id, transaction_id)
);

CREATE INDEX IF NOT EXISTS idx_paywifi_basic_pending_digital_system
  ON paywifi_basic_pending_digital (system_id, expires_at);

-- ────────────────────────────────────────────────────────────
-- ROW LEVEL SECURITY (RLS)
-- Using anon key for reads, service role for writes.
-- Vouchers: everyone can read (shared global), writes require auth.
-- All other tables: system_id scoped.
-- ────────────────────────────────────────────────────────────

ALTER TABLE paywifi_basic_vouchers ENABLE ROW LEVEL SECURITY;
ALTER TABLE paywifi_basic_phone_edit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE paywifi_basic_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE paywifi_basic_stores ENABLE ROW LEVEL SECURITY;
ALTER TABLE paywifi_basic_xendit_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE paywifi_basic_analytics_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE paywifi_basic_credits ENABLE ROW LEVEL SECURITY;
ALTER TABLE paywifi_basic_credit_reloads ENABLE ROW LEVEL SECURITY;
ALTER TABLE paywifi_basic_refunds ENABLE ROW LEVEL SECURITY;
ALTER TABLE paywifi_basic_refund_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE paywifi_basic_pending_digital ENABLE ROW LEVEL SECURITY;

-- Vouchers: anon can SELECT (global shared), only service role can INSERT/UPDATE
CREATE POLICY "vouchers_select_all" ON paywifi_basic_vouchers
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "vouchers_insert_service" ON paywifi_basic_vouchers
  FOR INSERT TO service_role WITH CHECK (true);
CREATE POLICY "vouchers_update_service" ON paywifi_basic_vouchers
  FOR UPDATE TO service_role USING (true);

-- Plans: anon can SELECT own system
CREATE POLICY "plans_select_anon" ON paywifi_basic_plans
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "plans_write_service" ON paywifi_basic_plans
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- Stores: anon can SELECT
CREATE POLICY "stores_select_anon" ON paywifi_basic_stores
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "stores_write_service" ON paywifi_basic_stores
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- Analytics: insert from anon (client-side tracking), select from service_role
CREATE POLICY "analytics_insert_anon" ON paywifi_basic_analytics_events
  FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "analytics_select_service" ON paywifi_basic_analytics_events
  FOR SELECT TO anon, authenticated USING (true);

-- All other tables: service_role only
CREATE POLICY "phone_edit_service" ON paywifi_basic_phone_edit_logs
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE POLICY "xendit_config_service" ON paywifi_basic_xendit_config
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE POLICY "credits_service" ON paywifi_basic_credits
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE POLICY "credit_reloads_service" ON paywifi_basic_credit_reloads
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE POLICY "refunds_service" ON paywifi_basic_refunds
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE POLICY "refund_config_service" ON paywifi_basic_refund_config
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE POLICY "pending_digital_service" ON paywifi_basic_pending_digital
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- anon can read credits and refunds for display
CREATE POLICY "credits_select_anon" ON paywifi_basic_credits
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "credit_reloads_select_anon" ON paywifi_basic_credit_reloads
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "refunds_select_anon" ON paywifi_basic_refunds
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "refund_config_select_anon" ON paywifi_basic_refund_config
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "pending_digital_select_anon" ON paywifi_basic_pending_digital
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "xendit_config_select_anon" ON paywifi_basic_xendit_config
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "phone_edit_select_anon" ON paywifi_basic_phone_edit_logs
  FOR SELECT TO anon, authenticated USING (true);
