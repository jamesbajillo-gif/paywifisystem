import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { z } from "zod";
import {
  getPlans,
  updatePlan,
  deletePlan,
  addPlan,
  type Plan,
  type StoredPlan,
  type PlanId,
} from "@/lib/portal-api";
import { BRAND, useBrand } from "@/lib/brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatPHP } from "@/lib/utils";
import {
  ArrowLeft,
  Check,
  Trash2,
  AlertCircle,
  X,
  Plus,
} from "lucide-react";

// ─── Route ───────────────────────────────────────────────────────────────
const searchSchema = z.object({
  role: z.enum(["admin", "operator"]).catch("operator"),
});

export const Route = createFileRoute("/plan-edit/$planId")({
  head: () => ({ meta: [{ title: `Edit plan — ${BRAND}` }] }),
  validateSearch: searchSchema,
  component: PlanEditPage,
});

// ─── Helpers ─────────────────────────────────────────────────────────────
function slugify(name: string): string {
  return name.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 32);
}

function minutesToLabel(mins: number): string {
  if (mins < 60) return `${mins} min`;
  if (mins < 60 * 24) return `${mins / 60} hr`;
  if (mins < 60 * 24 * 7) { const d = mins / (60 * 24); return `${d} day${d !== 1 ? "s" : ""}`; }
  const w = mins / (60 * 24 * 7);
  return `${w} week${w !== 1 ? "s" : ""}`;
}

type FormState = {
  name: string;
  description: string;
  durationMinutes: string;
  price: string;
  speed: string;
  epaymentFee: string;
  popular: boolean;
};

const BLANK: FormState = {
  name: "", description: "", durationMinutes: "60",
  price: "", speed: "", epaymentFee: "", popular: false,
};

const DURATION_PRESETS = [
  { label: "30 min", minutes: 30 },
  { label: "1 hr",   minutes: 60 },
  { label: "3 hr",   minutes: 180 },
  { label: "6 hr",   minutes: 360 },
  { label: "12 hr",  minutes: 720 },
  { label: "1 day",  minutes: 1440 },
  { label: "3 days", minutes: 4320 },
  { label: "1 week", minutes: 10080 },
];

function Field({
  label, optional, error, hint, children,
}: {
  label: string; optional?: boolean; error?: string; hint?: string; children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1">
      <p className="text-sm font-semibold px-0.5">
        {label}
        {optional && <span className="ml-1 text-xs font-normal text-muted-foreground">(optional)</span>}
      </p>
      {children}
      {hint && !error && <p className="text-xs text-muted-foreground px-0.5">{hint}</p>}
      {error && <p className="text-xs font-semibold text-destructive px-0.5">{error}</p>}
    </div>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────
function PlanEditPage() {
  const brand = useBrand();
  const navigate = useNavigate();
  const { planId } = useParams({ from: "/plan-edit/$planId" });
  const { role } = Route.useSearch();
  const isNew = planId === "new";

  const [plans, setPlans] = useState<Plan[]>([]);
  const [plan, setPlan] = useState<Plan | null>(null);
  const [form, setForm] = useState<FormState>(BLANK);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [saved, setSaved] = useState(false);
  const nameRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    getPlans().then((all) => {
      setPlans(all);
      if (!isNew) {
        const found = all.find((p) => p.id === planId) ?? null;
        setPlan(found);
        if (found) {
          setForm({
            name: found.name,
            description: found.description ?? "",
            durationMinutes: String(found.durationMinutes),
            price: String(found.price),
            speed: found.speed ?? "",
            epaymentFee: found.epaymentFee != null ? String(found.epaymentFee) : "",
            popular: found.popular ?? false,
          });
        }
      }
    });
    setTimeout(() => nameRef.current?.focus(), 100);
  }, [planId, isNew]);

  const backTo = role === "admin" ? "/settings?role=admin" : "/settings?role=operator";

  function set<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: undefined }));
  }

  function validate(): boolean {
    const errs: Partial<Record<keyof FormState, string>> = {};
    if (!form.name.trim()) errs.name = "Name is required.";
    if (!form.description.trim()) errs.description = "Description is required.";
    const mins = parseInt(form.durationMinutes, 10);
    if (!mins || mins < 1) errs.durationMinutes = "Enter a valid duration.";
    const price = parseFloat(form.price);
    if (isNaN(price) || price < 0) errs.price = "Enter a valid price.";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  function buildPlan(): StoredPlan {
    const mins = parseInt(form.durationMinutes, 10);
    const feeVal = parseFloat(form.epaymentFee);
    const baseSlug = slugify(form.name) || "plan";
    let id = isNew ? baseSlug : (plan?.id ?? baseSlug);
    if (isNew) {
      const existingIds: string[] = plans.map((p) => p.id as string);
      let suffix = 0;
      while (existingIds.includes(id)) { suffix++; id = `${baseSlug}-${suffix}`; }
    }
    return {
      id: id,
      name: form.name.trim(),
      description: form.description.trim(),
      duration: minutesToLabel(mins),
      durationMinutes: mins,
      price: parseFloat(form.price),
      speed: form.speed.trim() || undefined,
      epaymentFee: (!isNaN(feeVal) && feeVal > 0) ? feeVal : undefined,
      popular: form.popular,
    };
  }

  const handleSave = async () => {
    if (!validate()) return;
    const built = buildPlan();
    if (isNew) {
      await addPlan(built);
    } else {
      await updatePlan(built.id, built);
    }
    setSaved(true);
    setTimeout(() => navigate({ to: "/settings", search: { role } }), 600);
  };

  const handleDelete = async () => {
    if (!plan) return;
    await deletePlan(plan.id);
    navigate({ to: "/settings", search: { role } });
  };

  const mins = parseInt(form.durationMinutes, 10);
  const price = parseFloat(form.price);
  const fee = parseFloat(form.epaymentFee);
  const previewPrice = !isNaN(price) ? formatPHP(price) : null;
  const previewFee = !isNaN(fee) && fee > 0 ? formatPHP(fee) : null;

  return (
    <div className="min-h-dvh w-full flex flex-col bg-background">

      {/* ── Sticky header ── */}
      <header className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b border-border safe-top safe-x pb-4">
        <div className="mx-auto w-full max-w-md pt-3">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary truncate">
                {brand.name} · {role === "admin" ? "Admin" : "Operator"}
              </p>
              <h1 className="text-3xl font-bold tracking-tight leading-tight mt-0.5">
                {isNew ? "New plan" : "Edit plan"}
              </h1>
            </div>
            <button
              onClick={() => navigate({ to: "/settings", search: { role } })}
              aria-label="Back to plan settings"
              className="h-10 w-10 flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground hover:bg-accent transition-colors shrink-0"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      {/* ── Scrollable body ── */}
      <main className="flex-1 safe-x pt-5 pb-2">
        <div className="mx-auto w-full max-w-md flex flex-col gap-5">

          {/* Live preview card */}
          <div className="rounded-2xl border-2 border-border bg-card p-4 flex items-center gap-3 min-h-[5rem]">
            <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <Plus className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="text-lg font-bold truncate">
                  {form.name.trim() || <span className="text-muted-foreground font-normal italic">Plan name</span>}
                </p>
                {form.popular && (
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-primary text-primary-foreground whitespace-nowrap shrink-0">
                    Popular
                  </span>
                )}
              </div>
              <p className="text-xs text-muted-foreground mt-0.5 truncate">
                {form.description.trim() || <span className="italic">Description</span>}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {!isNaN(mins) && mins > 0 ? minutesToLabel(mins) : "Duration"}
                {form.speed.trim() ? ` · ${form.speed.trim()}` : ""}
              </p>
            </div>
            <div className="shrink-0 text-right">
              <p className="text-2xl font-bold whitespace-nowrap">
                {previewPrice ?? <span className="text-muted-foreground text-base font-normal">₱—</span>}
              </p>
              {previewFee && (
                <p className="text-xs text-muted-foreground">+{previewFee} fee</p>
              )}
            </div>
          </div>

          {/* Form fields */}
          <Field label="Plan name" error={errors.name}>
            <Input
              ref={nameRef}
              value={form.name}
              onChange={(e) => set("name", e.target.value)}
              placeholder="e.g. Day Pass"
              className={`h-14 border-2 rounded-2xl bg-input text-base ${errors.name ? "border-destructive" : "border-border"}`}
            />
          </Field>

          <Field label="Description" error={errors.description}>
            <Input
              value={form.description}
              onChange={(e) => set("description", e.target.value)}
              placeholder="e.g. Full-day access, great for streaming."
              className={`h-14 border-2 rounded-2xl bg-input text-base ${errors.description ? "border-destructive" : "border-border"}`}
            />
          </Field>

          <Field label="Duration" error={errors.durationMinutes}>
            <div className="flex flex-wrap gap-2 mb-2">
              {DURATION_PRESETS.map((p) => {
                const active = form.durationMinutes === String(p.minutes);
                return (
                  <button
                    key={p.minutes}
                    type="button"
                    onClick={() => set("durationMinutes", String(p.minutes))}
                    className={`h-10 px-4 rounded-xl text-sm font-bold border-2 transition-colors ${
                      active
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border bg-background text-muted-foreground hover:border-primary/50"
                    }`}
                  >
                    {p.label}
                  </button>
                );
              })}
            </div>
            <div className="relative">
              <Input
                type="number"
                min={1}
                value={form.durationMinutes}
                onChange={(e) => set("durationMinutes", e.target.value)}
                placeholder="Custom (minutes)"
                className={`h-14 border-2 rounded-2xl bg-input text-base pr-16 ${errors.durationMinutes ? "border-destructive" : "border-border"}`}
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-sm text-muted-foreground font-semibold pointer-events-none">
                min
              </span>
            </div>
          </Field>

          <Field label="Price" error={errors.price}>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-lg font-bold text-muted-foreground pointer-events-none">₱</span>
              <Input
                type="number"
                min={0}
                step={0.01}
                value={form.price}
                onChange={(e) => set("price", e.target.value)}
                placeholder="0.00"
                className={`h-14 border-2 rounded-2xl bg-input text-base pl-9 ${errors.price ? "border-destructive" : "border-border"}`}
              />
            </div>
          </Field>

          <Field
            label="Speed"
            optional
            hint="Leave blank to hide speed from the plan selection screen."
          >
            <Input
              value={form.speed}
              onChange={(e) => set("speed", e.target.value)}
              placeholder="e.g. 25 Mbps"
              className="h-14 border-2 border-border rounded-2xl bg-input text-base"
            />
          </Field>

          <Field
            label="E-payment fee"
            optional
            hint="Added when customer pays via GCash, QR PH, or Maya. Leave blank for no fee."
          >
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-lg font-bold text-muted-foreground pointer-events-none">₱</span>
              <Input
                type="number"
                min={0}
                step={0.01}
                value={form.epaymentFee}
                onChange={(e) => set("epaymentFee", e.target.value)}
                placeholder="0.00"
                className="h-14 border-2 border-border rounded-2xl bg-input text-base pl-9"
              />
            </div>
          </Field>

          {/* Popular toggle — large tappable row */}
          <label className="flex items-center gap-4 cursor-pointer select-none rounded-2xl border-2 border-border bg-card p-4 active:bg-secondary/50 transition-colors">
            <div
              role="checkbox"
              aria-checked={form.popular}
              tabIndex={0}
              onKeyDown={(e) => (e.key === " " || e.key === "Enter") && set("popular", !form.popular)}
              onClick={() => set("popular", !form.popular)}
              className={`h-7 w-7 rounded-xl border-2 flex items-center justify-center shrink-0 transition-colors ${
                form.popular ? "bg-primary border-primary" : "border-border bg-background"
              }`}
            >
              {form.popular && <Check className="h-4 w-4 text-primary-foreground" strokeWidth={3} />}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-base font-bold">Mark as popular</p>
              <p className="text-sm text-muted-foreground mt-0.5">
                Shows a "Popular" badge on this plan in the selection screen.
              </p>
            </div>
          </label>

          {/* Delete zone (edit only) */}
          {!isNew && plan && (
            <div className="rounded-2xl border-2 border-border bg-card p-4">
              <div className="flex items-start gap-3">
                <div className="h-10 w-10 rounded-xl bg-destructive/10 flex items-center justify-center shrink-0">
                  <AlertCircle className="h-5 w-5 text-destructive" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold">Delete this plan</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    This removes the plan from the selection screen. Existing vouchers are not affected.
                  </p>
                </div>
              </div>
              {deleteConfirm ? (
                <div className="flex gap-2 mt-3">
                  <Button
                    onClick={handleDelete}
                    variant="secondary"
                    className="flex-1 h-12 rounded-xl text-sm font-bold border-2 border-destructive/50 text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Yes, delete plan
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => setDeleteConfirm(false)}
                    className="flex-1 h-12 rounded-xl text-sm font-semibold border-2 border-border"
                  >
                    Cancel
                  </Button>
                </div>
              ) : (
                <Button
                  variant="secondary"
                  onClick={() => setDeleteConfirm(true)}
                  className="w-full h-12 mt-3 rounded-xl text-sm font-semibold border-2 border-border text-destructive hover:bg-destructive/10 hover:border-destructive/50"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete plan
                </Button>
              )}
            </div>
          )}

        </div>
      </main>

      {/* ── Sticky footer ── */}
      <footer className="sticky bottom-0 z-20 bg-background/95 backdrop-blur border-t border-border safe-bottom safe-x pt-3">
        <div className="mx-auto w-full max-w-md flex flex-col gap-3">
          <Button
            onClick={handleSave}
            disabled={saved}
            className="w-full h-16 text-lg font-bold rounded-2xl disabled:opacity-60"
          >
            {saved
              ? <><Check className="h-5 w-5 mr-2" /> Saved!</>
              : <><Check className="h-5 w-5 mr-2" /> {isNew ? "Add plan" : "Save changes"}</>
            }
          </Button>
          <Button
            variant="secondary"
            onClick={() => navigate({ to: "/settings", search: { role } })}
            className="w-full h-12 text-base font-semibold rounded-xl border-2 border-border text-muted-foreground"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to plans
          </Button>
        </div>
      </footer>

    </div>
  );
}
