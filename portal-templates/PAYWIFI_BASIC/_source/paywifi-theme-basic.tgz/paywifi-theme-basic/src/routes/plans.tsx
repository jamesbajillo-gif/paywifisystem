import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronRight, X, Zap } from "lucide-react";
import { getPlans, type Plan } from "@/lib/portal-api";
import { useBrand, BRAND } from "@/lib/brand";
import { trackEvent } from "@/lib/analytics";
import { formatPHP } from "@/lib/utils";

export type { Plan };

export const Route = createFileRoute("/plans")({
  head: () => ({ meta: [{ title: `Choose a plan — ${BRAND}` }] }),
  component: Plans,
});

function Plans() {
  const navigate = useNavigate();
  const brand = useBrand();
  const [plans, setPlans] = useState<Plan[] | null>(null);

  useEffect(() => {
    let cancelled = false;
    getPlans().then((p) => {
      if (!cancelled) setPlans(p);
    });
    return () => { cancelled = true; };
  }, []);

  return (
    <div className="min-h-dvh w-full flex flex-col bg-background">

        {/* Sticky header — mirrors index.tsx */}
        <header className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b border-border safe-top safe-x pb-4">
          <div className="mx-auto w-full max-w-md pt-3">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary mb-0.5">
                  {brand.name}
                </p>
                <h1 className="text-3xl font-bold tracking-tight leading-tight">Choose a plan</h1>
                <p className="mt-1 text-base text-muted-foreground">
                  Pick the time that fits you
                </p>
              </div>
              <button
                onClick={() => navigate({ to: "/" })}
                aria-label="Back to portal"
                className="mt-1 h-9 w-9 flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground hover:bg-accent transition-colors shrink-0"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>
        </header>

        {/* Plan list — flex-1 fills remaining viewport height */}
        <section
          aria-label="Available plans"
          className="flex-1 flex flex-col safe-x pt-4 pb-2 min-h-0"
        >
          <div className="mx-auto w-full max-w-md flex flex-col gap-3 flex-1">
            {plans === null
              ? /* Skeleton */
                Array.from({ length: 3 }).map((_, i) => (
                  <div
                    key={i}
                    aria-hidden="true"
                    className="flex-1 rounded-2xl border-2 border-border bg-card animate-pulse p-5 min-h-[5rem]"
                  />
                ))
              : plans.map((p) => (
                  <PlanCard
                    key={p.id}
                    plan={p}
                    count={plans.length}
                    onClick={() => {
                      trackEvent("plan_picked", { planId: p.id, price: p.price });
                      navigate({ to: "/checkout", search: { plan: p.id } });
                    }}
                  />
                ))}
          </div>
        </section>

        {/* Sticky footer back button — mirrors index.tsx footer */}
        <footer className="sticky bottom-0 z-20 bg-background/95 backdrop-blur border-t border-border safe-bottom safe-x pt-3">
          <div className="mx-auto w-full max-w-md">
            <Button
              variant="secondary"
              onClick={() => navigate({ to: "/" })}
              className="w-full h-14 text-base font-semibold rounded-2xl border-2 border-border"
            >
              Back
            </Button>
          </div>
        </footer>

      </div>
  );
}

function PlanCard({
  plan,
  count,
  onClick,
}: {
  plan: Plan;
  count: number;
  onClick: () => void;
}) {
  /* Stretch each card so all plans share the available height evenly */
  return (
    <button
      onClick={onClick}
      className={`
        relative flex-1 w-full text-left rounded-2xl border-2 bg-card
        transition-all active:scale-[0.98]
        flex items-center gap-4 px-5 min-h-[4.5rem]
        ${plan.popular
          ? "border-primary shadow-sm shadow-primary/10 hover:shadow-primary/20"
          : "border-border hover:border-primary/50"}
      `}
      style={{ minHeight: count <= 3 ? "0" : "4.5rem" }}
    >
      {/* Popular ribbon */}
      {plan.popular && (
        <span className="absolute top-3 right-3 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-primary text-primary-foreground whitespace-nowrap">
          Popular
        </span>
      )}

      {/* Left: icon pill */}
      <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
        <Zap className="h-5 w-5 text-primary" />
      </div>

      {/* Middle: name + meta */}
      <div className="flex-1 min-w-0 py-4">
        <p className="text-xl font-bold leading-tight truncate pr-16">{plan.name}</p>
        {plan.description && (
          <p className="text-sm text-muted-foreground mt-0.5 truncate">{plan.description}</p>
        )}
        <p className="text-xs text-muted-foreground mt-0.5 truncate">
          {plan.duration}{plan.speed ? ` · ${plan.speed}` : ""}
        </p>
      </div>

      {/* Right: price + chevron */}
      <div className="flex items-center gap-2 shrink-0">
        <p className="text-3xl font-bold whitespace-nowrap tabular-nums">{formatPHP(plan.price)}</p>
        <ChevronRight className="h-5 w-5 text-muted-foreground" />
      </div>
    </button>
  );
}
