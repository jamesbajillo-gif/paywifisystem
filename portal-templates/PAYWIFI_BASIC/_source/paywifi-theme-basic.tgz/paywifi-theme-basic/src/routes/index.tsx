import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AdsWidget } from "@/components/widgets/AdsWidget";
import { ClipboardPaste } from "lucide-react";
import { BRAND, useBrand } from "@/lib/brand";
import { trackEvent } from "@/lib/analytics";
import { formatVoucherCode } from "@/lib/portal-api";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: `${BRAND} — Connect to WiFi` },
      { name: "description", content: `Connect to ${BRAND} using your voucher code.` },
    ],
  }),
  component: Index,
});

function Index() {
  const navigate = useNavigate();
  const brand = useBrand();
  const [code, setCode] = useState("");
  const [pasteError, setPasteError] = useState(false);

  useEffect(() => {
    trackEvent("home_view");
  }, []);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = code.trim();
    if (!trimmed) return;
    trackEvent("voucher_submitted", { code_length: trimmed.length });
    navigate({ to: "/validate", search: { code: trimmed } });
  };

  const onPaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setCode(formatVoucherCode(text));
      setPasteError(false);
    } catch {
      setPasteError(true);
      setTimeout(() => setPasteError(false), 2000);
    }
  };

  return (
    <div className="min-h-dvh w-full flex flex-col bg-background">
      <header className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b border-border safe-top safe-x pb-4">
        <div className="mx-auto w-full max-w-md text-center pt-2">
          <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary mb-1">{brand.name}</p>
          <h1 className="text-3xl font-bold tracking-tight leading-tight">Connect to WiFi</h1>
          <p className="mt-1 text-base text-muted-foreground">Enter your voucher code</p>

          <form onSubmit={onSubmit} className="mt-4 flex flex-col gap-3">
            <div className="relative">
              <Input
                value={code}
                onChange={(e) => setCode(formatVoucherCode(e.target.value))}
                placeholder="XXXX-XXXX-XXXX"
                maxLength={14}
                autoFocus
                aria-label="Voucher code"
                className="h-20 text-center font-mono bg-input border-2 border-border rounded-2xl text-fluid-input w-full min-w-0 pr-14"
              />
              <button
                type="button"
                onClick={onPaste}
                aria-label="Paste voucher code from clipboard"
                className="absolute right-2 top-1/2 -translate-y-1/2 h-12 w-12 rounded-xl bg-card border-2 border-border hover:border-primary flex items-center justify-center transition-colors"
              >
                <ClipboardPaste className="h-5 w-5" />
              </button>
            </div>
            {pasteError && (
              <p className="text-xs text-destructive">
                Couldn't read your clipboard. Long-press the box to paste manually.
              </p>
            )}
            <Button
              type="submit"
              className="h-16 text-lg font-bold rounded-2xl w-full"
            >
              Connect
            </Button>
          </form>
        </div>
      </header>

      <section
        aria-label="More options"
        className="flex-1 overflow-y-auto safe-x pt-4 pb-4"
      >
        <div className="mx-auto w-full max-w-md flex flex-col gap-3">
          <AdsWidget />
        </div>
      </section>

      <footer className="sticky bottom-0 z-20 bg-background/95 backdrop-blur border-t border-border safe-bottom safe-x pt-3">
        <div className="mx-auto w-full max-w-md rounded-2xl border-2 border-border bg-card p-4 flex items-center justify-between gap-3 min-w-0">
          <div className="min-w-0 flex-1">
            <p className="text-lg font-bold truncate">No voucher?</p>
            <p className="text-sm text-muted-foreground mt-0.5 truncate">Plans from ₱1.99</p>
          </div>
          <Link to="/plans" className="shrink-0">
            <Button
              variant="secondary"
              className="h-12 px-5 rounded-xl font-bold text-base border-2 border-border whitespace-nowrap"
            >
              Buy one
            </Button>
          </Link>
        </div>
      </footer>
    </div>
  );
}
