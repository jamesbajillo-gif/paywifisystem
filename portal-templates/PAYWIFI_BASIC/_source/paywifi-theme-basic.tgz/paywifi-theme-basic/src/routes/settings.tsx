import { createFileRoute, Link, useNavigate, useSearch } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { getPlans, resetPlans, type Plan } from "@/lib/portal-api";
import { BRAND, useBrand } from "@/lib/brand";
import { Button } from "@/components/ui/button";
import { formatPHP } from "@/lib/utils";
import {
  ArrowLeft,
  Plus,
  ChevronRight,
  RotateCcw,
  AlertCircle,
  Clock,
  Zap,
} from "lucide-react";

const searchSchema = z.object({
  role: z.enum(["admin", "operator"]).catch("operator"),
});

export const Route = createFileRoute("/settings")({
  head: () => ({ meta: [{ title: `Plan Settings — ${BRAND}` }] }),
  validateSearch: searchSchema,
  component: Settings,
});

function Settings() {
  const brand = useBrand();
  const navigate = useNavigate();
  const { role } = useSearch({ from: "/settings" });
  const backTo = role === "admin" ? "/admin" : "/operator";
  const backLabel = role === "admin" ? "Admin" : "Operator";

  const [plans, setPlans] = useState<Plan[] | null>(null);
  const [resetConfirm, setResetConfirm] = useState(false);

  async function refresh() {
    setPlans(await getPlans());
  }

  useEffect(() => { refresh(); }, []);

  function handleReset() {
    resetPlans();
    setResetConfirm(false);
    refresh();
  }

  return (
    <div className="min-h-dvh w-full flex flex-col bg-background">

      {/* ── Sticky header ── */}
      <header className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b border-border safe-top safe-x pb-4">
        <div className="mx-auto w-full max-w-md pt-3 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary truncate">
              {brand.name} · {backLabel}
            </p>
            <h1 className="text-3xl font-bold tracking-tight mt-0.5">Plan settings</h1>
          </div>
          <Link to={backTo} className="shrink-0">
            <Button
              variant="secondary"
              className="h-11 px-4 rounded-xl text-sm font-semibold border-2 border-border gap-1.5"
            >
              <ArrowLeft className="h-4 w-4" />
              {backLabel}
            </Button>
          </Link>
        </div>
      </header>

      {/* ── Scrollable body ── */}
      <main className="flex-1 safe-x pt-5 pb-2">
        <div className="mx-auto w-full max-w-md flex flex-col gap-3">

          {/* Plan list */}
          {plans === null ? (
            Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="rounded-2xl border-2 border-border bg-card p-5 animate-pulse h-20" />
            ))
          ) : plans.length === 0 ? (
            <div className="rounded-2xl border-2 border-dashed border-border p-10 text-center">
              <p className="text-base font-semibold text-muted-foreground">No plans configured.</p>
              <p className="text-sm text-muted-foreground mt-1">Add your first plan below.</p>
            </div>
          ) : (
            plans.map((p) => (
              <PlanRow key={p.id} plan={p} role={role} />
            ))
          )}

          {/* Add new plan button */}
          <Link to="/plan-edit/$planId" params={{ planId: "new" }} search={{ role }}>
            <button className="w-full rounded-2xl border-2 border-dashed border-border hover:border-primary/60 bg-card p-5 flex items-center justify-center gap-2 text-base font-semibold text-muted-foreground hover:text-primary transition-colors">
              <Plus className="h-5 w-5" />
              Add a plan
            </button>
          </Link>

          {/* Danger zone */}
          <div className="mt-4 pt-5 border-t border-border">
            <p className="text-xs font-bold uppercase tracking-[0.15em] text-muted-foreground mb-3 px-0.5">
              Danger zone
            </p>
            <div className="rounded-2xl border-2 border-border bg-card p-4">
              <div className="flex items-start gap-3">
                <div className="h-10 w-10 rounded-xl bg-destructive/10 flex items-center justify-center shrink-0">
                  <AlertCircle className="h-5 w-5 text-destructive" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold">Reset to defaults</p>
                  <p className="text-xs text-muted-foreground mt-0.5 leading-snug">
                    Restores the original 1 Hour, Day Pass, and Week Pass plans. All custom plans will be removed.
                  </p>
                </div>
              </div>
              {resetConfirm ? (
                <div className="flex gap-2 mt-3">
                  <Button
                    onClick={handleReset}
                    variant="secondary"
                    className="flex-1 h-12 rounded-xl text-sm font-bold border-2 border-destructive/50 text-destructive hover:bg-destructive/10"
                  >
                    Yes, reset plans
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => setResetConfirm(false)}
                    className="flex-1 h-12 rounded-xl text-sm font-semibold border-2 border-border"
                  >
                    Cancel
                  </Button>
                </div>
              ) : (
                <Button
                  variant="secondary"
                  onClick={() => setResetConfirm(true)}
                  className="w-full h-12 mt-3 rounded-xl text-sm font-semibold border-2 border-border"
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Reset to defaults
                </Button>
              )}
            </div>
          </div>

        </div>
      </main>

      {/* ── Sticky footer: Add plan shortcut ── */}
      <footer className="sticky bottom-0 z-20 bg-background/95 backdrop-blur border-t border-border safe-bottom safe-x pt-3">
        <div className="mx-auto w-full max-w-md">
          <Link to="/plan-edit/$planId" params={{ planId: "new" }} search={{ role }}>
            <Button className="w-full h-14 text-base font-bold rounded-2xl">
              <Plus className="h-5 w-5 mr-2" />
              Add new plan
            </Button>
          </Link>
        </div>
      </footer>

    </div>
  );
}

// ─── Tappable plan row ────────────────────────────────────────────────────
function PlanRow({ plan, role }: { plan: Plan; role: "admin" | "operator" }) {
  return (
    <Link
      to="/plan-edit/$planId"
      params={{ planId: plan.id }}
      search={{ role }}
      className={`w-full rounded-2xl border-2 bg-card p-5 flex items-center gap-4 min-w-0 hover:border-primary/50 active:scale-[0.99] transition-all ${
        plan.popular ? "border-primary/30" : "border-border"
      }`}
    >
      {/* Icon */}
      <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
        <Zap className="h-5 w-5 text-primary" />
      </div>

      {/* Details */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="text-base font-bold truncate">{plan.name}</p>
          {plan.popular && (
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-primary text-primary-foreground whitespace-nowrap shrink-0">
              Popular
            </span>
          )}
        </div>
        <p className="text-sm text-muted-foreground mt-0.5 truncate">{plan.description}</p>
        <div className="flex items-center gap-3 mt-1 flex-wrap">
          <span className="flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="h-3 w-3" />{plan.duration}
          </span>
          {plan.speed && (
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Zap className="h-3 w-3" />{plan.speed}
            </span>
          )}
          {plan.epaymentFee && plan.epaymentFee > 0 && (
            <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
              +{formatPHP(plan.epaymentFee)} e-pay
            </span>
          )}
        </div>
      </div>

      {/* Price + chevron */}
      <div className="shrink-0 flex items-center gap-2">
        <p className="text-2xl font-bold whitespace-nowrap tabular-nums">{formatPHP(plan.price)}</p>
        <ChevronRight className="h-5 w-5 text-muted-foreground" />
      </div>
    </Link>
  );
}
