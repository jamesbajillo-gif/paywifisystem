import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { QrCode } from "@/components/QrCode";
import { PlanDuration } from "@/components/PlanDuration";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, Clock, Ban, Loader2, X, WifiOff } from "lucide-react";
import { z } from "zod";
import {
  validateVoucher,
  getPlan,
  type VoucherStatus,
  type PlanId,
} from "@/lib/portal-api";
import { findVoucher } from "@/lib/portal-api";
import { BRAND, useBrand } from "@/lib/brand";
import { trackEvent } from "@/lib/analytics";
import { useDbStatus } from "@/components/DbStatusContext";

const search = z.object({ code: z.string().min(1).max(64) });

export const Route = createFileRoute("/validate")({
  validateSearch: search,
  head: () => ({ meta: [{ title: `Validating voucher -- ${BRAND}` }] }),
  component: Validate,
});

type UiState =
  | { kind: "checking" }
  | { kind: "valid"; planId?: PlanId }
  | { kind: "failed"; status: Exclude<VoucherStatus, "valid">; message: string }
  | { kind: "offline" };

const FAILURE_COPY: Record<
  Exclude<VoucherStatus, "valid">,
  { title: string; headline: string; icon: typeof XCircle }
> = {
  invalid: { title: "Voucher not found", headline: "Not found", icon: XCircle },
  expired: { title: "Voucher expired",   headline: "Expired",   icon: Clock },
  used:    { title: "Already used",      headline: "Used",      icon: Ban },
};

function PageShell({
  brand,
  title,
  subtitle,
  children,
  footer,
  onClose,
}: {
  brand: string;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  onClose: () => void;
}) {
  return (
    <div className="min-h-dvh w-full flex flex-col bg-background">
      <header className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b border-border safe-top safe-x pb-4">
        <div className="mx-auto w-full max-w-md pt-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary mb-0.5">{brand}</p>
              <h1 className="text-3xl font-bold tracking-tight leading-tight">{title}</h1>
              {subtitle && <p className="mt-1 text-base text-muted-foreground">{subtitle}</p>}
            </div>
            <button
              onClick={onClose}
              aria-label="Back to portal"
              className="mt-1 h-9 w-9 flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground hover:bg-accent transition-colors shrink-0"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>
      <main className="flex-1 flex flex-col safe-x pt-4 pb-2 min-h-0 overflow-y-auto">
        <div className="mx-auto w-full max-w-md flex flex-col gap-3 flex-1">
          {children}
        </div>
      </main>
      {footer && (
        <footer className="sticky bottom-0 z-20 bg-background/95 backdrop-blur border-t border-border safe-bottom safe-x pt-3 pb-4">
          <div className="mx-auto w-full max-w-md flex flex-col gap-2">
            {footer}
          </div>
        </footer>
      )}
    </div>
  );
}

function Validate() {
  const { code } = Route.useSearch();
  const brand = useBrand();
  const navigate = useNavigate();
  const [state, setState] = useState<UiState>({ kind: "checking" });
  const { status: dbStatus } = useDbStatus();

  useEffect(() => {
    if (dbStatus === "offline") {
      setState({ kind: "offline" });
      return;
    }
    if (dbStatus === "checking") {
      setState({ kind: "checking" });
      return;
    }
    let cancelled = false;
    validateVoucher(code).then((result) => {
      if (cancelled) return;
      if (result.ok) {
        trackEvent("voucher_validated", { status: "valid" });
        setState({ kind: "valid", planId: result.planId });
      } else {
        trackEvent("voucher_validated", { status: result.status });
        setState({ kind: "failed", status: result.status, message: result.message });
      }
    });
    return () => { cancelled = true; };
  }, [code, dbStatus]);

  if (state.kind === "checking") {
    return (
      <PageShell brand={brand.name} title="Checking..." onClose={() => navigate({ to: "/" })}>
        <div className="flex-1 flex flex-col items-center justify-center text-center">
          <Loader2 className="h-20 w-20 text-primary animate-spin" />
          <p className="mt-6 text-xl font-semibold text-muted-foreground">Verifying your code</p>
          <p className="mt-3 font-mono text-lg text-muted-foreground break-all px-2">{code}</p>
        </div>
      </PageShell>
    );
  }

  if (state.kind === "offline") {
    return (
      <PageShell
        brand={brand.name}
        title="Refreshing connection"
        onClose={() => navigate({ to: "/" })}
        footer={
          <Link to="/"><Button className="w-full h-16 text-lg font-bold rounded-2xl">Go back</Button></Link>
        }
      >
        <div className="flex-1 flex flex-col items-center justify-center text-center">
          <div className="h-28 w-28 rounded-full bg-amber-500/10 flex items-center justify-center">
            <WifiOff className="h-16 w-16 text-amber-500" strokeWidth={2} />
          </div>
          <p className="mt-5 text-2xl font-bold">Refreshing connection</p>
          <p className="mt-2 text-lg text-muted-foreground px-4">
            We're reconnecting to verify your voucher. Please try again in a moment.
          </p>
        </div>
      </PageShell>
    );
  }

  if (state.kind === "failed") {
    const copy = FAILURE_COPY[state.status];
    const Icon = copy.icon;
    return (
      <PageShell
        brand={brand.name}
        title={copy.title}
        onClose={() => navigate({ to: "/" })}
        footer={
          <>
            <Link to="/"><Button className="w-full h-16 text-lg font-bold rounded-2xl">Try another code</Button></Link>
            <Link to="/plans">
              <Button variant="secondary" className="w-full h-14 text-base font-semibold rounded-2xl border-2 border-border">
                Buy voucher
              </Button>
            </Link>
          </>
        }
      >
        <div className="flex-1 flex flex-col items-center justify-center text-center">
          <div className="h-28 w-28 rounded-full bg-destructive/10 flex items-center justify-center">
            <Icon className="h-16 w-16 text-destructive" strokeWidth={2} />
          </div>
          <p className="mt-5 text-2xl font-bold text-destructive">{copy.headline}</p>
          <p className="mt-2 text-lg text-muted-foreground px-4">{state.message}</p>
          <p className="mt-3 font-mono text-lg text-muted-foreground break-all px-2">{code}</p>
        </div>
      </PageShell>
    );
  }

  const plan = state.planId ? getPlan(state.planId) : undefined;
  const stored = findVoucher(code);
  return (
    <PageShell
      brand={brand.name}
      title="You're online!"
      onClose={() => navigate({ to: "/" })}
      footer={
        <a
          href="https://www.google.com"
          onClick={() => trackEvent("start_browsing", { source: "validate" })}
          className="block"
        >
          <Button className="w-full h-16 text-lg font-bold rounded-2xl">Start browsing</Button>
        </a>
      }
    >
      <p className="text-xl font-bold text-success flex items-center justify-center gap-2 text-center">
        <CheckCircle2 className="h-7 w-7" strokeWidth={2.5} />
        Connected
      </p>
      <div className="mt-3 w-full rounded-2xl border-2 border-border bg-secondary/60 p-3 text-center min-w-0 overflow-hidden">
        <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
          Active voucher
        </p>
        <div className="mt-2 flex justify-center">
          <div className="rounded-xl bg-white p-2 border-2 border-border">
            <QrCode value={code} size={120} ariaLabel={`Voucher code ${code}`} />
          </div>
        </div>
        <p className="mt-2 font-mono font-bold text-lg break-all tracking-wider">{code}</p>
        {plan && (
          <div className="mt-2 flex justify-center">
            <PlanDuration plan={plan} redeemedAt={stored?.redeemedAt} />
          </div>
        )}
      </div>
    </PageShell>
  );
}
