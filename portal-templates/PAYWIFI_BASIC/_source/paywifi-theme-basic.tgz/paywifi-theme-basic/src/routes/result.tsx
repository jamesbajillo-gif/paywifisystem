import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { z } from "zod";
import { QrCode } from "@/components/QrCode";
import { PlanDuration } from "@/components/PlanDuration";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  CheckCircle2,
  XCircle,
  Copy,
  Share2,
  Check,
  Loader2,
  MessageSquare,
  Pencil,
  Lock,
  MapPin,
  AlertCircle,
  ArrowRight,
  RotateCcw,
  Timer,
  ChevronDown,
  ChevronUp,
  X,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import {
  redeemVoucher,
  voidVoucher,
  clearPendingDigitalPayment,
  getQueuedTimeForPhone,
  getPlan,
  findByPaymentReference,
  updateVoucherPhone,
  getPhoneEditLog,
  PHONE_EDIT_COOLDOWN_MS,
  PHONE_EDIT_MAX_CHANGES,
  type PaymentMethod,
  type PlanId,
} from "@/lib/portal-api";
import { BRAND, useBrand } from "@/lib/brand";
import type { ReactNode } from "react";
import { trackEvent } from "@/lib/analytics";
import { getStore } from "@/lib/stores";
import { formatPHP } from "@/lib/utils";
import { XENDIT_CHANNELS } from "@/lib/xendit-client";
import { handleXenditPaymentSuccess } from "@/lib/api/payment.functions";
import { getSystemId } from "@/lib/supabase";

const search = z.object({
  status: z.enum(["success", "failed", "pending"]),
  code: z.string().min(1).max(64).optional(),
  paymentReference: z.string().min(1).max(64).optional(),
  phone: z.string().min(1).max(20).optional(),
  message: z.string().min(1).max(200).optional(),
  planId: z.string().optional(),
  method: z.string().optional(),
  price: z.number().optional(),
  transactionId: z.string().min(1).max(64).optional(),
  storeId: z.string().min(1).max(64).optional(),
});

export const Route = createFileRoute("/result")({
  validateSearch: search,
  head: () => ({ meta: [{ title: `Order status — ${BRAND}` }] }),
  component: Result,
});

function Result() {
  const brand = useBrand();
  const {
    status, code, paymentReference, phone,
    message, planId, method, price,
    transactionId, storeId,
  } = Route.useSearch();

  useEffect(() => {
    if (status === "success") {
      trackEvent("payment_success", {
        planId: (planId ?? "unknown") as PlanId,
        method: (method ?? "unknown") as PaymentMethod,
        price: price ?? 0,
        transactionId: transactionId ?? "",
      });
    } else if (status === "failed") {
      trackEvent("payment_failed", { planId: (planId ?? "unknown") as PlanId, reason: message ?? "Unknown" });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  if (status === "failed") {
    return <FailedView message={message} planId={planId} method={method as PaymentMethod | undefined} />;
  }

  if (status === "pending") {
    return (
      <PendingView
        paymentReference={paymentReference}
        phone={phone}
        planId={planId as PlanId | undefined}
        method={method as PaymentMethod | undefined}
        price={price}
        transactionId={transactionId}
        storeId={storeId}
      />
    );
  }

  const plan = planId ? getPlan(planId as PlanId) : undefined;
  return (
    <SuccessView
      code={code}
      phone={phone}
      method={method as PaymentMethod | undefined}
      brandName={brand.name}
      plan={plan}
      transactionId={transactionId}
    />
  );
}

// ─── Shared page shell (matches plans.tsx / checkout.tsx layout) ─────────────
function ResultShell({
  brandName,
  title,
  subtitle,
  children,
  footer,
  onClose,
}: {
  brandName: string;
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
  onClose?: () => void;
}) {
  const navigate = useNavigate();
  return (
    <div className="min-h-dvh w-full flex flex-col bg-background">
      <header className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b border-border safe-top safe-x pb-4">
        <div className="mx-auto w-full max-w-md pt-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary mb-0.5">{brandName}</p>
              <h1 className="text-3xl font-bold tracking-tight leading-tight">{title}</h1>
              {subtitle && <p className="mt-1 text-base text-muted-foreground">{subtitle}</p>}
            </div>
            <button
              onClick={onClose ?? (() => navigate({ to: "/" }))}
              aria-label="Back to portal"
              className="mt-1 h-9 w-9 flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground hover:bg-accent transition-colors shrink-0"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>
      <main className="flex-1 flex flex-col safe-x pt-4 pb-2 min-h-0 overflow-y-auto">
        <div className="mx-auto w-full max-w-md flex flex-col gap-3 flex-1">
          {children}
        </div>
      </main>
      {footer && (
        <footer className="sticky bottom-0 z-20 bg-background/95 backdrop-blur border-t border-border safe-bottom safe-x pt-3 pb-4">
          <div className="mx-auto w-full max-w-md flex flex-col gap-2">
            {footer}
          </div>
        </footer>
      )}
    </div>
  );
}

// ─── Failed view ──────────────────────────────────────────────────────────────
function FailedView({
  message, planId, method,
}: {
  message?: string;
  planId?: string;
  method?: PaymentMethod;
}) {
  const brand = useBrand();
  const methodLabel = method ? (METHOD_LABEL[method as string] ?? method) : undefined;
  return (
    <ResultShell
      brandName={brand.name}
      title="Payment didn't go through"
      footer={
        <>
          {planId ? (
            <Link to="/checkout" search={{ plan: planId }}>
              <Button className="w-full h-16 text-lg font-bold rounded-2xl">
                <RotateCcw className="h-5 w-5 mr-2" />Try again
              </Button>
            </Link>
          ) : (
            <Link to="/plans">
              <Button className="w-full h-16 text-lg font-bold rounded-2xl">
                <RotateCcw className="h-5 w-5 mr-2" />Try again
              </Button>
            </Link>
          )}
          <Link to="/plans" className="w-full text-center py-2 text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors">
            Choose a different plan
          </Link>
          <Link to="/" className="w-full text-center py-1 text-xs text-muted-foreground/60 hover:text-muted-foreground transition-colors">
            Back to portal home
          </Link>
        </>
      }
    >
      <div className="flex-1 flex flex-col items-center justify-center text-center px-2">
        <div className="h-24 w-24 rounded-full bg-amber-500/10 flex items-center justify-center">
          <XCircle className="h-14 w-14 text-amber-500" strokeWidth={2} />
        </div>
        <p className="mt-5 text-xl font-bold">Payment didn&apos;t go through</p>
        {methodLabel && (
          <p className="mt-1 text-sm text-muted-foreground">
            via <span className="font-semibold text-foreground">{methodLabel}</span>
          </p>
        )}
        {message && (
          <div className="mt-4 w-full rounded-2xl border-2 border-amber-500/20 bg-amber-500/5 p-4 text-left">
            <div className="flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
              <p className="text-sm text-muted-foreground leading-snug">{message}</p>
            </div>
          </div>
        )}
      </div>
    </ResultShell>
  );
}

// ─── Pending view ─────────────────────────────────────────────────────────────
function PendingView({
  paymentReference, phone, planId, method, price, transactionId, storeId,
}: {
  paymentReference: string | undefined;
  phone: string | undefined;
  planId: PlanId | undefined;
  method: PaymentMethod | undefined;
  price: number | undefined;
  transactionId: string | undefined;
  storeId: string | undefined;
}) {
  const store = getStore(storeId);
  const navigate = useNavigate();
  const brand = useBrand();
  const [confirming, setConfirming] = useState(false);
  const [confirmError, setConfirmError] = useState<string | null>(null);
  const inFlightRef = useRef(false);
  const [syncState, setSyncState] = useState<"waiting" | "processing">("waiting");
  // R6: cooldown between check taps
  const [checkCooldown, setCheckCooldown] = useState(0);

  // B1: expiry countdown
  const [expiresAt, setExpiresAt] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [expired, setExpired] = useState(false);

  useEffect(() => {
    if (!paymentReference) return;
    const stored = findByPaymentReference(paymentReference);
    if (stored?.expiresAt) setExpiresAt(stored.expiresAt);
  }, [paymentReference]);

  useEffect(() => {
    if (!expiresAt) return;
    const tick = () => {
      const left = Math.max(0, expiresAt - Date.now());
      setTimeLeft(left);
      if (left === 0) setExpired(true);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [expiresAt]);

  // Phone edit state
  const [localPhone, setLocalPhone] = useState(phone ?? "");
  const [editingPhone, setEditingPhone] = useState(false);
  const [draftPhone, setDraftPhone] = useState("");
  const [phoneError, setPhoneError] = useState<string | null>(null);
  const [phoneSaving, setPhoneSaving] = useState(false);
  const [editCount, setEditCount] = useState(0);
  const [cooldownUntil, setCooldownUntil] = useState(0);
  const [cooldownLeft, setCooldownLeft] = useState(0);

  useEffect(() => {
    if (!paymentReference) return;
    const log = getPhoneEditLog(paymentReference);
    if (log) {
      setEditCount(log.edits.length);
      const remaining = log.lastEditAt + PHONE_EDIT_COOLDOWN_MS - Date.now();
      if (remaining > 0) {
        setCooldownUntil(log.lastEditAt + PHONE_EDIT_COOLDOWN_MS);
        setCooldownLeft(Math.ceil(remaining / 1000));
      }
    }
  }, [paymentReference]);

  useEffect(() => {
    if (cooldownUntil === 0) return;
    const tick = () => {
      const left = Math.ceil((cooldownUntil - Date.now()) / 1000);
      if (left <= 0) { setCooldownLeft(0); setCooldownUntil(0); }
      else setCooldownLeft(left);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [cooldownUntil]);

  // R6: check button cooldown ticker
  useEffect(() => {
    if (checkCooldown <= 0) return;
    const id = setInterval(() => setCheckCooldown((c) => Math.max(0, c - 1)), 1000);
    return () => clearInterval(id);
  }, [checkCooldown > 0]);

  const editsRemaining = PHONE_EDIT_MAX_CHANGES - editCount;
  const isCooldown = cooldownLeft > 0;
  const isLimitReached = editCount >= PHONE_EDIT_MAX_CHANGES;
  const canOpenEdit = !!paymentReference && !isLimitReached && !isCooldown;

  const onOpenEdit = () => {
    setDraftPhone(localPhone);
    setPhoneError(null);
    setEditingPhone(true);
  };

  const onSavePhone = async () => {
    if (!paymentReference || phoneSaving) return;
    setPhoneSaving(true);
    setPhoneError(null);
    const stored = findByPaymentReference(paymentReference);
    if (!stored) { setPhoneError("Payment reference not found."); setPhoneSaving(false); return; }
    if (stored.confirmedAt || stored.voidedAt || stored.redeemedAt) {
      setPhoneError("Payment already processed."); setPhoneSaving(false); return;
    }
    const result = updateVoucherPhone(paymentReference, draftPhone);
    if (result.ok) {
      setLocalPhone(draftPhone);
      setEditingPhone(false);
      const log = getPhoneEditLog(paymentReference);
      if (log) {
        setEditCount(log.edits.length);
        setCooldownUntil(log.lastEditAt + PHONE_EDIT_COOLDOWN_MS);
        setCooldownLeft(Math.ceil(PHONE_EDIT_COOLDOWN_MS / 1000));
      }
    } else if (result.reason === "cooldown") {
      const secs = Math.ceil(result.cooldownMs / 1000);
      setPhoneError(`Please wait ${secs}s before changing again.`);
      setCooldownUntil(Date.now() + result.cooldownMs);
    } else if (result.reason === "limit_reached") {
      setPhoneError("Maximum changes reached for this reference.");
      setEditCount(PHONE_EDIT_MAX_CHANGES);
    } else {
      setPhoneError("Could not update. Please try again.");
    }
    setPhoneSaving(false);
  };

  const navigateToSuccess = (voucherCode: string) => {
    navigate({
      to: "/result",
      search: {
        status: "success",
        code: voucherCode,
        phone: localPhone || undefined,
        planId,
        method,
        price,
        transactionId,
      },
    });
  };

  // Poll + storage event for cashier confirmation
  useEffect(() => {
    if (!paymentReference) return;
    const checkStatus = () => {
      const stored = findByPaymentReference(paymentReference);
      if (!stored) return;
      if (stored.voidedAt || stored.redeemedAt) return;
      if (stored.confirmedAt && stored.code && syncState === "waiting") {
        setSyncState("processing");
        setTimeout(() => navigateToSuccess(stored.code), 800);
      }
    };
    const onStorage = (e: StorageEvent) => { if (e.key === "paywifi:vouchers:v2") checkStatus(); };
    window.addEventListener("storage", onStorage);
    const pollId = setInterval(checkStatus, 3000);
    checkStatus();
    return () => { window.removeEventListener("storage", onStorage); clearInterval(pollId); };
  }, [paymentReference, localPhone, planId, method, price, transactionId, syncState, navigate]);

  // A1: on expiry, auto-void and rebook
  const onRebook = () => {
    if (paymentReference) voidVoucher(paymentReference);
    navigate({ to: "/checkout", search: { plan: planId ?? "" } });
  };

  const onCheckPayment = async () => {
    if (inFlightRef.current || !paymentReference || checkCooldown > 0) return;
    inFlightRef.current = true;
    setConfirming(true);
    setConfirmError(null);
    await new Promise((r) => setTimeout(r, 600));
    const stored = findByPaymentReference(paymentReference);
    const reset = (msg: string) => {
      setConfirmError(msg);
      setConfirming(false);
      inFlightRef.current = false;
      setCheckCooldown(5); // R6: 5-second cooldown
    };
    if (!stored) return reset("Payment reference could not be found.");
    if (stored.voidedAt) return reset("This payment was cancelled.");
    if (stored.redeemedAt) return reset("This voucher was already redeemed.");
    // A1: expiry detected — auto-rebook
    if (stored.expiresAt && !stored.confirmedAt && Date.now() >= stored.expiresAt) {
      voidVoucher(paymentReference);
      setConfirming(false);
      inFlightRef.current = false;
      navigate({ to: "/checkout", search: { plan: planId ?? "" } });
      return;
    }
    if (!stored.confirmedAt || !stored.code)
      return reset("Payment not yet confirmed by the cashier. Please complete payment at the counter first.");
    navigate({
      to: "/result",
      search: { status: "success", code: stored.code, phone: localPhone || undefined, planId, method, price, transactionId },
    });
  };

  if (syncState === "processing") {
    return (
      <ResultShell brandName={brand.name} title="Payment confirmed!">
        <div className="flex-1 flex flex-col items-center justify-center text-center">
          <Loader2 className="h-20 w-20 text-success animate-spin" />
          <p className="mt-6 text-xl font-bold text-success">Payment confirmed!</p>
          <p className="mt-2 text-base text-muted-foreground px-4">Activating your voucher...</p>
        </div>
      </ResultShell>
    );
  }

  // B1: expired state — show rebook CTA instead of normal screen
  if (expired) {
    return (
      <ResultShell
        brandName={brand.name}
        title="Reference expired"
        footer={
          <>
            <Button onClick={onRebook} className="w-full h-16 text-lg font-bold rounded-2xl">
              <ArrowRight className="h-5 w-5 mr-2" />Rebook same plan
            </Button>
            <Link to="/plans" className="w-full text-center py-2 text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors">
              Choose a different plan
            </Link>
          </>
        }
      >
        <div className="flex-1 flex flex-col items-center justify-center text-center px-2 gap-4">
          <div className="h-20 w-20 rounded-full bg-amber-500/10 flex items-center justify-center">
            <Timer className="h-12 w-12 text-amber-500" strokeWidth={2} />
          </div>
          <div>
            <p className="text-xl font-bold">Payment reference expired</p>
            <p className="mt-2 text-base text-muted-foreground leading-snug">
              Your 15-minute window has passed. Start a fresh payment for the same plan.
            </p>
          </div>
        </div>
      </ResultShell>
    );
  }

  // B1: countdown display helper
  const countdownMins = Math.floor(timeLeft / 60000);
  const countdownSecs = Math.floor((timeLeft % 60000) / 1000);
  const countdownStr = `${countdownMins}:${String(countdownSecs).padStart(2, "0")}`;
  const countdownUrgent = timeLeft > 0 && timeLeft < 3 * 60 * 1000; // < 3 min = red

  return (
    <ResultShell
      brandName={brand.name}
      title="Pay at the counter"
      footer={
        <>
          <p className="text-xs text-muted-foreground text-center leading-snug px-2">
            Once you have paid at the counter, tap the button below to receive your voucher.
          </p>
          <Button
            onClick={onCheckPayment}
            disabled={confirming || checkCooldown > 0}
            className="w-full h-16 text-lg font-bold rounded-2xl"
          >
            {confirming
              ? <><Loader2 className="h-5 w-5 mr-2 animate-spin" /> Checking payment...</>
              : checkCooldown > 0
                ? <>Wait {checkCooldown}s...</>
                : <><ArrowRight className="h-5 w-5 mr-2" /> I have paid — get my voucher</>
            }
          </Button>
          <Button
            variant="secondary"
            onClick={() => {
              if (paymentReference) {
                const voided = voidVoucher(paymentReference);
                if (!voided) {
                  const current = findByPaymentReference(paymentReference);
                  if (current?.confirmedAt && current.code) {
                    navigate({ to: "/result", search: { status: "success", code: current.code, planId, method, price, transactionId } });
                    return;
                  }
                }
              }
              navigate({ to: "/plans" });
            }}
            className="w-full h-14 text-base font-semibold rounded-2xl border-2 border-border text-muted-foreground"
          >
            Cancel this payment
          </Button>
        </>
      }
    >
      {/* Amount due */}
      <div className="w-full rounded-2xl border-2 border-primary bg-primary/5 p-4 text-center">
          <p className="text-xs font-bold uppercase tracking-widest text-primary mb-1">Amount due</p>
          <p className="text-5xl font-black text-primary tracking-tight">
            {typeof price === "number" ? formatPHP(price) : "..."}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">Pay this exact amount in cash at the counter</p>
        </div>

        {/* Store location */}
        {store && (
          <div className="w-full rounded-2xl border-2 border-border bg-card p-3 flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <MapPin className="h-4 w-4 text-primary" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Pay in person at</p>
              <p className="text-base font-bold text-foreground">{store.name}</p>
              <p className="text-sm text-muted-foreground">{store.address}</p>
            </div>
          </div>
        )}

        {/* Payment reference card — QR top, number below */}
        {paymentReference && (
          <div className="w-full rounded-2xl border-2 border-primary/30 bg-primary/5 p-4 text-center min-w-0 overflow-hidden">
            <p className="text-xs uppercase tracking-wider text-primary font-semibold">
              Payment reference
            </p>
            <div className="mt-2 flex justify-center">
              <div className="rounded-xl bg-white p-2 border-2 border-border">
                <QrCode value={paymentReference} size={128} ariaLabel={`Payment reference ${paymentReference}`} />
              </div>
            </div>
            <p className="mt-2 font-mono font-bold text-lg break-all tracking-wider">
              {paymentReference}
            </p>
            {timeLeft > 0 && (
              <p className={`text-xs font-semibold mt-1 ${countdownUrgent ? "text-destructive" : "text-muted-foreground"}`}>
                <Timer className="inline h-3 w-3 mr-1" />
                Expires in {countdownStr}
              </p>
            )}
          </div>
        )}

        {/* B4: compact phone row */}
        <div className="w-full rounded-2xl border-2 border-border bg-card shrink-0">
          {editingPhone ? (
            <div className="p-3 flex flex-col gap-2">
              <div className="flex gap-2">
                <Input
                  value={draftPhone}
                  onChange={(e) => setDraftPhone(e.target.value.replace(/\D/g, "").slice(0, 15))}
                  placeholder="Phone number"
                  inputMode="tel"
                  autoFocus
                  className="h-11 text-base bg-input border-2 border-border rounded-xl px-3 flex-1"
                />
                <Button onClick={onSavePhone} disabled={phoneSaving} className="h-11 px-4 rounded-xl text-sm font-bold shrink-0">
                  {phoneSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}
                </Button>
                <Button variant="secondary" onClick={() => setEditingPhone(false)} className="h-11 px-3 rounded-xl border-2 border-border shrink-0">
                  <CloseIcon className="h-4 w-4" />
                </Button>
              </div>
              {phoneError && <p className="text-xs font-semibold text-destructive px-1">{phoneError}</p>}
            </div>
          ) : (
            <div className="px-4 py-3 flex items-center gap-3">
              <MessageSquare className="h-4 w-4 text-muted-foreground shrink-0" />
              <div className="min-w-0 flex-1">
                <p className="text-sm text-muted-foreground leading-snug truncate">
                  {localPhone
                    ? <>SMS to <span className="text-foreground font-bold">{localPhone}</span></>
                    : <span className="italic">No phone — tap to add</span>}
                </p>
                {isCooldown && (
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Edit again in <span className="font-semibold">{cooldownLeft}s</span>
                    {" "}({editsRemaining} left)
                  </p>
                )}
              </div>
              <button
                onClick={onOpenEdit}
                disabled={!canOpenEdit}
                aria-label="Edit phone number"
                className="h-8 w-8 rounded-lg flex items-center justify-center border border-border bg-background hover:border-primary transition-colors shrink-0 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                {isLimitReached ? <Lock className="h-3.5 w-3.5" /> : <Pencil className="h-3.5 w-3.5" />}
              </button>
            </div>
          )}
        </div>

      {confirmError && (
        <div role="alert" className="rounded-2xl border-2 border-destructive/30 bg-destructive/5 p-3 flex items-start gap-2">
          <AlertCircle className="h-4 w-4 text-destructive shrink-0 mt-0.5" />
          <p className="text-sm font-semibold text-destructive leading-snug">{confirmError}</p>
        </div>
      )}
    </ResultShell>
  );
}

// Local close icon used in the phone-edit cancel button.
// Named CloseIcon to avoid shadowing the lucide XCircle import above.
function CloseIcon({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className={className}>
      <circle cx="12" cy="12" r="10" />
      <line x1="15" y1="9" x2="9" y2="15" />
      <line x1="9" y1="9" x2="15" y2="15" />
    </svg>
  );
}

// ─── Method labels ─────────────────────────────────────────────────────────────
const METHOD_LABEL: Record<string, string> = {
  // Legacy methods
  gcash: "GCash",
  qrph:  "QR PH",
  maya:  "Maya",
  cash:  "Cash at counter",
  // Xendit channel IDs (uppercase) — derived from XENDIT_CHANNELS catalog
  ...Object.fromEntries(XENDIT_CHANNELS.map((c) => [c.id, c.label])),
};

// ─── Success view ─────────────────────────────────────────────────────────────
function SuccessView({
  code: initialCode, phone, method, brandName, plan, transactionId,
}: {
  code: string | undefined;
  phone: string | undefined;
  method: PaymentMethod | undefined;
  brandName: string;
  plan: ReturnType<typeof getPlan>;
  transactionId: string | undefined;
}) {
  const [copied, setCopied] = useState(false);
  const [canShare, setCanShare] = useState(false);
  // B3: QR toggle
  const [showQr, setShowQr] = useState(false);
  // Voucher-activation checkbox — checked by default
  const [activateOnBrowse, setActivateOnBrowse] = useState(true);

  // For Xendit-redirect path: code arrives via URL param. If absent, auto-issue.
  const [code, setCode] = useState<string | undefined>(initialCode);
  const [issuing, setIssuing] = useState(!initialCode && !!plan);

  useEffect(() => {
    if (initialCode || !plan || !transactionId) {
      // Either we already have the code (issued by polling) or there's no
      // transaction to look up (legacy redirect with insufficient params).
      // If we have a code but no transaction id, just stop the spinner.
      if (initialCode) setIssuing(false);
      return;
    }
    // No code in URL — Xendit redirected us here without one. Resolve via
    // the idempotent server fn: if the webhook already issued a voucher
    // for this transactionId, we get it back; otherwise the server issues
    // one now. Crucially this does NOT deduct operator credits — the
    // customer paid Xendit.
    let cancelled = false;
    setIssuing(true);
    void handleXenditPaymentSuccess({
      data: { system_id: getSystemId(), transaction_id: transactionId },
    }).then((res) => {
      if (cancelled) return;
      if (res.ok && "code" in res) setCode(res.code);
      setIssuing(false);
    }).catch(() => {
      if (!cancelled) setIssuing(false);
    });
    return () => { cancelled = true; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    setCanShare(typeof navigator !== "undefined" && typeof navigator.share === "function");
  }, []);

  useEffect(() => {
    if (initialCode && transactionId) clearPendingDigitalPayment(transactionId);
  }, [transactionId, initialCode]);

  const onCopy = () => {
    if (!code) return;
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const onShare = async () => {
    if (!code) return;
    if (!canShare) { onCopy(); return; }
    try {
      await navigator.share({ title: `${brandName} WiFi voucher`, text: `Your WiFi voucher code: ${code}` });
    } catch { /* user cancelled */ }
  };

  const onStartBrowsing = (e: React.MouseEvent<HTMLAnchorElement>) => {
    trackEvent("start_browsing", { source: "result" });
    if (code && activateOnBrowse) void redeemVoucher(code);
    void e;
  };

  const methodLabel = method ? (METHOD_LABEL[method as string] ?? method) : undefined;

  // While auto-issuing a voucher after Xendit redirect, show a spinner
  if (issuing) {
    return (
      <ResultShell brandName={brandName} title="Activating your voucher…">
        <div className="flex-1 flex flex-col items-center justify-center text-center gap-4">
          <Loader2 className="h-20 w-20 text-primary animate-spin" />
          <div>
            <p className="text-xl font-bold text-success">Payment confirmed!</p>
            <p className="mt-2 text-base text-muted-foreground">Generating your WiFi voucher…</p>
          </div>
        </div>
      </ResultShell>
    );
  }

  return (
    <ResultShell
      brandName={brandName}
      title="You are online!"
      footer={
        <>
          <label className="flex items-center gap-2.5 px-1 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={activateOnBrowse}
              onChange={(e) => setActivateOnBrowse(e.target.checked)}
              className="h-4 w-4 rounded border-border accent-primary shrink-0 cursor-pointer"
            />
            <p className="text-xs text-muted-foreground leading-snug">
              This will activate your voucher on this device
            </p>
          </label>
          <a href="https://www.google.com" onClick={onStartBrowsing} className="block">
            <Button className="w-full h-16 text-lg font-bold rounded-2xl">Start browsing</Button>
          </a>
        </>
      }
    >
      <p className="text-xl font-bold text-success flex items-center justify-center gap-2 text-center">
        <CheckCircle2 className="h-7 w-7" strokeWidth={2.5} />
        Payment received
      </p>
      {methodLabel && (
        <p className="text-sm text-muted-foreground text-center">
          Paid via <span className="font-semibold text-foreground">{methodLabel}</span>
        </p>
      )}

      {code && phone && (() => {
        const q = getQueuedTimeForPhone(phone);
        // Don't bother showing the card if nothing is queued or active.
        if (q.totalMinutes <= 0) return null;
        const fmtMins = (m: number) => {
          if (m < 60) return `${m} min`;
          const h = Math.floor(m / 60);
          const r = m % 60;
          return r === 0 ? `${h} hr` : `${h} hr ${r} min`;
        };
        return (
          <div className="w-full rounded-2xl border-2 border-primary/30 bg-primary/5 p-3 text-center min-w-0">
            <p className="text-xs font-semibold uppercase tracking-wider text-primary">
              Total time available
            </p>
            <p className="mt-0.5 text-lg font-bold tabular-nums">{fmtMins(q.totalMinutes)}</p>
            {q.activeMinutes > 0 && q.queuedMinutes > 0 && (
              <p className="mt-0.5 text-xs text-muted-foreground">
                {fmtMins(q.activeMinutes)} active + {fmtMins(q.queuedMinutes)} queued
              </p>
            )}
            {q.activeMinutes === 0 && q.queuedMinutes > 0 && (
              <p className="mt-0.5 text-xs text-muted-foreground">All queued — starts when you redeem</p>
            )}
          </div>
        );
      })()}
      {code && (
        <div className="w-full rounded-2xl border-2 border-border bg-secondary/60 p-4 text-center min-w-0 overflow-hidden">
          <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-3">Your voucher code</p>
          <p className="font-mono font-black text-4xl tracking-[0.2em] break-all leading-tight text-foreground">
            {code}
          </p>
          {plan && (
            <div className="mt-2 flex justify-center">
              <PlanDuration plan={plan} />
            </div>
          )}
          <button
            onClick={() => setShowQr((v) => !v)}
            className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors"
          >
            {showQr ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
            {showQr ? "Hide QR code" : "Show QR code"}
          </button>
          {showQr && (
            <div className="mt-2 flex justify-center">
              <div className="rounded-xl bg-white p-2 border-2 border-border">
                <QrCode value={code} size={120} ariaLabel={`Voucher code ${code}`} />
              </div>
            </div>
          )}
          <div className="mt-3 flex items-center justify-center gap-2 flex-wrap">
            <button              onClick={onCopy}
              className="inline-flex items-center gap-2 h-11 px-4 rounded-xl text-sm font-semibold bg-card border-2 border-border hover:border-primary transition whitespace-nowrap"
            >
              {copied ? <Check className="h-4 w-4 text-success" /> : <Copy className="h-4 w-4" />}
              {copied ? "Copied!" : "Copy code"}
            </button>
            {canShare && (
              <button
                onClick={onShare}
                className="inline-flex items-center gap-2 h-11 px-4 rounded-xl text-sm font-semibold bg-card border-2 border-border hover:border-primary transition whitespace-nowrap"
              >
                <Share2 className="h-4 w-4" />
                Share
              </button>
            )}
          </div>
        </div>
      )}

      {phone && (
        <div className="w-full rounded-2xl border-2 border-border bg-secondary/60 p-3 flex items-center gap-3 min-w-0">
          <Check className="h-4 w-4 text-success shrink-0" strokeWidth={3} />
          <p className="text-sm text-muted-foreground min-w-0 flex-1 truncate">
            Receipt sent to <span className="text-foreground font-bold">{phone}</span>
          </p>
        </div>
      )}
    </ResultShell>
  );
}
