import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { getAllVouchers } from "@/lib/portal-api";
import type { StoredVoucher } from "@/lib/mock-store";
import { BRAND, useBrand } from "@/lib/brand";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Coins, RefreshCw, ShieldAlert, ScanLine } from "lucide-react";
import { PendingPaymentsList } from "@/components/operator/PendingPaymentsList";
import { ConfirmPaymentDialog } from "@/components/operator/ConfirmPaymentDialog";
import { SalesDashboard } from "@/components/operator/SalesDashboard";
import { CreditPanel } from "@/components/operator/CreditPanel";
import { getCreditRecord } from "@/lib/portal-api";

export const Route = createFileRoute("/operator")({
  head: () => ({ meta: [{ title: `Operator — ${BRAND}` }] }),
  component: Operator,
});

type OperatorTab = "pending" | "sales" | "credits";

/**
 * Dedicated operator page. Two tabs:
 *
 *   • Pending Payments — queue of unconfirmed CASH payment references.
 *     Tapping **Proceed Payment** on a row opens the ConfirmPaymentDialog,
 *     which is the *only* path to voucher generation on this page.
 *     There's no standalone GenerateVoucher form here (per the spec —
 *     manual standalone issuance lives on /admin).
 *
 *   • Sales Dashboard — today's revenue + count, plus a recent-sales
 *     list (confirmed cash + admin-issued).
 *
 * ─── Auth ────────────────────────────────────────────────────────────
 * TODO(live): like /admin, this route is currently OPEN. Operators
 * should be gated by their own staff session at milestone #1 — and
 * "own sales" on the dashboard should filter by that operator's id.
 * ────────────────────────────────────────────────────────────────────
 */
function Operator() {
  const brand = useBrand();
  const [tab, setTab] = useState<OperatorTab>("pending");
  const [refreshKey, setRefreshKey] = useState(0);
  const [data, setData] = useState<StoredVoucher[] | null>(null);
  /** Payment currently being processed in the dialog; null = closed. */
  const [activePayment, setActivePayment] = useState<StoredVoucher | null>(null);
  const [creditBalance, setCreditBalance] = useState<number | null>(null);

  const refresh = () => setRefreshKey((k) => k + 1);

  useEffect(() => {
    void (async () => {
      const [vouchers, creditRec] = await Promise.all([getAllVouchers(), getCreditRecord()]);
      setData(vouchers);
      setCreditBalance(creditRec.balance);
    })();
  }, [refreshKey]);

  // Filter the loaded list into the queue. Memoised so we don't re-walk
  // the array on every tab switch.
  const { pending } = useMemo(() => {
    if (!data) return { pending: [] as StoredVoucher[] };
    const now = Date.now();
    const pendingList = data.filter((v) => {
      if (!v.paymentReference) return false;
      if (v.confirmedAt) return false;
      if (v.voidedAt) return false;
      if (v.redeemedAt) return false;
      if (v.expiresAt && v.expiresAt <= now) return false;
      return true;
    });
    return { pending: pendingList };
  }, [data]);

  const onSelectPending = (payment: StoredVoucher) => {
    setActivePayment(payment);
  };

  const onCloseDialog = (didProcess: boolean) => {
    setActivePayment(null);
    if (didProcess) refresh();
  };

  return (
    <div className="min-h-dvh w-full bg-background safe-x">
      <div className="mx-auto w-full max-w-3xl safe-top pt-4 pb-8">
        {/* Header ------------------------------------------------------- */}
        <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div className="min-w-0">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary truncate flex items-center gap-2">
              <ScanLine className="h-3.5 w-3.5" />
              {brand.name} · Operator
            </p>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight leading-tight mt-1">
              Cash payment desk
            </h1>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Link to="/">
              <Button
                variant="secondary"
                className="h-10 px-3 rounded-xl text-sm font-semibold border-2 border-border"
              >
                <ArrowLeft className="h-4 w-4 mr-1" />
                Portal
              </Button>
            </Link>
            <Button
              onClick={refresh}
              variant="secondary"
              className="h-10 px-3 rounded-xl text-sm font-semibold border-2 border-border"
            >
              <RefreshCw className="h-4 w-4 mr-1" />
              Refresh
            </Button>
          </div>
        </header>

        {/* DEMO MODE warning — same pattern as /admin. */}
        <div
          role="status"
          className="mb-4 rounded-xl border-2 border-destructive/30 bg-destructive/5 p-3 flex items-start gap-2"
        >
          <ShieldAlert className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
          <p className="text-sm text-muted-foreground min-w-0">
            <span className="font-bold text-destructive uppercase tracking-wider text-xs block">
              Demo mode — no auth
            </span>
            Operator pages should be gated server-side by a staff session
            scoped narrower than admin. See <code>TODO(live)</code> in{" "}
            <code>src/routes/operator.tsx</code>.
          </p>
        </div>

        {/* Tab navigation ---------------------------------------------- */}
        <div
          role="tablist"
          aria-label="Operator sections"
          className="flex gap-1 p-1 rounded-xl bg-secondary/50 mb-4"
        >
          <button
            role="tab"
            type="button"
            aria-selected={tab === "pending"}
            onClick={() => setTab("pending")}
            className={`flex-1 h-11 rounded-lg font-semibold text-sm transition-colors flex items-center justify-center gap-2 ${
              tab === "pending"
                ? "bg-card text-foreground shadow-sm border border-border"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Pending payments
            {pending.length > 0 && (
              <span
                className={`min-w-[1.25rem] h-5 px-1.5 rounded-full text-xs font-bold flex items-center justify-center ${
                  tab === "pending"
                    ? "bg-primary text-primary-foreground"
                    : "bg-foreground/10"
                }`}
              >
                {pending.length}
              </span>
            )}
          </button>
          <button
            role="tab"
            type="button"
            aria-selected={tab === "sales"}
            onClick={() => setTab("sales")}
            className={`flex-1 h-11 rounded-lg font-semibold text-sm transition-colors ${
              tab === "sales"
                ? "bg-card text-foreground shadow-sm border border-border"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Sales dashboard
          </button>
          <button
            role="tab"
            type="button"
            aria-selected={tab === "credits"}
            onClick={() => setTab("credits")}
            className={`flex-1 h-11 rounded-lg font-semibold text-sm transition-colors flex items-center justify-center gap-1.5 ${
              tab === "credits"
                ? "bg-card text-foreground shadow-sm border border-border"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Coins className="h-3.5 w-3.5" />
            Credits
            {creditBalance !== null && creditBalance < 50 && (
              <span className={`min-w-[1.25rem] h-5 px-1.5 rounded-full text-xs font-bold flex items-center justify-center tabular-nums ${
                tab === "credits" ? "bg-amber-500 text-white" : "bg-amber-500/20 text-amber-700"
              }`}>
                !
              </span>
            )}
          </button>
        </div>

        {/* Tab panels --------------------------------------------------- */}
        {tab === "credits" ? (
          <CreditPanel />
        ) : !data ? (
          <p className="text-sm text-muted-foreground text-center py-12">Loading…</p>
        ) : tab === "pending" ? (
          <PendingPaymentsList
            pendingPayments={pending}
            onSelectPayment={onSelectPending}
          />
        ) : (
          <SalesDashboard vouchers={data} />
        )}
      </div>
      <div className="safe-bottom" />

      {/* Confirmation dialog — mounted at root so it overlays everything */}
      {activePayment && (
        <ConfirmPaymentDialog
          payment={activePayment}
          onClose={onCloseDialog}
        />
      )}
    </div>
  );
}
