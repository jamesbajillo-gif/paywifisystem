import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, useMemo } from "react";
import {
  getAllVouchers,
  getActiveSessions,
  getFunnelStats,
  getRefunds,
} from "@/lib/portal-api";
import type { StoredVoucher } from "@/lib/mock-store";
import type { FunnelStats } from "@/lib/analytics";
import { BRAND, useBrand } from "@/lib/brand";
import { Button } from "@/components/ui/button";
import { ArrowLeft, RefreshCw, Settings, ShieldAlert, LayoutDashboard, RotateCcw, CreditCard } from "lucide-react";
import { StatsBar } from "@/components/admin/StatsBar";
import { GenerateVoucher } from "@/components/admin/GenerateVoucher";
import { VoucherTable } from "@/components/admin/VoucherTable";
import { FunnelChart } from "@/components/admin/FunnelChart";
import { PaymentAttemptsCard } from "@/components/admin/PaymentAttemptsCard";
import { DemoControls } from "@/components/admin/DemoControls";
import { RefundManagement } from "@/components/admin/RefundManagement";
import { PaymentSettings } from "@/components/admin/PaymentSettings";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: `Admin — ${BRAND}` }] }),
  component: Admin,
});

type AdminTab = "dashboard" | "refunds" | "payment";

function Admin() {
  const brand = useBrand();
  const [tab, setTab] = useState<AdminTab>("dashboard");
  const [refreshKey, setRefreshKey] = useState(0);
  const [data, setData] = useState<{
    vouchers: StoredVoucher[];
    activeSessions: StoredVoucher[];
    funnel: FunnelStats;
  } | null>(null);
  const [pendingRefundCount, setPendingRefundCount] = useState(0);

  const refresh = () => setRefreshKey((k) => k + 1);

  useEffect(() => {
    void (async () => {
      const [vouchers, activeSessions, refunds] = await Promise.all([
        getAllVouchers(),
        getActiveSessions(),
        getRefunds(),
      ]);
      setData({ vouchers, activeSessions, funnel: getFunnelStats() });
      setPendingRefundCount(refunds.filter((r) => r.status === "pending").length);
    })();
  }, [refreshKey]);

  const todayStats = useMemo(() => {
    if (!data) return { revenue: 0, vouchers: 0 };
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);
    const since = startOfToday.getTime();
    const todayFunnel = getFunnelStats({ sinceTimestamp: since });
    const todayVouchers = data.vouchers.filter((v) => v.issuedAt >= since);
    return { revenue: todayFunnel.total_revenue, vouchers: todayVouchers.length };
  }, [data]);

  return (
    <div className="min-h-dvh w-full bg-background">
      <div className="mx-auto w-full max-w-5xl px-4 sm:px-6 safe-top pt-5 pb-10">

        {/* Header */}
        <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div className="min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <LayoutDashboard className="h-4 w-4 text-primary shrink-0" />
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary truncate">
                {brand.name} · Admin
              </p>
            </div>
            <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Link to="/">
              <Button variant="secondary" className="h-10 px-3 rounded-xl text-sm font-semibold border-2 border-border gap-1.5">
                <ArrowLeft className="h-4 w-4" />
                Portal
              </Button>
            </Link>
            <Link to="/settings" search={{ role: "admin" }}>
              <Button variant="secondary" className="h-10 px-3 rounded-xl text-sm font-semibold border-2 border-border gap-1.5">
                <Settings className="h-4 w-4" />
                Plans
              </Button>
            </Link>
            <Button
              onClick={refresh}
              variant="secondary"
              className="h-10 px-3 rounded-xl text-sm font-semibold border-2 border-border gap-1.5"
            >
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
          </div>
        </header>

        {/* Demo warning */}
        <div
          role="status"
          className="mb-5 rounded-xl border-2 border-destructive/30 bg-destructive/5 px-4 py-3 flex items-start gap-3"
        >
          <ShieldAlert className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
          <div className="min-w-0">
            <p className="text-xs font-bold text-destructive uppercase tracking-wider">Demo mode — no auth</p>
            <p className="text-sm text-muted-foreground mt-0.5">
              This route is open. Gate it server-side before going live.{" "}
              See <code className="text-xs">TODO(live)</code> in{" "}
              <code className="text-xs">src/routes/admin.tsx</code>.
            </p>
          </div>
        </div>

        {/* Tab navigation */}
        <div
          role="tablist"
          aria-label="Admin sections"
          className="flex gap-1 p-1 rounded-xl bg-secondary/50 mb-5"
        >
          <button
            role="tab"
            type="button"
            aria-selected={tab === "dashboard"}
            onClick={() => setTab("dashboard")}
            className={`flex-1 h-11 rounded-lg font-semibold text-sm transition-colors ${
              tab === "dashboard"
                ? "bg-card text-foreground shadow-sm border border-border"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Dashboard
          </button>
          <button
            role="tab"
            type="button"
            aria-selected={tab === "refunds"}
            onClick={() => setTab("refunds")}
            className={`flex-1 h-11 rounded-lg font-semibold text-sm transition-colors flex items-center justify-center gap-2 ${
              tab === "refunds"
                ? "bg-card text-foreground shadow-sm border border-border"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Refunds
            {pendingRefundCount > 0 && (
              <span className={`min-w-[1.25rem] h-5 px-1.5 rounded-full text-xs font-bold flex items-center justify-center ${
                tab === "refunds" ? "bg-amber-500 text-white" : "bg-amber-500/20 text-amber-700"
              }`}>
                {pendingRefundCount}
              </span>
            )}
          </button>
          <button
            role="tab"
            type="button"
            aria-selected={tab === "payment"}
            onClick={() => setTab("payment")}
            className={`flex-1 h-11 rounded-lg font-semibold text-sm transition-colors flex items-center justify-center gap-1.5 ${
              tab === "payment"
                ? "bg-card text-foreground shadow-sm border border-border"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <CreditCard className="h-3.5 w-3.5" />
            Payment
          </button>
        </div>

        {/* Tab panels */}
        {tab === "payment" ? (
          <PaymentSettings />
        ) : tab === "refunds" ? (
          <RefundManagement />
        ) : !data ? (
          <div className="flex items-center justify-center py-24">
            <p className="text-sm text-muted-foreground">Loading…</p>
          </div>
) : (
          <div className="flex flex-col gap-5">
            <StatsBar
              activeSessions={data.activeSessions.length}
              todayRevenue={todayStats.revenue}
              todayVouchersIssued={todayStats.vouchers}
              conversionRatePercent={data.funnel.conversion_rate_home_to_pay * 100}
            />

            <GenerateVoucher onIssued={refresh} />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              <VoucherTable vouchers={data.vouchers} />
              <FunnelChart stats={data.funnel} />
            </div>

            <PaymentAttemptsCard refreshKey={refreshKey} />
          </div>
        )}

        {import.meta.env.DEV && <DemoControls onChange={refresh} />}
      </div>
    </div>
  );
}
