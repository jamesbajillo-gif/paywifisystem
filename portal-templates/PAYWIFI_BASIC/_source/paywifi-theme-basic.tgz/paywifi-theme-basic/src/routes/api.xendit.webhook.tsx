/**
 * /api/xendit/webhook — TanStack Start API route receiving Xendit callbacks.
 *
 * All server-only logic (token verify, HMAC, replay protection, DB lookups,
 * voucher issuance) lives in `@/lib/api/xendit-webhook.server` so Vite
 * strips it from the client bundle. This file stays small enough that
 * including the tiny info-page component on the client costs nothing.
 */

import { createFileRoute } from "@tanstack/react-router";
import { handleXenditWebhookRequest } from "@/lib/api/xendit-webhook.server";

export const Route = createFileRoute("/api/xendit/webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => handleXenditWebhookRequest(request),
      GET: async () =>
        new Response(
          JSON.stringify({
            ok: true,
            service: "xendit-webhook",
            message: "POST Xendit payment callbacks here.",
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        ),
    },
  },
  component: WebhookInfo,
});

function WebhookInfo() {
  return (
    <div style={{ padding: "2rem", fontFamily: "system-ui", maxWidth: 640 }}>
      <h1>Xendit Webhook</h1>
      <p>This endpoint accepts <code>POST</code> requests from Xendit.</p>
      <p>Configure it in your Xendit dashboard under Settings → Webhooks.</p>
    </div>
  );
}
