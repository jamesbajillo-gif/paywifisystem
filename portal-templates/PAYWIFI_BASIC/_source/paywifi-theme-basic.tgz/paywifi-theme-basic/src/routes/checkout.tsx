import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState, useCallback } from "react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Loader2,
  Smartphone,
  QrCode,
  Wallet,
  Banknote,
  ShieldAlert,
  RefreshCw,
  X,
  ChevronDown,
  Store,
  Zap,
  CreditCard,
  Building2,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Clock,
} from "lucide-react";
import {
  getPlan,
  getPlans,
  processPayment,
  isLockedOut,
  getLockoutRemainingMs,
  recordFailedAttempt,
  clearAttempts,
  findPendingForVenue,
  voidVoucher,
  issueVoucher,
  recordPendingDigitalPayment,
  DIGITAL_PENDING_TTL_MS,
  type Plan,
  type PaymentMethod,
  type PlanId,
} from "@/lib/portal-api";
import type { StoredVoucher } from "@/lib/mock-store";
import { BRAND, useBrand } from "@/lib/brand";
import { formatPHP as fmt } from "@/lib/utils";
import { trackEvent } from "@/lib/analytics";
import { STORES } from "@/lib/stores";
import { getXenditConfig, getActiveXenditChannels, saveXenditConfig, XENDIT_CHANNELS, type XenditChannel } from "@/lib/xendit-client";
import { initiateXenditPayment, pollXenditPaymentStatusServer, getXenditConfigServer, handleXenditPaymentSuccess, handleXenditPaymentFailure } from "@/lib/api/payment.functions";
import { useDbStatus } from "@/components/DbStatusContext";
import { getSystemId } from "@/lib/supabase";

const search = z.object({ plan: z.string() });

export const Route = createFileRoute("/checkout")({
  validateSearch: search,
  head: () => ({ meta: [{ title: `Checkout — ${BRAND}` }] }),
  component: Checkout,
});

// Legacy method catalog for the built-in (non-Xendit) methods.
const LEGACY_METHOD_CATALOG: Record<
  PaymentMethod,
  { label: string; icon: typeof Smartphone }
> = {
  gcash: { label: "GCash", icon: Smartphone },
  qrph:  { label: "QR PH", icon: QrCode },
  maya:  { label: "Maya",  icon: Wallet },
  cash:  { label: "Cash",  icon: Banknote },
};

// Icon map for Xendit channels shown in the grid.
const XENDIT_ICON_MAP: Partial<Record<XenditChannel, typeof Smartphone>> = {
  GCASH:      Smartphone,
  PAYMAYA:    Wallet,
  SHOPEEPAY:  CreditCard,
  OVO:        CreditCard,
  DANA:       CreditCard,
  LINKAJA:    CreditCard,
  QRPH:       QrCode,
  QRIS:       QrCode,
  BPI:        Building2,
  BDO:        Building2,
  RCBC:       Building2,
  UNIONBANK:  Building2,
};

// A unified tile descriptor used in the payment grid.
type PaymentTile =
  | { kind: "legacy"; id: PaymentMethod; label: string; icon: typeof Smartphone }
  | { kind: "xendit"; id: XenditChannel; label: string; icon: typeof Smartphone };

/** Minimum gap between Pay button clicks. Stops double-tap races. */
const SUBMISSION_DEBOUNCE_MS = 2000;

function Checkout() {
  const { plan: planId } = Route.useSearch();
  const navigate = useNavigate();
  const brand = useBrand();

  // Resolve the plan defensively:
  //   1. Try the static catalog (instant render in the common case).
  //   2. If unknown id (e.g. admin added custom DB plans), fetch them.
  //   3. If still unknown after the fetch, navigate back to /plans.
  const [plan, setPlan] = useState<Plan | undefined>(() => getPlan(planId as PlanId));
  useEffect(() => {
    if (plan) return;
    let cancelled = false;
    getPlans().then((all) => {
      if (cancelled) return;
      const found = all.find((p) => p.id === (planId as PlanId));
      if (found) {
        setPlan(found);
      } else {
        // Unknown plan — bounce back to the plan picker so the user can choose.
        navigate({ to: "/plans" });
      }
    }).catch(() => {
      // DB unreachable + not in static catalog — send the user to /plans.
      if (!cancelled) navigate({ to: "/plans" });
    });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [planId]);

  // ── Payment tile resolution ─────────────────────────────────────────
  // Cash is ALWAYS the default and cannot be removed.
  // When Xendit is enabled with an active channel, ALL channels of the
  // same module type are shown (e.g. GCash → GCash + Maya + ShopeePay).
  // Falls back to legacy brand.activeEpayment when Xendit is off.
  const CASH_TILE: PaymentTile = { kind: "legacy", id: "cash", label: "Cash", icon: Banknote };
  const [tiles, setTiles] = useState<PaymentTile[]>([CASH_TILE]);

  useEffect(() => {
    let cancelled = false;

    const buildTiles = (cfg: ReturnType<typeof getXenditConfig>) => {
      const activeChannels = getActiveXenditChannels(cfg);
      if (cfg.enabled && activeChannels.length > 0) {
        const xenditTiles: PaymentTile[] = activeChannels.map((meta) => ({
          kind: "xendit",
          id: meta.id,
          label: meta.label,
          icon: XENDIT_ICON_MAP[meta.id] ?? CreditCard,
        }));
        // Cash is always appended last and cannot be removed
        setTiles([...xenditTiles, CASH_TILE]);
      } else {
        // Xendit disabled / no module selected — legacy e-payment + Cash
        const leg = brand.activeEpayment;
        setTiles([
          { kind: "legacy", id: leg, label: LEGACY_METHOD_CATALOG[leg].label, icon: LEGACY_METHOD_CATALOG[leg].icon },
          CASH_TILE,
        ]);
      }
    };

    // Render immediately from localStorage cache for instant UI,
    // then sync from DB so admin changes to channel/enabled propagate.
    const cached = getXenditConfig();
    buildTiles(cached);

    getXenditConfigServer({ data: { system_id: getSystemId() } })
      .then((remote) => {
        if (cancelled) return;
        // Merge DB truth into the local cache (keep apiKey/webhookToken local
        // since the server returns a masked key).
        const merged = {
          ...cached,
          enabled: remote.enabled,
          activeChannel: remote.activeChannel,
          webhookToken: remote.webhookToken || cached.webhookToken,
        };
        saveXenditConfig(merged);
        buildTiles(merged);
      })
      .catch(() => { /* DB offline — stay with cached values */ });

    return () => { cancelled = true; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [brand.activeEpayment]);

  // Selected tile — Cash is the default (always available, cannot be disabled)
  const [selectedTileId, setSelectedTileId] = useState<string>("cash");

  const selectedTile = tiles.find((t) => t.id === selectedTileId) ?? tiles[0];
  const isCash = selectedTile?.id === "cash";
  const isXendit = selectedTile?.kind === "xendit";

  const [processing, setProcessing] = useState(false);
  const [storeId, setStoreId] = useState<string>("");

  // ── Xendit in-app payment sheet state ────────────────────────────────
  type XenditSheetState = {
    open: boolean;
    paymentRequestId: string;
    transactionId: string;
    redirectUrl: string;       // deep-link or QR URL from Xendit
    channelLabel: string;
    channelType: "EWALLET" | "QR_CODE" | "ONLINE_BANKING";
    planId: string;
    amount: number;
    pollStatus: "polling" | "success" | "failed" | "timeout";
    pollError?: string;
  };
  /** Session-scoped storage key for the active payment wizard. Survives
   *  page reload, captive-portal reconnect, and back-nav. Cleared on
   *  terminal states (success / failure / cancel) and on TTL expiry. */
  const XENDIT_SHEET_STORAGE_KEY = "paywifi:xendit-sheet";
  const XENDIT_SHEET_TTL_MS = 3 * 60 * 1000; // matches MAX_POLL_ATTEMPTS window

  type StoredXenditSheet = XenditSheetState & { expiresAt: number; planIdSearch: string };

  const readStoredSheet = (): StoredXenditSheet | null => {
    if (typeof window === "undefined") return null;
    try {
      const raw = window.sessionStorage.getItem(XENDIT_SHEET_STORAGE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as StoredXenditSheet;
      if (!parsed || typeof parsed !== "object") return null;
      if (Date.now() >= parsed.expiresAt) {
        window.sessionStorage.removeItem(XENDIT_SHEET_STORAGE_KEY);
        return null;
      }
      // Only restore if it belongs to the same plan that the URL says we're on.
      // (Refreshing /checkout?plan=hour shouldn't pop up a /checkout?plan=day sheet.)
      if (parsed.planIdSearch !== planId) {
        return null;
      }
      return parsed;
    } catch {
      return null;
    }
  };

  const persistSheet = (sheet: XenditSheetState | null) => {
    if (typeof window === "undefined") return;
    try {
      if (sheet === null) {
        window.sessionStorage.removeItem(XENDIT_SHEET_STORAGE_KEY);
      } else {
        const stored: StoredXenditSheet = {
          ...sheet,
          expiresAt: Date.now() + XENDIT_SHEET_TTL_MS,
          planIdSearch: planId as string,
        };
        window.sessionStorage.setItem(XENDIT_SHEET_STORAGE_KEY, JSON.stringify(stored));
      }
    } catch { /* storage unavailable */ }
  };

  // Hydrate the sheet from sessionStorage on first render. If a valid
  // pending sheet exists, reopen it in "polling" state so the existing
  // polling effect resumes automatically.
  const [xenditSheet, setXenditSheet] = useState<XenditSheetState | null>(() => {
    const stored = readStoredSheet();
    if (!stored) return null;
    // Force back into "polling" state on rehydrate — if the payment already
    // succeeded or failed, the next poll tick will discover that and update
    // the UI within ~3 s.
    return { ...stored, pollStatus: "polling" };
  });
  const pollTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const pollCountRef = useRef(0);
  const MAX_POLL_ATTEMPTS = 60; // 60 × 3 s = 3 min timeout

  // Stable expiry timestamp — captured the moment a sheet opens (or on
  // rehydrate, read from the persisted record). Without this the countdown
  // appears to "reset" on every render.
  const xenditSheetExpiresAtRef = useRef<number>(Date.now() + XENDIT_SHEET_TTL_MS);
  useEffect(() => {
    if (xenditSheet?.open) {
      // Try to read the persisted expiresAt; if missing, anchor it now.
      try {
        const raw = typeof window !== "undefined"
          ? window.sessionStorage.getItem(XENDIT_SHEET_STORAGE_KEY)
          : null;
        if (raw) {
          const parsed = JSON.parse(raw) as { expiresAt?: number };
          if (typeof parsed.expiresAt === "number" && parsed.expiresAt > Date.now()) {
            xenditSheetExpiresAtRef.current = parsed.expiresAt;
            return;
          }
        }
      } catch { /* ignore */ }
      xenditSheetExpiresAtRef.current = Date.now() + XENDIT_SHEET_TTL_MS;
    }
  }, [xenditSheet?.paymentRequestId, xenditSheet?.open]);
  const xenditSheetExpiresAt = xenditSheetExpiresAtRef.current;

  // Phone persisted in sessionStorage so it survives plan changes and back-nav.
  const PHONE_KEY = "paywifi:customer-phone";
  const [phone, setPhone] = useState<string>(() => {
    try { return window.sessionStorage.getItem(PHONE_KEY) ?? ""; } catch { return ""; }
  });
  const onPhoneChange = (value: string) => {
    setPhone(value);
    try { window.sessionStorage.setItem(PHONE_KEY, value); } catch { /* ignore */ }
  };

  // Persist active sheet to sessionStorage on every change so a refresh
  // or captive-portal reconnect rehydrates it.
  useEffect(() => { persistSheet(xenditSheet); }, [xenditSheet]);

  // ─── Abuse protection state ──────────────────────────────────────────
  // Lockout (item 1): ms remaining on the 3-strike cooldown for this venue+plan.
  const [lockoutMs, setLockoutMs] = useState(0);
  // Pending reference (item 4): existing unredeemed CASH-* voucher we can resume.
  const [pending, setPending] = useState<StoredVoucher | undefined>(undefined);
  // Submission lock (item 2): in-flight + last-submit refs prevent double-tap.
  const inFlightRef = useRef(false);
  const lastSubmitAtRef = useRef(0);
  const formRef = useRef<HTMLFormElement>(null);
  const { status: dbStatus } = useDbStatus();
  const dbOnline = dbStatus === "online";

  // When tiles reload and the selected tile is no longer in the list, fall back to Cash.
  useEffect(() => {
    if (tiles.length > 0 && !tiles.find((t) => t.id === selectedTileId)) {
      setSelectedTileId("cash");
    }
  }, [tiles, selectedTileId]);

  // Initial protection read — refreshed on venue change too, so a sticky
  // sessionStorage venue picked up post-hydration is honoured.
  useEffect(() => {
    setLockoutMs(getLockoutRemainingMs(brand.slug, planId));
    void findPendingForVenue(brand.slug).then(setPending);
  }, [brand.slug, planId]);

  // Tick the lockout countdown. Re-reads every second so the banner shows
  // accurate time-remaining text and the user gets a smooth "now unlocked"
  // transition when the timer hits 0.
  useEffect(() => {
    if (lockoutMs <= 0) return;
    const id = setInterval(() => {
      const remaining = getLockoutRemainingMs(brand.slug, planId);
      setLockoutMs(remaining);
    }, 1000);
    return () => clearInterval(id);
  }, [lockoutMs > 0, brand.slug, planId]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Plan must be resolved before we can act on it (handles the brief
    // window between mount and DB-backed plan fetch).
    if (!plan) return;

    // DB offline guard — block ALL payment/voucher operations when DB unreachable.
    if (!dbOnline) return;

    // Item 2 — submission lock. The Pay button is also disabled while
    // `processing` is true, but these refs are the source of truth: they
    // survive React batching and synthetic events that disable doesn't catch.
    if (inFlightRef.current) return;
    if (Date.now() - lastSubmitAtRef.current < SUBMISSION_DEBOUNCE_MS) return;

    // Item 5 — concurrent-pending check.
    if (isCash && pending && pending.paymentReference) {
      const existingPlan = getPlan(pending.planId);
      navigate({
        to: "/result",
        search: {
          status: "pending",
          paymentReference: pending.paymentReference,
          phone: pending.phone,
          planId: pending.planId,
          method: "cash",
          price: existingPlan?.price,
          transactionId: pending.transactionId,
          storeId: pending.storeId,
        },
      });
      return;
    }

    // Item 1 — defensive lockout re-check at submit time. Cash & Xendit
    // channels are exempt from the 3-strike guard.
    if (!isCash && !isXendit && isLockedOut(brand.slug, planId)) {
      setLockoutMs(getLockoutRemainingMs(brand.slug, planId));
      return;
    }

    inFlightRef.current = true;
    lastSubmitAtRef.current = Date.now();
    setProcessing(true);

    const methodLabel = selectedTile?.id ?? "unknown";
    trackEvent("checkout_submit", {
      planId: planId as PlanId,
      method: methodLabel as PaymentMethod,
      sms_requested: Boolean(phone),
    });

    try {
      // ── Xendit path ──────────────────────────────────────────────────
      if (isXendit && selectedTile?.kind === "xendit") {
        const transactionId = `TXN-${Date.now()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
        const origin = typeof window !== "undefined" ? window.location.origin : "";
        const xenditAmount = plan.price + (plan.epaymentFee ?? 0);
        const result = await initiateXenditPayment({
          data: {
            channel: selectedTile.id,
            amount: xenditAmount,
            referenceId: transactionId,
            // These URLs are fallback only — we poll in-app and never navigate there.
            successReturnUrl: `${origin}/result?status=success&planId=${planId}&method=${selectedTile.id}&transactionId=${transactionId}&price=${plan.price}${phone ? `&phone=${encodeURIComponent(phone)}` : ""}`,
            failureReturnUrl: `${origin}/result?status=failed&planId=${planId}&method=${selectedTile.id}&message=Payment+cancelled+or+failed`,
            phoneNumber: phone || undefined,
            metadata: { planId, venue: brand.slug },
            system_id: getSystemId(),
          },
        });

        if (result.ok) {
          // Persist the pending digital payment so the webhook can issue a
          // voucher even if the customer closes the tab before polling sees
          // SUCCEEDED. Pre-mints the voucher code so both webhook and polling
          // converge on the same value.
          const VOUCHER_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
          let payload = "";
          for (let i = 0; i < 12; i++) {
            payload += VOUCHER_ALPHABET[Math.floor(Math.random() * VOUCHER_ALPHABET.length)];
          }
          const preMintedCode = `${payload.slice(0, 4)}-${payload.slice(4, 8)}-${payload.slice(8, 12)}`;
          const persisted = await recordPendingDigitalPayment({
            transactionId,
            planId: planId as PlanId,
            method: selectedTile.id,
            venue: brand.slug,
            issuedAt: Date.now(),
            expiresAt: Date.now() + DIGITAL_PENDING_TTL_MS,
            code: preMintedCode,
          });
          if (!persisted.ok) {
            // DB unreachable — webhook will not know which system this
            // payment belongs to. Surface the failure rather than letting
            // the user pay and lose their voucher.
            navigate({
              to: "/result",
              search: {
                status: "failed",
                message: "We couldn't reserve your payment. Please try again in a moment.",
                planId,
                method: selectedTile.id as PaymentMethod,
              },
            });
            return;
          }

          // Open in-app payment wizard instead of redirecting to Xendit's page.
          const channelMeta = XENDIT_CHANNELS.find((c) => c.id === selectedTile.id);
          setXenditSheet({
            open: true,
            paymentRequestId: result.paymentRequestId,
            transactionId,
            redirectUrl: result.redirectUrl,
            channelLabel: channelMeta?.label ?? selectedTile.label,
            channelType: channelMeta?.type ?? "EWALLET",
            planId,
            amount: xenditAmount,
            pollStatus: "polling",
          });
          // Polling starts inside XenditPaymentSheet via useEffect
        } else {
          navigate({
            to: "/result",
            search: {
              status: "failed",
              message: result.error ?? "Payment could not be initiated. Please try again.",
              planId,
              method: selectedTile.id as PaymentMethod,
            },
          });
        }
        return;
      }

      // ── Legacy path (cash / built-in methods) ────────────────────────
      const legacyMethod = (selectedTile?.id ?? "cash") as PaymentMethod;
      const result = await processPayment({
        planId: planId as PlanId,
        method: legacyMethod,
        phone: phone || undefined,
        venue: brand.slug,
        storeId: isCash ? storeId || undefined : undefined,
      });

      if (result.ok) {
        clearAttempts(brand.slug, planId);
        if (isCash && "paymentReference" in result) {
          navigate({
            to: "/result",
            search: {
              status: "pending",
              paymentReference: result.paymentReference,
              phone: phone || undefined,
              planId,
              method: legacyMethod,
              price: plan.price,
              transactionId: result.transactionId,
              storeId: storeId || undefined,
            },
          });
        } else if ("code" in result) {
          navigate({
            to: "/result",
            search: {
              status: "success",
              code: result.code,
              phone: phone || undefined,
              planId,
              method: legacyMethod,
              price: plan.price,
              transactionId: result.transactionId,
            },
          });
        }
      } else {
        const state = recordFailedAttempt(brand.slug, planId);
        if (state.lockedUntil && state.lockedUntil > Date.now()) {
          setLockoutMs(state.lockedUntil - Date.now());
        } else {
          navigate({
            to: "/result",
            search: {
              status: "failed",
              message: result.message,
              planId,
              method: legacyMethod,
            },
          });
        }
      }
    } finally {
      inFlightRef.current = false;
      setProcessing(false);
    }
  };

  // Resume / cancel handlers for the pending banner.
  const onResume = () => {
    if (!pending || !pending.paymentReference) return;
    const existingPlan = getPlan(pending.planId);
    navigate({
      to: "/result",
      search: {
        status: "pending",
        paymentReference: pending.paymentReference,
        phone: pending.phone,
        planId: pending.planId,
        method: "cash",
        price: existingPlan?.price,
        transactionId: pending.transactionId,
      },
    });
  };

  const onCancelPending = () => {
    if (!pending || !pending.paymentReference) return;
    voidVoucher(pending.paymentReference);
    setPending(undefined);
  };

  // ── Xendit polling logic (runs when sheet opens) ──────────────────────
  const startXenditPolling = useCallback((paymentRequestId: string, transId: string, planIdStr: string, amount: number, channelId: string, phone_: string | undefined) => {
    if (pollTimerRef.current) clearInterval(pollTimerRef.current);
    pollCountRef.current = 0;

    const tick = async () => {
      pollCountRef.current += 1;
      if (pollCountRef.current > MAX_POLL_ATTEMPTS) {
        clearInterval(pollTimerRef.current!);
        setXenditSheet((s) => s ? { ...s, pollStatus: "timeout" } : s);
        return;
      }
      try {
        const rawRes = await pollXenditPaymentStatusServer({ data: { paymentRequestId, system_id: getSystemId() } });
        type PollResult = { ok: true; status: string } | { ok: false; error: string };
        const res = rawRes as PollResult;
        if (!res.ok) return; // transient error — keep polling
        const succeededStatus = res.ok && (res as { ok: true; status: string }).status;
        if (succeededStatus === "SUCCEEDED") {
          clearInterval(pollTimerRef.current!);
          setXenditSheet((s) => s ? { ...s, pollStatus: "success" } : s);
          // Idempotent — webhook may have already issued the voucher. The
          // server fn returns the existing code in that case (no double-issue,
          // no credit deduction since the customer already paid Xendit).
          try {
            const issued = await handleXenditPaymentSuccess({
              data: { system_id: getSystemId(), transaction_id: transId },
            });
            const voucherCode = (issued.ok && "code" in issued) ? issued.code : "";
            persistSheet(null);
            navigate({
              to: "/result",
              search: {
                status: "success",
                code: voucherCode,
                phone: phone_ || undefined,
                planId: planIdStr,
                method: channelId as PaymentMethod,
                price: amount,
                transactionId: transId,
              },
            });
          } catch {
            persistSheet(null);
            navigate({
              to: "/result",
              search: {
                status: "success",
                planId: planIdStr,
                method: channelId as PaymentMethod,
                price: amount,
                transactionId: transId,
              },
            });
          }
        } else if (succeededStatus === "FAILED" || succeededStatus === "VOIDED") {
          clearInterval(pollTimerRef.current!);
          setXenditSheet((s) => s ? { ...s, pollStatus: "failed", pollError: "Payment was declined or cancelled." } : s);
          // Clear server-side pending so a retry mints a fresh transactionId
          handleXenditPaymentFailure({
            data: { system_id: getSystemId(), transaction_id: transId },
          }).catch(() => { /* best-effort */ });
        }
        // PENDING / REQUIRES_ACTION → keep polling
      } catch { /* network error — keep polling */ }
    };

    pollTimerRef.current = setInterval(tick, 3000);
    void tick(); // immediate first check
  }, [navigate]);

  // Start polling whenever sheet opens
  useEffect(() => {
    if (xenditSheet?.open && xenditSheet.pollStatus === "polling") {
      startXenditPolling(
        xenditSheet.paymentRequestId,
        xenditSheet.transactionId,
        xenditSheet.planId,
        xenditSheet.amount,
        // find the channel id from channelLabel fallback
        XENDIT_CHANNELS.find((c) => c.label === xenditSheet.channelLabel)?.id ?? xenditSheet.channelLabel,
        phone,
      );
    }
    return () => { if (pollTimerRef.current) clearInterval(pollTimerRef.current); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [xenditSheet?.open, xenditSheet?.paymentRequestId]);

  const onCloseXenditSheet = () => {
    if (pollTimerRef.current) clearInterval(pollTimerRef.current);
    setXenditSheet(null);
    inFlightRef.current = false;
    setProcessing(false);
  };

  // Cash submissions require a store selection. Digital methods don't.
  const cashFormValid = !isCash || storeId.length > 0;
  // Cash bypasses the 3-strike guard.
  const digitalLockedOut = lockoutMs > 0;
  const cashAvailable = tiles.some((t) => t.id === "cash");

  // When a lockout kicks in mid-session, auto-switch to cash.
  useEffect(() => {
    if (digitalLockedOut && cashAvailable && !isCash) {
      setSelectedTileId("cash");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [digitalLockedOut, cashAvailable]);

  // ─── Render ────────────────────────────────────────────────────────────
  // While the plan is loading from the DB (custom admin-defined plans),
  // show a minimal centered spinner instead of crashing on plan.* access.
  if (!plan) {
    return (
      <div className="min-h-dvh w-full flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3 text-muted-foreground">
          <Loader2 className="h-6 w-6 animate-spin" />
          <p className="text-sm">Loading your plan…</p>
        </div>
      </div>
    );
  }

  // If a lockout is active AND cash isn't visible (shouldn't happen with
  // current brand config, but guard anyway), fall back to the original
  // full-screen lockout view.
  if (digitalLockedOut && !cashAvailable) {
    return <LockoutBanner remainingMs={lockoutMs} planName={plan.name} />;
  }

  return (
    <div className="min-h-dvh w-full flex flex-col bg-background">

      {/* In-app Xendit payment sheet */}
      {xenditSheet?.open && (
        <XenditPaymentSheet
          transactionId={xenditSheet.transactionId}
          planSummary={`${plan.name} · ${plan.duration}${plan.speed ? ` · ${plan.speed}` : ""}`}
          phone={phone || undefined}
          expiresAt={xenditSheetExpiresAt}
          channelLabel={xenditSheet.channelLabel}
          channelType={xenditSheet.channelType}
          amount={xenditSheet.amount}
          redirectUrl={xenditSheet.redirectUrl}
          pollStatus={xenditSheet.pollStatus}
          pollError={xenditSheet.pollError}
          onClose={onCloseXenditSheet}
        />
      )}

      {/* Sticky header — matches plans.tsx exactly */}
      <header className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b border-border safe-top safe-x pb-4">
        <div className="mx-auto w-full max-w-md pt-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary mb-0.5">
                {brand.name}
              </p>
              <h1 className="text-3xl font-bold tracking-tight leading-tight">Confirm &amp; pay</h1>
              <p className="mt-1 text-base text-muted-foreground">Review your order and choose how to pay</p>
            </div>
            <button
              onClick={() => navigate({ to: "/plans" })}
              aria-label="Back to plans"
              className="mt-1 h-9 w-9 flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground hover:bg-accent transition-colors shrink-0"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Scrollable body */}
      <main className="flex-1 flex flex-col safe-x pt-4 pb-2 min-h-0 overflow-y-auto">
        <div className="mx-auto w-full max-w-md flex flex-col gap-3 flex-1">

          {pending && <ResumeBanner pending={pending} onResume={onResume} onCancel={onCancelPending} />}
          {digitalLockedOut && <InlineLockoutBanner remainingMs={lockoutMs} />}

          {/* Plan summary + fee breakdown card */}
          {(() => {
            // Service fee only applies to digital channels (Xendit takes a cut).
            // Cash flow doesn't add a fee at the customer-side.
            const planAmount = plan.price;
            const serviceFee = !isCash ? (plan.epaymentFee ?? 0) : 0;
            const totalPayable = planAmount + serviceFee;
            const showFeeRow = serviceFee > 0;
            return (
              <div className="rounded-2xl border-2 border-primary bg-primary/5 p-4 flex flex-col gap-3 shrink-0 min-w-0">
                {/* Header row — plan identity */}
                <div className="flex items-center gap-3 min-w-0">
                  <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <Zap className="h-5 w-5 text-primary" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xl font-bold truncate">{plan.name}</p>
                    <p className="text-xs text-muted-foreground mt-0.5 truncate">
                      {plan.duration}{plan.speed ? ` · ${plan.speed}` : ""}
                    </p>
                  </div>
                </div>
                {/* Fee breakdown rows */}
                <div className="border-t border-primary/15 pt-3 flex flex-col gap-1.5 text-sm tabular-nums">
                  <div className="flex justify-between gap-3">
                    <span className="text-muted-foreground">Plan</span>
                    <span className="font-semibold">{fmt(planAmount)}</span>
                  </div>
                  {showFeeRow && (
                    <div className="flex justify-between gap-3">
                      <span className="text-muted-foreground">Service fee</span>
                      <span className="font-semibold">{fmt(serviceFee)}</span>
                    </div>
                  )}
                  <div className="flex justify-between gap-3 pt-1.5 mt-0.5 border-t border-primary/15">
                    <span className="font-bold">Total to pay</span>
                    <span className="text-xl font-bold">{fmt(totalPayable)}</span>
                  </div>
                </div>
              </div>
            );
          })()}

          <form ref={formRef} onSubmit={onSubmit} className="flex flex-col flex-1 gap-3 min-w-0">
            <p className="text-sm font-semibold text-muted-foreground px-0.5">Pay with</p>
            {/* Responsive grid: 2 cols for ≤4 tiles, 3 cols for 5+ */}
            <div className={`grid gap-3 min-w-0 ${tiles.length > 4 ? "grid-cols-3" : "grid-cols-2"}`}>
              {tiles.map((tile) => {
                const Icon = tile.icon;
                const active = selectedTileId === tile.id;
                const tileIsDigital = tile.id !== "cash";
                const tileDisabled = digitalLockedOut && tileIsDigital;
                return (
                  <button
                    key={tile.id}
                    type="button"
                    onClick={() => {
                      if (tileDisabled) return;
                      setSelectedTileId(tile.id);
                    }}
                    disabled={tileDisabled}
                    aria-disabled={tileDisabled}
                    className={`min-w-0 rounded-2xl border-2 p-4 flex flex-col items-center justify-center gap-2 transition-all ${
                      tileDisabled
                        ? "border-border bg-muted opacity-40 cursor-not-allowed"
                        : active
                          ? "border-primary bg-primary/5"
                          : "border-border bg-card hover:border-primary/40"
                    }`}
                  >
                    <div className={`h-14 w-14 rounded-2xl flex items-center justify-center shrink-0 ${active && !tileDisabled ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"}`}>
                      <Icon className="h-7 w-7" />
                    </div>
                    <span className="text-sm font-bold truncate max-w-full text-center leading-tight">{tile.label}</span>
                  </button>
                );
              })}
            </div>

            {isCash && (
              <div className="flex flex-col gap-2">
                <label htmlFor="store-select" className="text-sm font-semibold text-muted-foreground px-0.5">
                  Pay at which store?
                </label>
                <div className="relative">
                  <Store className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground pointer-events-none" />
                  <select
                    id="store-select"
                    value={storeId}
                    onChange={(e) => setStoreId(e.target.value)}
                    aria-required="true"
                    className="h-14 w-full text-lg bg-input border-2 border-border rounded-xl pl-12 pr-12 appearance-none font-semibold"
                  >
                    <option value="">Select a store…</option>
                    {STORES.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} — {s.address}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground pointer-events-none" />
                </div>
              </div>
            )}

            <div className="flex flex-col gap-2">
              <p className="text-sm font-semibold text-muted-foreground px-0.5">
                Mobile number <span className="font-normal text-muted-foreground/70">(optional — for SMS receipt)</span>
              </p>
              <Input
                value={phone}
                onChange={(e) => onPhoneChange(e.target.value.replace(/\D/g, "").slice(0, 15))}
                placeholder="09xxxxxxxxx"
                inputMode="tel"
                className="h-14 text-lg bg-input border-2 border-border rounded-xl px-4"
              />
            </div>
          </form>

        </div>
      </main>

      {/* Sticky footer — matches plans.tsx */}
      <footer className="sticky bottom-0 z-20 bg-background/95 backdrop-blur border-t border-border safe-bottom safe-x pt-3 pb-4">
        <div className="mx-auto w-full max-w-md flex flex-col gap-2">
          {!dbOnline && (
            <div className="flex items-center gap-2 rounded-xl border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive">
              <AlertCircle className="h-3.5 w-3.5 shrink-0" />
              Server is offline — payments and vouchers unavailable.
            </div>
          )}
          <Button
            onClick={() => formRef.current?.requestSubmit()}
            disabled={processing || !cashFormValid || !dbOnline}
            size="lg"
            className="w-full h-16 text-lg font-bold rounded-2xl"
          >
            {processing ? (
              <><Loader2 className="h-5 w-5 mr-2 animate-spin" /> {isCash ? "Issuing reference…" : "Processing…"}</>
            ) : !dbOnline ? (
              <>Reconnecting…</>
            ) : isCash ? (
              <>Get payment reference</>
            ) : (
              <>Pay {(() => {
                const fee = !isCash ? (plan.epaymentFee ?? 0) : 0;
                const total = (typeof plan.price === "number" ? plan.price : 0) + fee;
                return fmt(total);
              })()}</>
            )}
          </Button>
          <Link to="/plans">
            <Button type="button" variant="secondary" className="w-full h-14 text-base font-semibold rounded-2xl border-2 border-border">
              Change plan
            </Button>
          </Link>
        </div>
      </footer>

    </div>
  );
}

// ─── Inline lockout banner (cash-still-available variant) ────────────────
function InlineLockoutBanner({ remainingMs }: { remainingMs: number }) {
  const mins = Math.floor(remainingMs / 60000);
  const secs = Math.floor((remainingMs % 60000) / 1000);
  const formatted = `${mins}:${String(secs).padStart(2, "0")}`;
  return (
    <div
      role="status"
      aria-live="polite"
      className="rounded-2xl border-2 border-destructive/30 bg-destructive/5 p-3 flex items-start gap-3 shrink-0 mb-3"
    >
      <div className="h-9 w-9 rounded-xl bg-destructive/15 flex items-center justify-center shrink-0">
        <ShieldAlert className="h-4 w-4 text-destructive" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-bold text-destructive">
          Multiple payment attempts detected. Please try again later.
        </p>
        <p className="text-xs text-muted-foreground mt-0.5">
          Available again in <span className="font-mono font-bold text-foreground">{formatted}</span>. Cash payments still work.
        </p>
      </div>
    </div>
  );
}

// ─── Full-screen lockout banner (fallback when no cash option visible) ───
function LockoutBanner({
  remainingMs,
  planName,
}: {
  remainingMs: number;
  planName: string;
}) {
  const mins = Math.floor(remainingMs / 60000);
  const secs = Math.floor((remainingMs % 60000) / 1000);
  const formatted = `${mins}:${String(secs).padStart(2, "0")}`;

  return (
    <div className="min-h-dvh w-full flex flex-col bg-background">
      <header className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b border-border safe-top safe-x pb-4">
        <div className="mx-auto w-full max-w-md pt-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary mb-0.5">
                PayWifi
              </p>
              <h1 className="text-3xl font-bold tracking-tight leading-tight">Just a moment</h1>
            </div>
          </div>
        </div>
      </header>
      <main className="flex-1 flex flex-col items-center justify-center text-center safe-x px-4">
        <div className="mx-auto w-full max-w-md">
          <div className="h-24 w-24 rounded-full bg-amber-500/10 flex items-center justify-center mx-auto">
            <ShieldAlert className="h-14 w-14 text-amber-500" strokeWidth={2} />
          </div>
          <p className="mt-4 text-2xl font-bold">Let&apos;s slow down a bit</p>
          <p className="mt-2 text-lg text-muted-foreground px-4">
            Several payment attempts in a row. Try again in a moment.
          </p>
          <div className="mt-4 inline-flex items-center gap-2 px-4 h-11 rounded-full bg-amber-500/10 text-amber-700 font-mono font-bold text-base">
            Try again in {formatted}
          </div>
          <p className="mt-3 text-xs text-muted-foreground">Plan: {planName}</p>
        </div>
      </main>
      <footer className="sticky bottom-0 z-20 bg-background/95 backdrop-blur border-t border-border safe-bottom safe-x pt-3 pb-4">
        <div className="mx-auto w-full max-w-md flex flex-col gap-2">
          <Link to="/plans">
            <Button variant="secondary" className="w-full h-14 text-base font-semibold rounded-2xl border-2 border-border">
              Choose another plan
            </Button>
          </Link>
          <Link to="/">
            <Button variant="secondary" className="w-full h-14 text-base font-semibold rounded-2xl border-2 border-border">
              Back to start
            </Button>
          </Link>
        </div>
      </footer>
    </div>
  );
}

// ─── In-app Xendit payment sheet ─────────────────────────────────────────────
/**
 * Full-screen overlay shown after Xendit payment is initiated.
 * Instead of redirecting to Xendit's hosted page, we show:
 *  - For EWALLET (GCash, Maya, etc.): deep-link button to open the app + QR
 *  - For QR_CODE: the QR image/link to scan
 *  - For ONLINE_BANKING: a button to open the bank's page in a new tab
 * The sheet polls the Xendit API every 3 s and auto-completes on SUCCEEDED.
 */
function XenditPaymentSheet({
  channelLabel,
  channelType,
  amount,
  redirectUrl,
  pollStatus,
  pollError,
  onClose,
  transactionId,
  planSummary,
  phone,
  expiresAt,
}: {
  channelLabel: string;
  channelType: "EWALLET" | "QR_CODE" | "ONLINE_BANKING";
  amount: number;
  redirectUrl: string;
  pollStatus: "polling" | "success" | "failed" | "timeout";
  pollError?: string;
  onClose: () => void;
  transactionId: string;
  planSummary: string;
  phone?: string;
  expiresAt: number;
}) {
  const isPolling = pollStatus === "polling";
  const isSuccess = pollStatus === "success";
  const isFailed  = pollStatus === "failed";
  const isTimeout = pollStatus === "timeout";

  // ── Live expiry countdown — refreshes every second while polling
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (!isPolling) return;
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, [isPolling]);
  const remainingMs = Math.max(0, expiresAt - now);
  const remainingMin = Math.floor(remainingMs / 60000);
  const remainingSec = Math.floor((remainingMs % 60000) / 1000);
  const countdownLabel = `${remainingMin}:${String(remainingSec).padStart(2, "0")}`;

  // Short, readable session id for the customer — last 8 chars of the
  // transactionId. Full ID is shown in the support card for reference.
  const sessionShort = transactionId.slice(-8).toUpperCase();

  const actionLabel =
    channelType === "EWALLET"        ? `Open ${channelLabel} app` :
    channelType === "QR_CODE"        ? `Scan QR with ${channelLabel}` :
    /* ONLINE_BANKING */               `Pay via ${channelLabel}`;

  const instructionText =
    channelType === "EWALLET"
      ? `Tap the button below to open your ${channelLabel} app and complete the payment of ${fmt(amount)}. Once paid, this screen will update automatically.`
      : channelType === "QR_CODE"
      ? `Open your QR scanner or ${channelLabel} app and scan the code below to pay ${fmt(amount)}. Once paid, this screen will update automatically.`
      : `Tap the button below to complete payment of ${fmt(amount)} via ${channelLabel} Online Banking. Return here after paying — this screen will update automatically.`;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`${channelLabel} payment`}
      className="fixed inset-0 z-50 flex flex-col bg-background"
    >
      {/* Header — wizard-style with plan, amount, payment channel, session id */}
      <header className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b border-border safe-top safe-x pb-4">
        <div className="mx-auto w-full max-w-md pt-3">
          {/* Top row: title + close */}
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary mb-0.5">
                Confirm &amp; Pay
              </p>
              <h2 className="text-2xl font-bold tracking-tight leading-tight">
                {channelLabel}
              </h2>
            </div>
            {!isSuccess && (
              <button
                onClick={onClose}
                aria-label="Close"
                className="mt-1 h-9 w-9 flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground hover:bg-accent transition-colors shrink-0"
              >
                <X className="h-5 w-5" />
              </button>
            )}
          </div>

          {/* Amount banner — the "amount to pay" focal point */}
          <div className="mt-3 rounded-xl bg-primary/10 px-4 py-3">
            <p className="text-xs font-semibold text-muted-foreground">Amount to pay</p>
            <p className="text-3xl font-bold tabular-nums leading-tight">{fmt(amount)}</p>
            <p className="text-xs text-muted-foreground mt-1 truncate">
              {planSummary}
            </p>
          </div>

          {/* Context strip — payment method, phone, session id, expiry */}
          <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
            <div className="rounded-lg border border-border px-3 py-2 min-w-0">
              <p className="text-muted-foreground">Payment method</p>
              <p className="font-semibold truncate">{channelLabel}</p>
            </div>
            {phone && (
              <div className="rounded-lg border border-border px-3 py-2 min-w-0">
                <p className="text-muted-foreground">Mobile number</p>
                <p className="font-semibold truncate">{phone}</p>
              </div>
            )}
            <div className="rounded-lg border border-border px-3 py-2 min-w-0">
              <p className="text-muted-foreground">Session</p>
              <p className="font-semibold font-mono truncate">{sessionShort}</p>
            </div>
            {isPolling && (
              <div className="rounded-lg border border-border px-3 py-2 min-w-0">
                <p className="text-muted-foreground">Expires in</p>
                <p className="font-semibold font-mono tabular-nums">{countdownLabel}</p>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Body */}
      <main className="flex-1 flex flex-col safe-x pt-4 pb-2 min-h-0 overflow-y-auto">
        <div className="mx-auto w-full max-w-md flex flex-col gap-4 flex-1">

          {/* Status: success */}
          {isSuccess && (
            <div className="flex-1 flex flex-col items-center justify-center text-center gap-4">
              <div className="h-24 w-24 rounded-full bg-green-500/10 flex items-center justify-center">
                <CheckCircle2 className="h-14 w-14 text-green-500" strokeWidth={2} />
              </div>
              <div>
                <p className="text-xl font-bold text-green-600">Payment confirmed!</p>
                <p className="mt-1 text-base text-muted-foreground">Generating your WiFi voucher…</p>
              </div>
              <Loader2 className="h-8 w-8 text-primary animate-spin" />
            </div>
          )}

          {/* Status: failed */}
          {isFailed && (
            <div className="flex-1 flex flex-col items-center justify-center text-center gap-4 px-2">
              <div className="h-20 w-20 rounded-full bg-amber-500/10 flex items-center justify-center">
                <AlertCircle className="h-12 w-12 text-amber-500" strokeWidth={2} />
              </div>
              <div>
                <p className="text-xl font-bold">Payment didn't go through</p>
                <p className="mt-2 text-base text-muted-foreground leading-snug">
                  {pollError ?? "We couldn't confirm your payment. Please try again."}
                </p>
              </div>
              <Button onClick={onClose} className="w-full h-14 text-base font-bold rounded-2xl">
                Try again
              </Button>
            </div>
          )}

          {/* Status: timeout */}
          {isTimeout && (
            <div className="flex-1 flex flex-col items-center justify-center text-center gap-4 px-2">
              <div className="h-20 w-20 rounded-full bg-amber-500/10 flex items-center justify-center">
                <Clock className="h-12 w-12 text-amber-500" strokeWidth={2} />
              </div>
              <div>
                <p className="text-xl font-bold">Still waiting on payment</p>
                <p className="mt-2 text-base text-muted-foreground leading-snug">
                  We haven't seen your payment yet. If you already paid, give it a moment — it may still arrive. Otherwise, try again.
                </p>
              </div>
              <Button onClick={onClose} className="w-full h-14 text-base font-bold rounded-2xl">
                Try again
              </Button>
            </div>
          )}

          {/* Status: polling — show payment action */}
          {isPolling && (
            <>
              {/* Instruction card */}
              <div className="rounded-2xl border-2 border-primary/30 bg-primary/5 p-4">
                <p className="text-sm font-semibold text-foreground leading-snug">
                  {instructionText}
                </p>
              </div>

              {/* Primary action button — opens the channel-specific URL */}
              <a
                href={redirectUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 h-16 rounded-2xl bg-primary text-primary-foreground font-bold text-lg w-full"
              >
                <ExternalLink className="h-5 w-5 shrink-0" />
                {actionLabel}
              </a>

              {/* QR fallback for eWallets / QR channels */}
              {(channelType === "EWALLET" || channelType === "QR_CODE") && (
                <div className="rounded-2xl border-2 border-border bg-card p-4 flex flex-col items-center gap-3">
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Or scan the QR code below
                  </p>
                  <div className="rounded-xl bg-white p-3 border-2 border-border">
                    {/* QR rendered from the Xendit-provided URL */}
                    <QrCodeFromUrl url={redirectUrl} size={160} />
                  </div>
                  <p className="text-xs text-muted-foreground text-center leading-snug">
                    Open your {channelLabel} app camera and point it at this code
                  </p>
                </div>
              )}

              {/* Polling indicator */}
              <div className="flex items-center justify-center gap-2 py-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin shrink-0" />
                Waiting for payment confirmation…
              </div>
            </>
          )}

        </div>
      </main>

      {/* Footer — cancel option while polling */}
      {isPolling && (
        <footer className="sticky bottom-0 z-20 bg-background/95 backdrop-blur border-t border-border safe-bottom safe-x pt-3 pb-4">
          <div className="mx-auto w-full max-w-md">
            <Button
              variant="secondary"
              onClick={onClose}
              className="w-full h-14 text-base font-semibold rounded-2xl border-2 border-border text-muted-foreground"
            >
              Cancel payment
            </Button>
          </div>
        </footer>
      )}
    </div>
  );
}

/**
 * Renders a QR code SVG from the Xendit payment URL using a lightweight
 * browser-native canvas approach or a simple qr-fallback via img/link.
 * Since the redirectUrl IS the Xendit action URL, we just encode it as a QR.
 */
function QrCodeFromUrl({ url, size }: { url: string; size: number }) {
  // Import the project's existing QrCode component (used in result.tsx)
  // We create a dynamic import wrapper using the same approach.
  const [QrComponent, setQrComponent] = useState<React.ComponentType<{ value: string; size: number; ariaLabel?: string }> | null>(null);

  useEffect(() => {
    import("@/components/QrCode").then((m) => {
      setQrComponent(() => m.QrCode);
    });
  }, []);

  if (!QrComponent) {
    return (
      <div
        style={{ width: size, height: size }}
        className="flex items-center justify-center bg-muted rounded-lg"
      >
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return <QrComponent value={url} size={size} ariaLabel="Payment QR code" />;
}


// --- Resume-pending banner ---
function ResumeBanner({
  pending,
  onResume,
  onCancel,
}: {
  pending: StoredVoucher;
  onResume: () => void;
  onCancel: () => void;
}) {
  const plan = getPlan(pending.planId as PlanId);
  const mins = Math.max(1, Math.round((Date.now() - pending.issuedAt) / 60000));
  return (
    <div
      role="region"
      aria-label="Unpaid payment reference"
      className="rounded-2xl border-2 border-primary/40 bg-primary/5 p-3 flex flex-col gap-3 shrink-0"
    >
      <div className="flex items-start gap-3 min-w-0">
        <div className="h-9 w-9 rounded-xl bg-primary/15 flex items-center justify-center shrink-0">
          <RefreshCw className="h-4 w-4 text-primary" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-xs font-bold uppercase tracking-wider text-primary mb-0.5">
            Unpaid payment
          </p>
          <p className="text-sm font-semibold truncate">
            {plan?.name ?? pending.planId} · started {mins} min ago
          </p>
          <p className="text-xs text-muted-foreground mt-0.5 truncate">
            Ref: <code className="font-mono">{pending.paymentReference ?? pending.code}</code>
          </p>
        </div>
      </div>
      <div className="flex gap-2">
        <Button
          type="button"
          onClick={onResume}
          className="flex-1 h-10 rounded-xl text-sm font-semibold"
        >
          Resume
        </Button>
        <Button
          type="button"
          variant="secondary"
          onClick={onCancel}
          className="flex-1 h-10 rounded-xl text-sm font-semibold border-2 border-border"
        >
          Cancel
        </Button>
      </div>
    </div>
  );
}
