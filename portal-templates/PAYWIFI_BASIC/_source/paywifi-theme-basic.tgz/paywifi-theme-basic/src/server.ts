import "./lib/error-capture";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";

type ServerEntry = {
  fetch: (request: Request, env: unknown, ctx: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => (m.default ?? m) as ServerEntry,
    );
  }
  return serverEntryPromise;
}

// h3 swallows in-handler throws into a normal 500 Response with body
// {"unhandled":true,"message":"HTTPError"} — try/catch alone never fires for those.
async function normalizeCatastrophicSsrResponse(response: Response): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!body.includes('"unhandled":true') || !body.includes('"message":"HTTPError"')) {
    return response;
  }

  console.error(consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`));
  return new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  });
}

/**
 * Adds headers that tell captive-portal detection agents (Chrome, iOS, Android,
 * Windows NCA) to open the portal in a real browser tab instead of a sandboxed
 * iframe or webview.
 *
 * - `X-Frame-Options: DENY` — stops any frame from embedding the portal page.
 * - `Cache-Control: no-store` — prevents stale portal pages from being served
 *   after the user has already authenticated.
 * - `X-Content-Type-Options: nosniff` — hardens against MIME-sniffing attacks.
 *
 * Chrome specifically: when it receives a non-204 response to its captive-portal
 * probe (connectivitycheck.gstatic.com), it shows a "Sign in to network"
 * notification. Clicking that opens the portal URL in a full Chrome tab —
 * bypassing the chrome-error://chromewebdata/ sandbox entirely.
 */
function addPortalHeaders(response: Response): Response {
  const headers = new Headers(response.headers);
  headers.set("X-Frame-Options", "DENY");
  headers.set("Cache-Control", "no-store, no-cache, must-revalidate");
  headers.set("X-Content-Type-Options", "nosniff");
  // Explicitly allow the page to be top-level navigated to by any origin
  // (captive portal agents navigate to the URL directly, not via fetch).
  headers.set("Content-Security-Policy", "frame-ancestors 'none'");
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers,
  });
}

export default {
  async fetch(request: Request, env: unknown, ctx: unknown) {
    try {
      const handler = await getServerEntry();
      const response = await handler.fetch(request, env, ctx);
      const normalized = await normalizeCatastrophicSsrResponse(response);
      return addPortalHeaders(normalized);
    } catch (error) {
      console.error(error);
      return new Response(renderErrorPage(), {
        status: 500,
        headers: {
        },
      });
    }
  },
};
