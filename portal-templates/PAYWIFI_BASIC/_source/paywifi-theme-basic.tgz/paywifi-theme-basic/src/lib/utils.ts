import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Format a number as Philippine Peso, e.g. 99 -> "₱99.00" */
export function formatPHP(amount: number): string {
  return `₱${amount.toFixed(2)}`;
}
