/**
 * Mock voucher store — localStorage adapter for the captive-portal demo.
 *
 * Persists issued / redeemed vouchers so the demo behaves like a real
 * backend: codes survive reloads, redemption marks them used, expired
 * codes report correctly, and the admin dashboard has real-looking data
 * to render.
 *
 * ─── Two-code architecture ──────────────────────────────────────────
 * Per the cashier-workflow spec, cash flows carry TWO distinct codes:
 *
 *   • `paymentReference` — the cashier-desk lookup ID. Shown on the
 *     customer's pending screen (QR + text). Cashier types or scans it
 *     to find the pending payment. NEVER functions as a voucher.
 *
 *   • `code` — the captive-portal voucher code. Used at `/validate` to
 *     redeem WiFi. For cash: empty string until the cashier confirms
 *     payment, at which point a fresh voucher code is generated and
 *     written into this field. For digital: set at payment success.
 *
 * The two strings are intentionally different. A customer cannot use
 * their `paymentReference` to redeem WiFi — `findVoucher` looks up by
 * `code` and an unconfirmed cash record has `code === ""`, so the
 * lookup misses.
 *
 * ─── Why a separate file ─────────────────────────────────────────────
 * When milestone #1 (real Postgres) lands, the live swap is:
 *   1. Delete this file.
 *   2. Replace the localStorage calls in `portal-api.ts` with DB queries.
 *
 * SSR-safe: every entry point guards `typeof window` so server-rendered
 * routes don't blow up.
 */

import type { PlanId } from "@/lib/portal-api";

export type StoredVoucher = {
  code: string;
  paymentReference?: string;
  planId: PlanId;
  issuedAt: number;
  redeemedAt?: number;
  durationMinutes: number;
  transactionId?: string;
  phone?: string;
  venue?: string;
  storeId?: string;
  expiresAt?: number;
  voidedAt?: number;
  confirmedAt?: number;
};

/**
 * Audit record for customer phone-number updates on a pending cash reference.
 * Rate-limit: one edit per 30 seconds, max 3 total edits per reference.
 */
export type PhoneEditLog = {
  paymentReference: string;
  edits: number[];      // timestamps (ms) of each successful save
  lastEditAt: number;   // timestamp of most recent save
};

const STORAGE_KEY = "paywifi:vouchers:v2";
const PHONE_EDIT_KEY = "paywifi:phone-edits:v1";

function load(): StoredVoucher[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as StoredVoucher[]) : [];
  } catch {
    return [];
  }
}

function save(list: StoredVoucher[]): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch {
    // localStorage full / disabled / private-mode — fail silently in the mock.
  }
}

function loadPhoneEdits(): PhoneEditLog[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(PHONE_EDIT_KEY);
    return raw ? (JSON.parse(raw) as PhoneEditLog[]) : [];
  } catch {
    return [];
  }
}

function savePhoneEdits(logs: PhoneEditLog[]): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(PHONE_EDIT_KEY, JSON.stringify(logs));
  } catch { /* ignore */ }
}

export function addVoucher(v: StoredVoucher): void {
  const list = load();
  list.push(v);
  save(list);
}

export function findVoucher(code: string): StoredVoucher | undefined {
  const normalized = code.trim().toUpperCase();
  if (!normalized) return undefined;
  return load().find((v) => v.code === normalized);
}

export function findByPaymentReference(ref: string): StoredVoucher | undefined {
  const normalized = ref.trim().toUpperCase();
  if (!normalized) return undefined;
  return load().find((v) => v.paymentReference === normalized);
}

export function markRedeemed(code: string): boolean {
  const list = load();
  const normalized = code.trim().toUpperCase();
  const idx = list.findIndex((v) => v.code === normalized);
  if (idx < 0 || list[idx].redeemedAt) return false;
  list[idx].redeemedAt = Date.now();
  save(list);
  return true;
}

export function getAllVouchers(): StoredVoucher[] {
  return load()
    .slice()
    .sort((a, b) => b.issuedAt - a.issuedAt);
}

export function getActiveSessions(): StoredVoucher[] {
  const now = Date.now();
  return load().filter((v) => {
    // Must have been redeemed and not subsequently voided.
    if (!v.redeemedAt) return false;
    if (v.voidedAt) return false;
    // Session window: duration starts at redemption time.
    const expiresAt = v.redeemedAt + v.durationMinutes * 60 * 1000;
    return now < expiresAt;
  });
}

export function findPendingForVenue(
  venue: string,
  withinMs: number = 15 * 60 * 1000,
): StoredVoucher | undefined {
  const now = Date.now();
  return load()
    .slice()
    .sort((a, b) => b.issuedAt - a.issuedAt)
    .find((v) => {
      if (v.venue !== venue) return false;
      if (v.redeemedAt) return false;
      if (v.voidedAt) return false;
      if (v.confirmedAt) return false;
      if (!v.paymentReference) return false;
      if (now - v.issuedAt > withinMs) return false;
      if (v.expiresAt && v.expiresAt <= now) return false;
      return true;
    });
}

export function confirmAndIssueVoucher(
  paymentReference: string,
  voucherCode: string,
): boolean {
  const list = load();
  const normalizedRef = paymentReference.trim().toUpperCase();
  const idx = list.findIndex((v) => v.paymentReference === normalizedRef);
  if (idx < 0) return false;
  const v = list[idx];
  if (v.confirmedAt || v.voidedAt || v.redeemedAt) return false;
  if (v.expiresAt && v.expiresAt <= Date.now()) return false;
  list[idx].confirmedAt = Date.now();
  list[idx].code = voucherCode.trim().toUpperCase();
  save(list);
  return true;
}

export function voidVoucher(codeOrReference: string): boolean {
  const list = load();
  const normalized = codeOrReference.trim().toUpperCase();
  const idx = list.findIndex(
    (v) => v.code === normalized || v.paymentReference === normalized,
  );
  if (idx < 0) return false;
  if (list[idx].voidedAt || list[idx].redeemedAt) return false;
  list[idx].voidedAt = Date.now();
  save(list);
  return true;
}

/**
 * Removes vouchers whose pre-issuance TTL (`expiresAt`) has elapsed AND
 * that were never redeemed. Redeemed vouchers are kept indefinitely for
 * history regardless of `expiresAt`.
 *
 * Contrast with `getActiveSessions`, which filters by the *session window*
 * (`redeemedAt + durationMinutes`) — a different "expiry" concept:
 *   • `expiresAt`  — deadline to pay/confirm before the reference is voided.
 *   • session end  — when the redeemed WiFi access window closes.
 *
 * Returns the number of records removed.
 */
export function purgeExpired(): number {
  const list = load();
  const now = Date.now();
  const kept = list.filter((v) => {
    if (v.redeemedAt) return true;   // keep all redeemed records for history
    if (!v.expiresAt) return true;   // no TTL set — keep
    return v.expiresAt > now;        // TTL not yet elapsed — keep
  });
  if (kept.length !== list.length) {
    save(kept);
  }
  return list.length - kept.length;
}

export function clearStore(): void {
  save([]);
}

export function seedDemoData(): void {
  if (load().length > 0) return;
  const now = Date.now();
  const MIN = 60 * 1000;
  const HR = 60 * MIN;
  const DAY = 24 * HR;
  void HR; void DAY;

  const seeds: StoredVoucher[] = [
    {
      code: "DEMO-AAAA-2222",
      planId: "day",
      issuedAt: now - 30 * MIN,
      redeemedAt: now - 10 * MIN,
      durationMinutes: 60 * 24,
      transactionId: "TXN-DEMOSEED1",
    },
    {
      code: "DEMO-BBBB-3333",
      planId: "hour",
      issuedAt: now - 15 * MIN,
      redeemedAt: now - 5 * MIN,
      durationMinutes: 60,
      transactionId: "TXN-DEMOSEED2",
      phone: "09171234567",
    },
    {
      code: "DEMO-CCCC-4444",
      planId: "week",
      issuedAt: now - 2 * MIN,
      durationMinutes: 60 * 24 * 7,
      transactionId: "TXN-DEMOSEED3",
    },
    {
      code: "",
      paymentReference: "DEMO-PEND-7777",
      planId: "day",
      issuedAt: now - 3 * MIN,
      durationMinutes: 60 * 24,
      transactionId: "CASH-DEMOSEED4",
      phone: "09181234567",
      venue: "default",
      storeId: "main-counter",
      // 15-minute TTL from issuedAt; 3 min have elapsed → expires ~12 min from now.
      expiresAt: now - 3 * MIN + 15 * MIN,
    },
    {
      code: "DEMO-CASH-9999",
      paymentReference: "DEMO-PAID-8888",
      planId: "hour",
      issuedAt: now - 8 * MIN,
      confirmedAt: now - 4 * MIN,
      durationMinutes: 60,
      transactionId: "CASH-DEMOSEED5",
      venue: "default",
      storeId: "lobby-desk",
    },
  ];

  for (const v of seeds) addVoucher(v);
}


// ─── Sequential payment reference counter ────────────────────────────────
const REF_SEQ_KEY = "paywifi:ref-seq:v1";

/**
 * Returns the next 6-digit payment reference as a zero-padded string
 * (e.g. "000001", "000002", …, "999999"). The counter persists in
 * localStorage so references are strictly incrementing across sessions.
 * Wraps at 999999 back to 1 (avoids "000000").
 */
export function nextPaymentReferenceSequence(): string {
  if (typeof window === "undefined") return "000001";
  try {
    const raw = window.localStorage.getItem(REF_SEQ_KEY);
    const current = raw ? parseInt(raw, 10) : 0;
    const next = current >= 999999 ? 1 : current + 1;
    window.localStorage.setItem(REF_SEQ_KEY, String(next));
    return String(next).padStart(6, "0");
  } catch {
    return "000001";
  }
}


// ─── Digital pending payment tracker ─────────────────────────────────────
// Digital vouchers are issued immediately but we still want to prevent
// duplicate payments within a short window. We record a lightweight
// "pending digital" entry that expires after DIGITAL_PENDING_TTL_MS.
// On redemption (or explicit clear) it is removed.

const DIGITAL_PENDING_KEY = "paywifi:pending-digital:v1";

/** How long a digital payment is considered "pending" before the user
 *  can attempt another one. Shorter than cash (15 min) since digital
 *  success is instant — this is purely an abuse / duplicate guard. */
export const DIGITAL_PENDING_TTL_MS = 5 * 60 * 1000; // 5 minutes

export type PendingDigitalRecord = {
  transactionId: string;
  planId: PlanId;
  method: string;
  venue: string;
  issuedAt: number;
  expiresAt: number;
  /** The voucher code that was issued — used to check redemption status. */
  code: string;
};

function loadDigitalPending(): PendingDigitalRecord[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(DIGITAL_PENDING_KEY);
    return raw ? (JSON.parse(raw) as PendingDigitalRecord[]) : [];
  } catch { return []; }
}

function saveDigitalPending(list: PendingDigitalRecord[]): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(DIGITAL_PENDING_KEY, JSON.stringify(list));
  } catch { /* ignore */ }
}

/** Records a successful digital payment so duplicate attempts are blocked. */
export function recordPendingDigitalPayment(record: PendingDigitalRecord): void {
  const list = loadDigitalPending();
  // Purge expired entries first
  const now = Date.now();
  const fresh = list.filter((r) => r.expiresAt > now);
  fresh.push(record);
  saveDigitalPending(fresh);
}

/** Clears a digital pending record by transactionId (call after redemption). */
export function clearPendingDigitalPayment(transactionId: string): void {
  const list = loadDigitalPending();
  saveDigitalPending(list.filter((r) => r.transactionId !== transactionId));
}

/**
 * Unified check: returns a pending payment (cash OR digital) for a venue,
 * or undefined if none exists.
 *
 * Cash: unconfirmed reference still within TTL.
 * Digital: successfully issued voucher not yet redeemed, within 5-min window.
 *
 * This is the single gate used by checkout to block duplicate payments
 * across ALL methods.
 */
export type AnyPendingPayment =
  | { kind: "cash"; voucher: StoredVoucher }
  | { kind: "digital"; record: PendingDigitalRecord };

export function findAnyPendingPayment(venue: string): AnyPendingPayment | undefined {
  const now = Date.now();

  // Load once and build a transactionId → voucher map to avoid O(n²)
  // localStorage reads when checking digital pending records.
  const allVouchers = load();
  const voucherByTxn = new Map<string, StoredVoucher>();
  for (const v of allVouchers) {
    if (v.transactionId) voucherByTxn.set(v.transactionId, v);
  }

  // 1. Cash: unconfirmed, unvoided, unexpired reference
  const cashPending = allVouchers.find((v) => {
    if (v.venue !== venue) return false;
    if (!v.paymentReference) return false;
    if (v.confirmedAt) return false;
    if (v.voidedAt) return false;
    if (v.redeemedAt) return false;
    if (v.expiresAt && v.expiresAt <= now) return false;
    return true;
  });
  if (cashPending) return { kind: "cash", voucher: cashPending };

  // 2. Digital: recently issued voucher not yet redeemed, within TTL
  const digitalList = loadDigitalPending();
  const digitalPending = digitalList.find((r) => {
    if (r.venue !== venue) return false;
    if (r.expiresAt <= now) return false;
    // Check if the voucher was already redeemed using the pre-built map
    const voucher = voucherByTxn.get(r.transactionId);
    if (voucher?.redeemedAt) return false;
    return true;
  });
  if (digitalPending) return { kind: "digital", record: digitalPending };

  return undefined;
}

// ─── Phone-number edit with rate-limit ───────────────────────────────────

/** 30 seconds between edits. */
export const PHONE_EDIT_COOLDOWN_MS = 30_000;
/** Maximum 3 edits per pending reference. */
export const PHONE_EDIT_MAX_CHANGES = 3;

export type PhoneUpdateResult =
  | { ok: true }
  | { ok: false; reason: "not_found" | "already_processed" }
  | { ok: false; reason: "cooldown"; cooldownMs: number }
  | { ok: false; reason: "limit_reached" };

/**
 * Update the phone number on a pending (unconfirmed) cash payment reference.
 *
 * Rules:
 *  - Blocked if already confirmed / voided / redeemed.
 *  - Rate-limited: one save every PHONE_EDIT_COOLDOWN_MS (30s).
 *  - Hard cap: PHONE_EDIT_MAX_CHANGES (3) total edits per reference.
 *
 * On success, writes updated phone to the voucher record in localStorage,
 * triggering a `storage` event that the operator page picks up.
 */
export function updateVoucherPhone(
  ref: string,
  newPhone: string,
): PhoneUpdateResult {
  const normalized = ref.trim().toUpperCase();
  const list = load();
  const idx = list.findIndex((v) => v.paymentReference === normalized);
  if (idx < 0) return { ok: false, reason: "not_found" };

  const v = list[idx];
  if (v.confirmedAt || v.voidedAt || v.redeemedAt) {
    return { ok: false, reason: "already_processed" };
  }

  const logs = loadPhoneEdits();
  const logIdx = logs.findIndex((l) => l.paymentReference === normalized);
  const log: PhoneEditLog = logIdx >= 0
    ? logs[logIdx]
    : { paymentReference: normalized, edits: [], lastEditAt: 0 };

  if (log.edits.length >= PHONE_EDIT_MAX_CHANGES) {
    return { ok: false, reason: "limit_reached" };
  }

  const now = Date.now();
  const msSinceLast = now - log.lastEditAt;
  if (log.lastEditAt > 0 && msSinceLast < PHONE_EDIT_COOLDOWN_MS) {
    return { ok: false, reason: "cooldown", cooldownMs: PHONE_EDIT_COOLDOWN_MS - msSinceLast };
  }

  // Persist updated phone
  list[idx] = { ...v, phone: newPhone || undefined };
  save(list);

  // Record audit entry
  const updatedLog: PhoneEditLog = {
    paymentReference: normalized,
    edits: [...log.edits, now],
    lastEditAt: now,
  };
  if (logIdx >= 0) logs[logIdx] = updatedLog;
  else logs.push(updatedLog);
  savePhoneEdits(logs);

  return { ok: true };
}

/**
 * Returns the current phone-edit log for a reference, or null if none exists.
 * Used by the customer pending screen to render remaining-edits and cooldown state.
 */
export function getPhoneEditLog(ref: string): PhoneEditLog | null {
  const normalized = ref.trim().toUpperCase();
  return loadPhoneEdits().find((l) => l.paymentReference === normalized) ?? null;
}

/**
 * Merge a phone-edit log fetched from Supabase into the local cache.
 * Only updates if the Supabase record has more edits or is newer, so
 * the local optimistic write is never overwritten by a stale server response.
 */
export function syncPhoneEditLog(ref: string, edits: number[], lastEditAt: number): void {
  const normalized = ref.trim().toUpperCase();
  const logs = loadPhoneEdits();
  const idx = logs.findIndex((l) => l.paymentReference === normalized);
  const existing = idx >= 0 ? logs[idx] : null;
  // Only sync if server has more edits or a more recent timestamp
  if (existing && existing.edits.length >= edits.length && existing.lastEditAt >= lastEditAt) return;
  const merged: PhoneEditLog = { paymentReference: normalized, edits, lastEditAt };
  if (idx >= 0) logs[idx] = merged;
  else logs.push(merged);
  savePhoneEdits(logs);
}


// ─── Plan catalog store ───────────────────────────────────────────────────
// Plans are stored in localStorage so admin/operator can manage them without
// a backend. When milestone #1 lands, replace these with DB queries.

const PLANS_KEY = "paywifi:plans:v1";

export type StoredPlan = {
  id: string;
  name: string;
  description: string;
  duration: string;
  durationMinutes: number;
  price: number;
  /** Optional — hidden/unselected by default unless explicitly set. */
  speed?: string;
  /**
   * Optional e-payment convenience fee (₱). Added to the total when the
   * customer pays via GCash, QR PH, Maya, or any non-cash e-payment method.
   * Leave undefined (or 0) for no fee.
   */
  epaymentFee?: number;
  popular?: boolean;
};

/** Default plan catalog — written to localStorage the first time plans are loaded. */
const DEFAULT_PLANS: StoredPlan[] = [
  {
    id: "hour",
    name: "1 Hour",
    description: "Perfect for a quick session.",
    duration: "60 minutes",
    durationMinutes: 60,
    speed: "10 Mbps",
    price: 1.99,
  },
  {
    id: "day",
    name: "Day Pass",
    description: "Full-day access, great for working or browsing.",
    duration: "24 hours",
    durationMinutes: 60 * 24,
    speed: "25 Mbps",
    price: 4.99,
    popular: true,
  },
  {
    id: "week",
    name: "Week Pass",
    description: "Best value for extended stays.",
    duration: "7 days",
    durationMinutes: 60 * 24 * 7,
    speed: "50 Mbps",
    price: 14.99,
  },
];

function loadPlans(): StoredPlan[] {
  if (typeof window === "undefined") return DEFAULT_PLANS;
  try {
    const raw = window.localStorage.getItem(PLANS_KEY);
    if (!raw) {
      // First run — seed defaults
      window.localStorage.setItem(PLANS_KEY, JSON.stringify(DEFAULT_PLANS));
      return DEFAULT_PLANS;
    }
    return JSON.parse(raw) as StoredPlan[];
  } catch {
    return DEFAULT_PLANS;
  }
}

function savePlans(plans: StoredPlan[]): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(PLANS_KEY, JSON.stringify(plans));
  } catch { /* ignore */ }
}

/** Returns all plans in display order. */
export function getStoredPlans(): StoredPlan[] {
  return loadPlans();
}

/** Adds a new plan. Returns false if id already exists. */
export function addStoredPlan(plan: StoredPlan): boolean {
  const plans = loadPlans();
  if (plans.some((p) => p.id === plan.id)) return false;
  plans.push(plan);
  savePlans(plans);
  return true;
}

/** Updates an existing plan by id. Returns false if not found. */
export function updateStoredPlan(id: string, patch: Partial<Omit<StoredPlan, "id">>): boolean {
  const plans = loadPlans();
  const idx = plans.findIndex((p) => p.id === id);
  if (idx < 0) return false;
  plans[idx] = { ...plans[idx], ...patch };
  savePlans(plans);
  return true;
}

/** Removes a plan by id. Returns false if not found. */
export function deleteStoredPlan(id: string): boolean {
  const plans = loadPlans();
  const next = plans.filter((p) => p.id !== id);
  if (next.length === plans.length) return false;
  savePlans(next);
  return true;
}

/** Resets plan catalog back to defaults. */
export function resetStoredPlans(): void {
  savePlans(DEFAULT_PLANS);
}


// ─── Operator Credit System ───────────────────────────────────────────────
// Prepaid credit balance for operators. 1 credit = ₱1 voucher value.
// Credits are deducted on every voucher generation (cash or digital).
// Default starting balance: 500 credits.

const CREDITS_KEY = "paywifi:operator-credits:v1";

export const DEFAULT_CREDIT_BALANCE = 500;

export type CreditReloadPackage = {
  id: string;
  credits: number;
  price: number;   // what operator pays (₱)
};

export const CREDIT_PACKAGES: CreditReloadPackage[] = [
  { id: "pkg-500",  credits: 500,  price: 300 },
  { id: "pkg-1000", credits: 1000, price: 500 },
];

export type CreditReloadTransaction = {
  id: string;
  packageId: string;
  credits: number;
  price: number;
  method: "gcash";
  status: "pending" | "confirmed" | "failed";
  createdAt: number;
  confirmedAt?: number;
  transactionRef?: string;
};

export type CreditRecord = {
  balance: number;
  totalPurchased: number;
  totalConsumed: number;
  reloads: CreditReloadTransaction[];
};

function loadCredits(): CreditRecord {
  if (typeof window === "undefined") return {
    balance: DEFAULT_CREDIT_BALANCE,
    totalPurchased: DEFAULT_CREDIT_BALANCE,
    totalConsumed: 0,
    reloads: [],
  };
  try {
    const raw = window.localStorage.getItem(CREDITS_KEY);
    if (!raw) {
      const fresh: CreditRecord = {
        balance: DEFAULT_CREDIT_BALANCE,
        totalPurchased: DEFAULT_CREDIT_BALANCE,
        totalConsumed: 0,
        reloads: [],
      };
      window.localStorage.setItem(CREDITS_KEY, JSON.stringify(fresh));
      return fresh;
    }
    return JSON.parse(raw) as CreditRecord;
  } catch {
    return { balance: DEFAULT_CREDIT_BALANCE, totalPurchased: DEFAULT_CREDIT_BALANCE, totalConsumed: 0, reloads: [] };
  }
}

function saveCredits(record: CreditRecord): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(CREDITS_KEY, JSON.stringify(record));
  } catch { /* ignore */ }
}

/** Returns the current credit record. */
export function getCreditRecord(): CreditRecord {
  return loadCredits();
}

/**
 * Attempts to deduct `amount` credits (= voucher price in pesos).
 * Returns true and updates balance if sufficient credits available.
 * Returns false if insufficient — caller must block voucher generation.
 */
export function deductCredits(amount: number): boolean {
  const rec = loadCredits();
  const cost = Math.ceil(amount); // 1 credit per peso, round up
  if (rec.balance < cost) return false;
  rec.balance -= cost;
  rec.totalConsumed += cost;
  saveCredits(rec);
  return true;
}

/**
 * Records a pending GCash credit reload request.
 * Credits are NOT added until confirmCreditReload() is called.
 */
export function createCreditReload(pkg: CreditReloadPackage): CreditReloadTransaction {
  const rec = loadCredits();
  const txn: CreditReloadTransaction = {
    id: `CR-${Date.now()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
    packageId: pkg.id,
    credits: pkg.credits,
    price: pkg.price,
    method: "gcash",
    status: "pending",
    createdAt: Date.now(),
  };
  rec.reloads = [txn, ...rec.reloads].slice(0, 50); // keep last 50
  saveCredits(rec);
  return txn;
}

/**
 * Confirms a pending credit reload — adds credits to balance.
 * Safe to call only after GCash payment is verified.
 */
export function confirmCreditReload(txnId: string, transactionRef?: string): boolean {
  const rec = loadCredits();
  const idx = rec.reloads.findIndex((r) => r.id === txnId);
  if (idx < 0) return false;
  if (rec.reloads[idx].status !== "pending") return false;
  rec.reloads[idx].status = "confirmed";
  rec.reloads[idx].confirmedAt = Date.now();
  if (transactionRef) rec.reloads[idx].transactionRef = transactionRef;
  rec.balance += rec.reloads[idx].credits;
  rec.totalPurchased += rec.reloads[idx].credits;
  saveCredits(rec);
  return true;
}

/** Marks a pending reload as failed (no credits added). */
export function failCreditReload(txnId: string): boolean {
  const rec = loadCredits();
  const idx = rec.reloads.findIndex((r) => r.id === txnId);
  if (idx < 0) return false;
  if (rec.reloads[idx].status !== "pending") return false;
  rec.reloads[idx].status = "failed";
  saveCredits(rec);
  return true;
}

/** Resets credit record back to defaults (used by DemoControls reset). */
export function resetCredits(): void {
  saveCredits({
    balance: DEFAULT_CREDIT_BALANCE,
    totalPurchased: DEFAULT_CREDIT_BALANCE,
    totalConsumed: 0,
    reloads: [],
  });
}


// ─── Refund system ────────────────────────────────────────────────────────────
//
// Operators can tag a confirmed sale for refund within REFUND_WINDOW_MS.
// By default refunds are auto-approved; admin can toggle manual approval.
// Refunded vouchers are excluded from revenue calculations.

const REFUND_KEY        = "paywifi:refunds:v1";
const REFUND_CONFIG_KEY = "paywifi:refund-config:v1";

/** Window within which a refund can be requested: 48 hours. */
export const REFUND_WINDOW_MS = 48 * 60 * 60 * 1000;

export const REFUND_REASONS = [
  "Customer request",
  "Duplicate payment",
  "Service not received",
  "Technical error",
  "Wrong plan purchased",
  "Other",
] as const;

export type RefundReason = (typeof REFUND_REASONS)[number];

export type RefundRequest = {
  id: string;
  voucherCode: string;
  planId: string;
  saleAmount: number;      // ₱ — plan price at time of refund
  reason: RefundReason;
  notes?: string;
  status: "pending" | "approved" | "rejected";
  createdAt: number;
  resolvedAt?: number;
  resolvedBy?: "auto" | "admin";
};

export type RefundConfig = {
  /** When true, refund requests are auto-approved immediately. Default: true. */
  autoApprove: boolean;
};

function loadRefundConfig(): RefundConfig {
  if (typeof window === "undefined") return { autoApprove: true };
  try {
    const raw = window.localStorage.getItem(REFUND_CONFIG_KEY);
    return raw ? JSON.parse(raw) as RefundConfig : { autoApprove: true };
  } catch { return { autoApprove: true }; }
}

function saveRefundConfig(cfg: RefundConfig): void {
  if (typeof window === "undefined") return;
  try { window.localStorage.setItem(REFUND_CONFIG_KEY, JSON.stringify(cfg)); } catch { /* */ }
}

function loadRefunds(): RefundRequest[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(REFUND_KEY);
    return raw ? JSON.parse(raw) as RefundRequest[] : [];
  } catch { return []; }
}

function saveRefunds(list: RefundRequest[]): void {
  if (typeof window === "undefined") return;
  try { window.localStorage.setItem(REFUND_KEY, JSON.stringify(list)); } catch { /* */ }
}

export function getRefundConfig(): RefundConfig {
  return loadRefundConfig();
}

export function setRefundAutoApprove(value: boolean): void {
  saveRefundConfig({ ...loadRefundConfig(), autoApprove: value });
}

export function getRefunds(): RefundRequest[] {
  return loadRefunds();
}

/**
 * Submits a refund request for a voucher.
 * If autoApprove is enabled, immediately marks as approved.
 * Returns the created RefundRequest, or null if outside the refund window.
 */
export function createRefundRequest(
  voucherCode: string,
  planId: string,
  saleAmount: number,
  saleTimestamp: number,
  reason: RefundReason,
  notes?: string,
): RefundRequest | null {
  // Enforce refund window
  if (Date.now() - saleTimestamp > REFUND_WINDOW_MS) return null;

  const cfg = loadRefundConfig();
  const list = loadRefunds();

  // Prevent duplicate open refund for same voucher
  const existing = list.find(
    (r) => r.voucherCode === voucherCode && r.status !== "rejected",
  );
  if (existing) return existing;

  const req: RefundRequest = {
    id: `REF-${Date.now()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
    voucherCode,
    planId,
    saleAmount,
    reason,
    notes: notes || undefined,
    status: cfg.autoApprove ? "approved" : "pending",
    createdAt: Date.now(),
    resolvedAt: cfg.autoApprove ? Date.now() : undefined,
    resolvedBy: cfg.autoApprove ? "auto" : undefined,
  };

  list.unshift(req);
  saveRefunds(list.slice(0, 200));
  return req;
}

/** Admin approves a pending refund request. */
export function approveRefund(id: string): boolean {
  const list = loadRefunds();
  const idx = list.findIndex((r) => r.id === id);
  if (idx < 0 || list[idx].status !== "pending") return false;
  list[idx].status = "approved";
  list[idx].resolvedAt = Date.now();
  list[idx].resolvedBy = "admin";
  saveRefunds(list);
  return true;
}

/** Admin rejects a pending refund request. */
export function rejectRefund(id: string): boolean {
  const list = loadRefunds();
  const idx = list.findIndex((r) => r.id === id);
  if (idx < 0 || list[idx].status !== "pending") return false;
  list[idx].status = "rejected";
  list[idx].resolvedAt = Date.now();
  list[idx].resolvedBy = "admin";
  saveRefunds(list);
  return true;
}

/** Returns the set of voucher codes that have approved refunds. */
export function getRefundedVoucherCodes(): Set<string> {
  return new Set(
    loadRefunds()
      .filter((r) => r.status === "approved")
      .map((r) => r.voucherCode),
  );
}

/** Resets all refund data (used by DemoControls reset). */
export function resetRefunds(): void {
  saveRefunds([]);
}

/**
 * Merge a phone-edit log fetched from Supabase into the local cache.
 * Only updates if the Supabase record has more edits or is newer, so
 * the local optimistic write is never overwritten by a stale server response.
 */


/**
 * Returns the total queued minutes for a phone number — i.e. unredeemed,
 * unvoided, unexpired vouchers belonging to this phone. Plus, if a voucher
 * is currently active (redeemed and still within its window), the remaining
 * minutes of that active session.
 *
 * This is informational for the customer ("you have 3 hours queued").
 * Actual queue enforcement happens at the wifi gateway.
 */
export function getQueuedTimeForPhone(phone: string): {
  activeMinutes: number;
  queuedMinutes: number;
  totalMinutes: number;
} {
  const now = Date.now();
  const list = load().filter((v) => v.phone === phone && !v.voidedAt);
  let activeMinutes = 0;
  let queuedMinutes = 0;
  for (const v of list) {
    if (v.redeemedAt) {
      const endsAt = v.redeemedAt + v.durationMinutes * 60 * 1000;
      if (now < endsAt) {
        activeMinutes += Math.ceil((endsAt - now) / 60000);
      }
    } else {
      // Skip expired (cash references that timed out before redemption)
      if (v.expiresAt && v.expiresAt <= now) continue;
      queuedMinutes += v.durationMinutes;
    }
  }
  return {
    activeMinutes,
    queuedMinutes,
    totalMinutes: activeMinutes + queuedMinutes,
  };
}
