/**
 * supabase.server.ts — server-only Supabase client.
 *
 * The `.server.ts` suffix excludes this from the client bundle.
 * Uses the SERVICE_ROLE key — never expose to the browser.
 *
 * All write operations (INSERT/UPDATE) MUST go through this module.
 * The service role key bypasses RLS so writes from server functions work
 * without needing user auth tokens.
 */
import process from "node:process";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "https://db.techpinoy.net";
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY ?? "";
const ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";

let _serverClient: SupabaseClient | null = null;

/**
 * Returns the server-side Supabase client (service role).
 * Falls back to anon key if service role key is not configured.
 */
export function getServerSupabaseClient(): SupabaseClient {
  if (!_serverClient) {
    const key = SERVICE_ROLE_KEY || ANON_KEY;
    _serverClient = createClient(SUPABASE_URL, key, {
      auth: { persistSession: false },
    });
  }
  return _serverClient;
}

/**
 * Checks Supabase server reachability from the server side.
 * Returns true if the REST API responds with a 200.
 */
export async function checkDbHealthServer(): Promise<boolean> {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    const resp = await fetch(`${SUPABASE_URL}/rest/v1/`, {
      signal: controller.signal,
      headers: { apikey: ANON_KEY || SERVICE_ROLE_KEY },
    });
    clearTimeout(timer);
    return resp.ok || resp.status === 200;
  } catch {
    return false;
  }
}

export { SUPABASE_URL };
