/**
 * Mocked analytics — captures funnel events to localStorage so the admin
 * dashboard can render conversion stats without a real backend.
 *
 * Every event is tagged with the active venue (read from the same
 * sessionStorage key that `brand.tsx` writes on boot), so the admin
 * dashboard can filter "Café Luna's funnel" with a one-line call to
 * `getFunnelStats({ venue: 'cafe-luna' })`.
 *
 * ─── Why a separate file ─────────────────────────────────────────────
 * When milestone #1 lands and you wire a real provider (PostHog, Mixpanel,
 * GA4, …), `trackEvent` becomes a thin wrapper around the provider SDK.
 * `getAllEvents` / `getFunnelStats` either disappear (provider has its own
 * dashboard) or stay as a thin local cache for the admin view.
 *
 * Delete this file at milestone #1 if you're going fully provider-side.
 */

import type { PaymentMethod, PlanId, VoucherStatus } from "@/lib/portal-api";
import { getSupabaseClient, getSystemId } from "@/lib/supabase";


export type EventName =
  | "home_view"
  | "voucher_submitted"
  | "voucher_validated"
  | "plan_picked"
  | "checkout_submit"
  | "payment_success"
  | "payment_failed"
  | "start_browsing";

export type TrackedEvent = {
  name: EventName;
  at: number;
  venue: string;
  props: Record<string, unknown>;
};

// Strongly-typed prop shapes per event. Components should pass payloads that
// match these — runtime is permissive (props is `Record<string, unknown>`)
// so analytics never blocks the user flow, but TypeScript guards the call sites.
export type EventProps = {
  home_view: Record<string, never>;
  voucher_submitted: { code_length: number };
  voucher_validated: { status: VoucherStatus };
  plan_picked: { planId: PlanId; price: number };
  checkout_submit: { planId: PlanId; method: PaymentMethod; sms_requested: boolean };
  payment_success: { planId: PlanId; method: PaymentMethod; price: number; transactionId: string };
  payment_failed: { planId: PlanId; reason: string };
  start_browsing: { source: "result" | "validate" };
};

const STORAGE_KEY = "paywifi:events:v1";
const VENUE_SESSION_KEY = "paywifi:venue";
const MAX_EVENTS = 500;

function load(): TrackedEvent[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as TrackedEvent[]) : [];
  } catch {
    return [];
  }
}

function save(list: TrackedEvent[]): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch {
    /* localStorage full / disabled — fail silently in the mock */
  }
}

function getActiveVenueSlug(): string {
  if (typeof window === "undefined") return "default";
  try {
    return window.sessionStorage.getItem(VENUE_SESSION_KEY) ?? "default";
  } catch {
    return "default";
  }
}

/**
 * Push a funnel event to the analytics store. Strongly-typed via overloads —
 * the second arg's shape is tied to the event name.
 *
 * Never throws and never blocks the calling component. Best-effort logging.
 */
export function trackEvent<N extends EventName>(
  name: N,
  props: EventProps[N] = {} as EventProps[N],
): void {
  if (typeof window === "undefined") return;
  try {
    const event: TrackedEvent = {
      name,
      at: Date.now(),
      venue: getActiveVenueSlug(),
      props: props as Record<string, unknown>,
    };
    const list = load();
    list.push(event);
    // Cap unbounded growth.
    if (list.length > MAX_EVENTS) {
      list.splice(0, list.length - MAX_EVENTS);
    }
    save(list);
    // Useful while developing — comment out before going live if too noisy.
    console.info("[analytics]", name, event.props, `venue=${event.venue}`);
    // Best-effort push to Supabase (fire-and-forget)
    try {
      const systemId = getSystemId();
      const db = getSupabaseClient();
      void db.from("paywifi_basic_analytics_events").insert({
        system_id: systemId,
        name: event.name,
        venue: event.venue,
        props: event.props,
        at: event.at,
      });
    } catch {
      /* supabase push failure must never break the user flow */
    }
  } catch {
    /* analytics must never break the user flow */
  }
}

/** Read-only list of all events, newest first. */
export function getAllEvents(): TrackedEvent[] {
  return load()
    .slice()
    .sort((a, b) => b.at - a.at);
}

export function clearEvents(): void {
  save([]);
}

export type FunnelStats = {
  home_view: number;
  voucher_submitted: number;
  voucher_validated_valid: number;
  voucher_validated_failed: number;
  plan_picked: number;
  checkout_submit: number;
  payment_success: number;
  payment_failed: number;
  start_browsing: number;
  /** payment_success / home_view, in [0,1]. */
  conversion_rate_home_to_pay: number;
  /** start_browsing / payment_success, in [0,1]. */
  conversion_rate_pay_to_browse: number;
  /** Sum of `price` across all payment_success events. */
  total_revenue: number;
};

/**
 * Roll up the raw event stream into a funnel summary. Filter by venue (or
 * by time window) by passing options.
 */
export function getFunnelStats(filter?: {
  venue?: string;
  sinceTimestamp?: number;
}): FunnelStats {
  const events = load().filter((e) => {
    if (filter?.venue && e.venue !== filter.venue) return false;
    if (filter?.sinceTimestamp && e.at < filter.sinceTimestamp) return false;
    return true;
  });

  const countOf = (name: EventName) => events.filter((e) => e.name === name).length;
  const countValidated = (kind: "valid" | "failed") =>
    events.filter((e) => {
      if (e.name !== "voucher_validated") return false;
      const ok = e.props.status === "valid";
      return kind === "valid" ? ok : !ok;
    }).length;

  const home_view = countOf("home_view");
  const payment_success = countOf("payment_success");
  const start_browsing = countOf("start_browsing");

  const total_revenue = events
    .filter((e) => e.name === "payment_success")
    .reduce(
      (sum, e) =>
        sum + (typeof e.props.price === "number" ? (e.props.price as number) : 0),
      0,
    );

  return {
    home_view,
    voucher_submitted: countOf("voucher_submitted"),
    voucher_validated_valid: countValidated("valid"),
    voucher_validated_failed: countValidated("failed"),
    plan_picked: countOf("plan_picked"),
    checkout_submit: countOf("checkout_submit"),
    payment_success,
    payment_failed: countOf("payment_failed"),
    start_browsing,
    conversion_rate_home_to_pay: home_view > 0 ? payment_success / home_view : 0,
    conversion_rate_pay_to_browse: payment_success > 0 ? start_browsing / payment_success : 0,
    total_revenue,
  };
}
