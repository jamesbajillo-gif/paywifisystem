/**
 * xendit-client.ts — CLIENT-SAFE Xendit config helpers.
 *
 * This file contains ONLY browser-compatible code (localStorage, no Node APIs).
 * It is the only Xendit module imported by client-side components (checkout.tsx,
 * PaymentSettings.tsx). The server-only logic lives in xendit.server.ts.
 *
 * Rule: never import from xendit.server.ts in a client component.
 *
 * Design: one active channel per module at a time (radio, not checkboxes).
 * `activeChannel` is null when Xendit is enabled but no channel is selected.
 */

/** Every Xendit channel ID we expose. */
export type XenditChannel =
  | "GCASH"
  | "PAYMAYA"
  | "SHOPEEPAY"
  | "OVO"
  | "DANA"
  | "LINKAJA"
  | "QRIS"
  | "QRPH"
  | "BPI"
  | "BDO"
  | "RCBC"
  | "UNIONBANK";

export type XenditChannelMeta = {
  id: XenditChannel;
  label: string;
  type: "EWALLET" | "QR_CODE" | "ONLINE_BANKING";
  countries: string;
};

export type XenditConfig = {
  enabled: boolean;
  /** The single active payment channel. null = Xendit enabled but none selected. */
  activeChannel: XenditChannel | null;
  apiKey: string;
  webhookToken: string;
};

// ─── Channel catalog ──────────────────────────────────────────────────────────

export const XENDIT_CHANNELS: XenditChannelMeta[] = [
  { id: "GCASH",      label: "GCash",      type: "EWALLET",        countries: "PH" },
  { id: "PAYMAYA",    label: "Maya",        type: "EWALLET",        countries: "PH" },
  { id: "SHOPEEPAY",  label: "ShopeePay",   type: "EWALLET",        countries: "PH, ID" },
  { id: "OVO",        label: "OVO",         type: "EWALLET",        countries: "ID" },
  { id: "DANA",       label: "DANA",        type: "EWALLET",        countries: "ID" },
  { id: "LINKAJA",    label: "LinkAja",     type: "EWALLET",        countries: "ID" },
  { id: "QRPH",       label: "QR PH",       type: "QR_CODE",        countries: "PH" },
  { id: "QRIS",       label: "QRIS",        type: "QR_CODE",        countries: "ID" },
  { id: "BPI",        label: "BPI Online",  type: "ONLINE_BANKING", countries: "PH" },
  { id: "BDO",        label: "BDO Online",  type: "ONLINE_BANKING", countries: "PH" },
  { id: "RCBC",       label: "RCBC",        type: "ONLINE_BANKING", countries: "PH" },
  { id: "UNIONBANK",  label: "UnionBank",   type: "ONLINE_BANKING", countries: "PH" },
];

const XENDIT_CONFIG_KEY = "paywifi:xendit-config";

export function defaultXenditConfig(): XenditConfig {
  // Default: Xendit enabled with GCash (EWALLET module) active.
  // Activating GCASH shows the full EWALLET group (GCash, Maya, ShopeePay) at checkout.
  return { enabled: true, activeChannel: "GCASH", apiKey: "", webhookToken: "" };
}

/** Read Xendit config from localStorage. Safe to call in any component. */
export function getXenditConfig(): XenditConfig {
  if (typeof window === "undefined") return defaultXenditConfig();
  try {
    const raw = window.localStorage.getItem(XENDIT_CONFIG_KEY);
    if (!raw) return defaultXenditConfig();
    const parsed = JSON.parse(raw) as Record<string, unknown>;

    // Migration: old shape had `channels: Record<XenditChannel, boolean>` —
    // pick the first enabled one as activeChannel.
    let activeChannel: XenditChannel | null = null;
    if (parsed.activeChannel && typeof parsed.activeChannel === "string") {
      activeChannel = parsed.activeChannel as XenditChannel;
    } else if (parsed.channels && typeof parsed.channels === "object") {
      const ch = parsed.channels as Record<string, boolean>;
      const first = XENDIT_CHANNELS.find((c) => ch[c.id] === true);
      activeChannel = first?.id ?? null;
    }

    return {
      enabled: typeof parsed.enabled === "boolean" ? parsed.enabled : false,
      activeChannel,
      apiKey: typeof parsed.apiKey === "string" ? parsed.apiKey : "",
      webhookToken: typeof parsed.webhookToken === "string" ? parsed.webhookToken : "",
    };
  } catch {
    return defaultXenditConfig();
  }
}

/** Persist Xendit config to localStorage. */
export function saveXenditConfig(config: XenditConfig): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(XENDIT_CONFIG_KEY, JSON.stringify(config));
  } catch { /* ignore */ }
}

/**
 * Returns the single active channel, or null if Xendit is disabled / no
 * channel is selected.
 */
export function getActiveXenditChannel(config: XenditConfig): XenditChannel | null {
  if (!config.enabled) return null;
  return config.activeChannel;
}

/** Returns the metadata for the active channel, or undefined. */
export function getActiveXenditChannelMeta(config: XenditConfig): XenditChannelMeta | undefined {
  const ch = getActiveXenditChannel(config);
  if (!ch) return undefined;
  return XENDIT_CHANNELS.find((c) => c.id === ch);
}

/**
 * Returns the active channel as a single-element array, or [] if none.
 * One channel active at a time — the selected channel is shown at checkout.
 */
export function getActiveXenditChannels(config: XenditConfig): XenditChannelMeta[] {
  const ch = getActiveXenditChannel(config);
  if (!ch) return [];
  const meta = XENDIT_CHANNELS.find((c) => c.id === ch);
  return meta ? [meta] : [];
}

