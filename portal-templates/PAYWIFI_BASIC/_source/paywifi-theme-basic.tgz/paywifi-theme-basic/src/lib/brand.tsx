/**
 * Brand + per-venue branding system.
 *
 * Each venue has a name, tagline, optional logo, an OKLCH primary-color
 * override, and a preferred e-payment provider. The active venue is picked
 * from `?venue=<slug>` on first load and persisted to sessionStorage so it
 * survives navigation within the captive-portal flow.
 *
 * Demo venues (try in the browser):
 *   /?venue=default          PAYWIFI (the default — blue, GCash)
 *   /?venue=cafe-luna        Café Luna (warm orange, GCash)
 *   /?venue=beachside-lodge  Beachside Lodge (teal, Maya)
 *   /?venue=metro-transit    Metro Transit (purple, QR PH)
 *
 * When milestone #1 (real backend) lands, `VENUES` becomes a DB-backed
 * lookup and the slug can be derived from a venue-scoped subdomain instead
 * of a query string.
 */

import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import type { PaymentMethod } from "@/lib/portal-api";
import { purgeExpired } from "@/lib/portal-api";

export type BrandConfig = {
  slug: string;
  /** Display name. Shown on home + used in fallback titles. */
  name: string;
  /** Short tagline. Used in meta description + home subtitle. */
  tagline: string;
  /** Optional logo image URL. Falls back to text rendering of `name`. */
  logoUrl?: string;
  /** Optional OKLCH override applied to `--primary`. Leave undefined to use the default token. */
  primaryColor?: string;
  /** Which e-payment provider this venue's /checkout grid shows next to Cash. */
  activeEpayment: Extract<PaymentMethod, "gcash" | "qrph" | "maya">;
};

export const VENUES: Record<string, BrandConfig> = {
  default: {
    slug: "default",
    name: "PAYWIFI",
    tagline: "Captive WiFi portal — connect with a voucher or buy a plan.",
    activeEpayment: "gcash",
    // no primaryColor override — uses --primary from styles.css
  },
  "cafe-luna": {
    slug: "cafe-luna",
    name: "Café Luna",
    tagline: "Free WiFi for café guests — ask your barista for a code.",
    primaryColor: "oklch(0.65 0.18 40)", // warm orange
    activeEpayment: "gcash",
  },
  "beachside-lodge": {
    slug: "beachside-lodge",
    name: "Beachside Lodge",
    tagline: "Lodge guest WiFi — vouchers on your room key.",
    primaryColor: "oklch(0.60 0.14 200)", // teal
    activeEpayment: "maya",
  },
  "metro-transit": {
    slug: "metro-transit",
    name: "Metro Transit",
    tagline: "Free WiFi while you ride. 1-hour sessions.",
    primaryColor: "oklch(0.55 0.18 290)", // purple
    activeEpayment: "qrph",
  },
};

/**
 * Static compatibility shim — points at the *default* venue's display name.
 * Used by route `head()` blocks which run before the React tree mounts, so
 * they can't yet read the active venue. Visible UI inside the React tree
 * should use `useBrand()` instead.
 */
export const BRAND = VENUES.default.name;

const SESSION_STORAGE_KEY = "paywifi:venue";

function resolveInitialVenue(): BrandConfig {
  if (typeof window === "undefined") return VENUES.default;

  // 1) URL query param wins — lets a customer reach a specific venue from a
  //    QR sign / signage / NFC tap.
  const params = new URLSearchParams(window.location.search);
  const urlSlug = params.get("venue");
  if (urlSlug && urlSlug in VENUES) {
    try {
      window.sessionStorage.setItem(SESSION_STORAGE_KEY, urlSlug);
    } catch {
      /* sessionStorage unavailable — fine, URL still wins this session */
    }
    return VENUES[urlSlug];
  }

  // 2) Sticky across navigation within the same browser tab.
  try {
    const stored = window.sessionStorage.getItem(SESSION_STORAGE_KEY);
    if (stored && stored in VENUES) return VENUES[stored];
  } catch {
    /* private-mode / disabled storage — fall through to default */
  }

  return VENUES.default;
}

const BrandContext = createContext<BrandConfig>(VENUES.default);

/** Read the active venue config from any component below `<BrandProvider>`. */
export function useBrand(): BrandConfig {
  return useContext(BrandContext);
}

/**
 * Provides the active venue + applies its `primaryColor` override to the
 * document root. Mount once at the router root.
 *
 * On SSR the initial render uses the default venue (no window). The client
 * resolves the actual venue in `useEffect` after hydration. For venues with
 * a custom palette this means a single-frame flash from the default blue to
 * the venue colour — acceptable for a demo; eliminated once milestone #1
 * gives us a venue-scoped subdomain (which the server can read at render).
 */
export function BrandProvider({ children }: { children: ReactNode }) {
  const [brand, setBrand] = useState<BrandConfig>(VENUES.default);

  // Resolve venue on mount.
  useEffect(() => {
    setBrand(resolveInitialVenue());
    // House-keeping: drop any cash references whose TTL elapsed before they
    // were paid. Keeps abandoned references from accumulating in localStorage
    // and ensures the admin's voucher table stays meaningful.
    purgeExpired();
  }, []);

  // Apply / clean up the OKLCH primary-color override on the root element.
  useEffect(() => {
    if (typeof document === "undefined") return;
    if (brand.primaryColor) {
      document.documentElement.style.setProperty("--primary", brand.primaryColor);
    } else {
      document.documentElement.style.removeProperty("--primary");
    }
    return () => {
      document.documentElement.style.removeProperty("--primary");
    };
  }, [brand.primaryColor]);

  return <BrandContext.Provider value={brand}>{children}</BrandContext.Provider>;
}
