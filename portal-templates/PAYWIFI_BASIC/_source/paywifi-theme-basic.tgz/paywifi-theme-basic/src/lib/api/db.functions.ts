/**
 * db.functions.ts — createServerFn wrappers for all Supabase DB operations.
 *
 * ALL writes go through here (server-side, service role key).
 * Reads for vouchers use anon key on client; reads for other tables
 * also come through here for consistency.
 *
 * ─── Offline guard ──────────────────────────────────────────────────────
 * Every function that creates/modifies data first checks DB health.
 * If DB is unreachable, returns { ok: false, error: "DB_OFFLINE" }.
 * UI components check for this error code and show the offline banner.
 */

import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getServerSupabaseClient, checkDbHealthServer } from "@/lib/supabase.server";

// ─── Health check ─────────────────────────────────────────────────────────

export const checkDbHealthFn = createServerFn({ method: "GET" })
  .handler(async () => {
    const ok = await checkDbHealthServer();
    return { ok };
  });

// ─── Shared helpers ───────────────────────────────────────────────────────

const DB_OFFLINE_RESULT = { ok: false as const, error: "DB_OFFLINE" };

async function assertDbOnline(): Promise<true | typeof DB_OFFLINE_RESULT> {
  const ok = await checkDbHealthServer();
  if (!ok) return DB_OFFLINE_RESULT;
  return true;
}

// ─── Voucher operations ───────────────────────────────────────────────────

const voucherSchema = z.object({
  system_id:         z.string(),
  code:              z.string().default(""),
  payment_reference: z.string().optional(),
  plan_id:           z.string(),
  issued_at:         z.number(),
  duration_minutes:  z.number(),
  transaction_id:    z.string().optional(),
  phone:             z.string().optional(),
  venue:             z.string().default("default"),
  store_id:          z.string().optional(),
  expires_at:        z.number().optional(),
});

export const addVoucherFn = createServerFn({ method: "POST" })
  .inputValidator(voucherSchema)
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return guard;
    const db = getServerSupabaseClient();
    const { error } = await db.from("paywifi_basic_vouchers").insert({
      system_id:         data.system_id,
      code:              data.code,
      payment_reference: data.payment_reference ?? null,
      plan_id:           data.plan_id,
      issued_at:         data.issued_at,
      duration_minutes:  data.duration_minutes,
      transaction_id:    data.transaction_id ?? null,
      phone:             data.phone ?? null,
      venue:             data.venue,
      store_id:          data.store_id ?? null,
      expires_at:        data.expires_at ?? null,
    });
    if (error) return { ok: false as const, error: error.message };
    return { ok: true as const };
  });

export const findVoucherFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({ code: z.string() }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return { ...guard, voucher: null };
    const db = getServerSupabaseClient();
    const { data: row, error } = await db
      .from("paywifi_basic_vouchers")
      .select("*")
      .eq("code", data.code.trim().toUpperCase())
      .maybeSingle();
    if (error) return { ok: false as const, error: error.message, voucher: null };
    return { ok: true as const, voucher: row ?? null };
  });

export const findByPaymentReferenceFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({ ref: z.string() }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return { ...guard, voucher: null };
    const db = getServerSupabaseClient();
    const { data: row, error } = await db
      .from("paywifi_basic_vouchers")
      .select("*")
      .eq("payment_reference", data.ref.trim().toUpperCase())
      .maybeSingle();
    if (error) return { ok: false as const, error: error.message, voucher: null };
    return { ok: true as const, voucher: row ?? null };
  });

export const markRedeemedFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({ code: z.string() }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return guard;
    const db = getServerSupabaseClient();
    const normalized = data.code.trim().toUpperCase();
    const { data: row } = await db
      .from("paywifi_basic_vouchers")
      .select("id, redeemed_at")
      .eq("code", normalized)
      .maybeSingle();
    if (!row || row.redeemed_at) return { ok: false as const, error: "Not found or already redeemed" };
    const { error } = await db
      .from("paywifi_basic_vouchers")
      .update({ redeemed_at: Date.now() })
      .eq("id", row.id);
    if (error) return { ok: false as const, error: error.message };
    return { ok: true as const };
  });

export const confirmAndIssueVoucherFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({ payment_reference: z.string(), voucher_code: z.string() }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return guard;
    const db = getServerSupabaseClient();
    const normalizedRef = data.payment_reference.trim().toUpperCase();
    const { data: row } = await db
      .from("paywifi_basic_vouchers")
      .select("id, confirmed_at, voided_at, redeemed_at, expires_at")
      .eq("payment_reference", normalizedRef)
      .maybeSingle();
    if (!row) return { ok: false as const, error: "Not found" };
    if (row.confirmed_at || row.voided_at || row.redeemed_at) {
      return { ok: false as const, error: "Already processed" };
    }
    if (row.expires_at && row.expires_at <= Date.now()) {
      return { ok: false as const, error: "Expired" };
    }
    const { error } = await db
      .from("paywifi_basic_vouchers")
      .update({ confirmed_at: Date.now(), code: data.voucher_code.trim().toUpperCase() })
      .eq("id", row.id);
    if (error) return { ok: false as const, error: error.message };
    return { ok: true as const };
  });

export const voidVoucherFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({ code_or_reference: z.string() }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return guard;
    const db = getServerSupabaseClient();
    const normalized = data.code_or_reference.trim().toUpperCase();
    const { data: row } = await db
      .from("paywifi_basic_vouchers")
      .select("id, voided_at, redeemed_at")
      .or(`code.eq.${normalized},payment_reference.eq.${normalized}`)
      .maybeSingle();
    if (!row || row.voided_at || row.redeemed_at) {
      return { ok: false as const, error: "Not found or already processed" };
    }
    const { error } = await db
      .from("paywifi_basic_vouchers")
      .update({ voided_at: Date.now() })
      .eq("id", row.id);
    if (error) return { ok: false as const, error: error.message };
    return { ok: true as const };
  });

export const getAllVouchersFn = createServerFn({ method: "GET" })
  .handler(async () => {
    const guard = await assertDbOnline();
    if (guard !== true) return { ...guard, vouchers: [] };
    const db = getServerSupabaseClient();
    const { data, error } = await db
      .from("paywifi_basic_vouchers")
      .select("*")
      .order("issued_at", { ascending: false })
      .limit(500);
    if (error) return { ok: false as const, error: error.message, vouchers: [] };
    return { ok: true as const, vouchers: data ?? [] };
  });

export const getActiveSessionsFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({ now: z.number() }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return { ...guard, sessions: [] };
    const db = getServerSupabaseClient();
    // Active sessions: redeemed, not voided, session window still open
    const { data: rows, error } = await db
      .from("paywifi_basic_vouchers")
      .select("*")
      .not("redeemed_at", "is", null)
      .is("voided_at", null);
    if (error) return { ok: false as const, error: error.message, sessions: [] };
    const active = (rows ?? []).filter((v: Record<string, unknown>) => {
      const expiresAt = (v.redeemed_at as number) + (v.duration_minutes as number) * 60 * 1000;
      return data.now < expiresAt;
    });
    return { ok: true as const, sessions: active };
  });

export const findPendingForVenueFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({ venue: z.string(), within_ms: z.number().optional() }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return { ...guard, voucher: null };
    const db = getServerSupabaseClient();
    const withinMs = data.within_ms ?? 15 * 60 * 1000;
    const cutoff = Date.now() - withinMs;
    const { data: rows, error } = await db
      .from("paywifi_basic_vouchers")
      .select("*")
      .eq("venue", data.venue)
      .is("redeemed_at", null)
      .is("voided_at", null)
      .is("confirmed_at", null)
      .not("payment_reference", "is", null)
      .gt("issued_at", cutoff)
      .order("issued_at", { ascending: false });
    if (error) return { ok: false as const, error: error.message, voucher: null };
    const now = Date.now();
    const pending = (rows ?? []).find((v: Record<string, unknown>) =>
      !v.expires_at || (v.expires_at as number) > now
    );
    return { ok: true as const, voucher: pending ?? null };
  });

// ─── Plans ────────────────────────────────────────────────────────────────

const DEFAULT_PLANS = [
  { plan_id: "hour", name: "1 Hour", description: "Perfect for a quick session.", duration: "60 minutes", duration_minutes: 60, speed: "10 Mbps", price: 1.99, popular: false, sort_order: 0 },
  { plan_id: "day",  name: "Day Pass", description: "Full-day access, great for working or browsing.", duration: "24 hours", duration_minutes: 60 * 24, speed: "25 Mbps", price: 4.99, popular: true, sort_order: 1 },
  { plan_id: "week", name: "Week Pass", description: "Best value for extended stays.", duration: "7 days", duration_minutes: 60 * 24 * 7, speed: "50 Mbps", price: 14.99, popular: false, sort_order: 2 },
];

export const getPlansFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({ system_id: z.string() }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return { ...guard, plans: DEFAULT_PLANS };
    const db = getServerSupabaseClient();
    const { data: rows, error } = await db
      .from("paywifi_basic_plans")
      .select("*")
      .eq("system_id", data.system_id)
      .eq("active", true)
      .order("sort_order");
    if (error || !rows || rows.length === 0) {
      // Seed defaults
      const seeds = DEFAULT_PLANS.map((p) => ({ ...p, system_id: data.system_id, active: true }));
      await db.from("paywifi_basic_plans").upsert(
        seeds.map((s) => ({ ...s })),
        { onConflict: "system_id,plan_id" }
      );
      return { ok: true as const, plans: DEFAULT_PLANS };
    }
    return { ok: true as const, plans: rows };
  });

export const upsertPlanFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({
    system_id:        z.string(),
    plan_id:          z.string(),
    name:             z.string(),
    description:      z.string().default(""),
    duration:         z.string(),
    duration_minutes: z.number(),
    speed:            z.string().optional(),
    price:            z.number(),
    epayment_fee:     z.number().optional(),
    popular:          z.boolean().default(false),
    sort_order:       z.number().default(0),
    active:           z.boolean().default(true),
  }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return guard;
    const db = getServerSupabaseClient();
    const { error } = await db
      .from("paywifi_basic_plans")
      .upsert({ ...data, updated_at: new Date().toISOString() }, { onConflict: "system_id,plan_id" });
    if (error) return { ok: false as const, error: error.message };
    return { ok: true as const };
  });

export const deletePlanFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({ system_id: z.string(), plan_id: z.string() }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return guard;
    const db = getServerSupabaseClient();
    const { error } = await db
      .from("paywifi_basic_plans")
      .update({ active: false, updated_at: new Date().toISOString() })
      .eq("system_id", data.system_id)
      .eq("plan_id", data.plan_id);
    if (error) return { ok: false as const, error: error.message };
    return { ok: true as const };
  });

// ─── Analytics ────────────────────────────────────────────────────────────

export const trackEventFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({
    system_id: z.string(),
    name:      z.string(),
    venue:     z.string().default("default"),
    props:     z.record(z.unknown()).default({}),
    at:        z.number(),
  }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return guard;
    const db = getServerSupabaseClient();
    const { error } = await db.from("paywifi_basic_analytics_events").insert({
      system_id: data.system_id,
      name:      data.name,
      venue:     data.venue,
      props:     data.props,
      at:        data.at,
    });
    if (error) return { ok: false as const, error: error.message };
    return { ok: true as const };
  });

export const getAnalyticsFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({
    system_id: z.string(),
    venue:     z.string().optional(),
    since:     z.number().optional(),
    limit:     z.number().default(500),
  }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return { ...guard, events: [] };
    const db = getServerSupabaseClient();
    let q = db
      .from("paywifi_basic_analytics_events")
      .select("*")
      .eq("system_id", data.system_id)
      .order("at", { ascending: false })
      .limit(data.limit);
    if (data.venue) q = q.eq("venue", data.venue);
    if (data.since)  q = q.gt("at", data.since);
    const { data: rows, error } = await q;
    if (error) return { ok: false as const, error: error.message, events: [] };
    return { ok: true as const, events: rows ?? [] };
  });

// ─── Credits ──────────────────────────────────────────────────────────────

export const getCreditsFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({ system_id: z.string() }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return { ...guard, record: null };
    const db = getServerSupabaseClient();
    const { data: row } = await db
      .from("paywifi_basic_credits")
      .select("*")
      .eq("system_id", data.system_id)
      .maybeSingle();
    if (!row) {
      const fresh = { system_id: data.system_id, balance: 500, total_purchased: 500, total_consumed: 0 };
      await db.from("paywifi_basic_credits").insert(fresh);
      return { ok: true as const, record: fresh };
    }
    return { ok: true as const, record: row };
  });

export const deductCreditsFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({ system_id: z.string(), amount: z.number() }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return { ...guard, success: false };
    const db = getServerSupabaseClient();
    const cost = Math.ceil(data.amount);
    const { data: row } = await db
      .from("paywifi_basic_credits")
      .select("id, balance, total_consumed")
      .eq("system_id", data.system_id)
      .maybeSingle();
    if (!row || row.balance < cost) return { ok: true as const, success: false };
    const { error } = await db
      .from("paywifi_basic_credits")
      .update({
        balance: row.balance - cost,
        total_consumed: row.total_consumed + cost,
        updated_at: new Date().toISOString(),
      })
      .eq("id", row.id);
    if (error) return { ok: false as const, error: error.message, success: false };
    return { ok: true as const, success: true };
  });

// ─── Pending digital payments ─────────────────────────────────────────────

const pendingDigitalSchema = z.object({
  system_id:      z.string(),
  transaction_id: z.string(),
  plan_id:        z.string(),
  method:         z.string(),
  venue:          z.string(),
  issued_at:      z.number(),
  expires_at:     z.number(),
  code:           z.string(),
});

export const recordPendingDigitalFn = createServerFn({ method: "POST" })
  .inputValidator(pendingDigitalSchema)
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return guard;
    const db = getServerSupabaseClient();
    // Purge expired first
    await db
      .from("paywifi_basic_pending_digital")
      .delete()
      .lt("expires_at", Date.now());
    const { error } = await db
      .from("paywifi_basic_pending_digital")
      .upsert(data, { onConflict: "system_id,transaction_id" });
    if (error) return { ok: false as const, error: error.message };
    return { ok: true as const };
  });

export const clearPendingDigitalFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({ system_id: z.string(), transaction_id: z.string() }))
  .handler(async ({ data }) => {
    const db = getServerSupabaseClient();
    await db
      .from("paywifi_basic_pending_digital")
      .delete()
      .eq("system_id", data.system_id)
      .eq("transaction_id", data.transaction_id);
    return { ok: true as const };
  });

export const findPendingDigitalFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({ system_id: z.string(), venue: z.string() }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return { ...guard, record: null };
    const db = getServerSupabaseClient();
    const now = Date.now();
    const { data: rows } = await db
      .from("paywifi_basic_pending_digital")
      .select("*")
      .eq("system_id", data.system_id)
      .eq("venue", data.venue)
      .gt("expires_at", now);
    if (!rows || rows.length === 0) return { ok: true as const, record: null };
    // Check if any are not yet redeemed
    for (const r of rows) {
      const { data: v } = await db
        .from("paywifi_basic_vouchers")
        .select("redeemed_at")
        .eq("code", r.code)
        .maybeSingle();
      if (!v?.redeemed_at) return { ok: true as const, record: r };
    }
    return { ok: true as const, record: null };
  });

// ─── Refunds ──────────────────────────────────────────────────────────────

export const getRefundsFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({ system_id: z.string() }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return { ...guard, refunds: [] };
    const db = getServerSupabaseClient();
    const { data: rows, error } = await db
      .from("paywifi_basic_refunds")
      .select("*")
      .eq("system_id", data.system_id)
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) return { ok: false as const, error: error.message, refunds: [] };
    return { ok: true as const, refunds: rows ?? [] };
  });

export const createRefundFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({
    system_id:      z.string(),
    voucher_code:   z.string(),
    plan_id:        z.string(),
    sale_amount:    z.number(),
    sale_timestamp: z.number(),
    reason:         z.string(),
    notes:          z.string().optional(),
  }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return { ...guard, refund: null };
    const REFUND_WINDOW_MS = 48 * 60 * 60 * 1000;
    if (Date.now() - data.sale_timestamp > REFUND_WINDOW_MS) {
      return { ok: false as const, error: "Outside refund window", refund: null };
    }
    const db = getServerSupabaseClient();
    // Check existing
    const { data: existing } = await db
      .from("paywifi_basic_refunds")
      .select("*")
      .eq("system_id", data.system_id)
      .eq("voucher_code", data.voucher_code)
      .neq("status", "rejected")
      .maybeSingle();
    if (existing) return { ok: true as const, refund: existing };
    // Get auto_approve config
    const { data: cfg } = await db
      .from("paywifi_basic_refund_config")
      .select("auto_approve")
      .eq("system_id", data.system_id)
      .maybeSingle();
    const autoApprove = cfg?.auto_approve ?? true;
    const now = new Date().toISOString();
    const { data: row, error } = await db
      .from("paywifi_basic_refunds")
      .insert({
        system_id:   data.system_id,
        voucher_code: data.voucher_code,
        plan_id:     data.plan_id,
        sale_amount: data.sale_amount,
        reason:      data.reason,
        notes:       data.notes ?? null,
        status:      autoApprove ? "approved" : "pending",
        resolved_at: autoApprove ? now : null,
        resolved_by: autoApprove ? "auto" : null,
      })
      .select()
      .single();
    if (error) return { ok: false as const, error: error.message, refund: null };
    return { ok: true as const, refund: row };
  });

export const resolveRefundFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({
    system_id: z.string(),
    id:        z.string(),
    action:    z.enum(["approve", "reject"]),
  }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return guard;
    const db = getServerSupabaseClient();
    const { error } = await db
      .from("paywifi_basic_refunds")
      .update({
        status:      data.action === "approve" ? "approved" : "rejected",
        resolved_at: new Date().toISOString(),
        resolved_by: "admin",
      })
      .eq("id", data.id)
      .eq("system_id", data.system_id)
      .eq("status", "pending");
    if (error) return { ok: false as const, error: error.message };
    return { ok: true as const };
  });

// ─── Phone edit log ───────────────────────────────────────────────────────

export const getPhoneEditLogFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({ system_id: z.string(), payment_reference: z.string() }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return { ...guard, log: null };
    const db = getServerSupabaseClient();
    const { data: row } = await db
      .from("paywifi_basic_phone_edit_logs")
      .select("*")
      .eq("system_id", data.system_id)
      .eq("payment_reference", data.payment_reference.trim().toUpperCase())
      .maybeSingle();
    return { ok: true as const, log: row ?? null };
  });

export const updateVoucherPhoneFn = createServerFn({ method: "POST" })
  .inputValidator(z.object({
    system_id:    z.string(),
    ref:          z.string(),
    new_phone:    z.string(),
  }))
  .handler(async ({ data }) => {
    const guard = await assertDbOnline();
    if (guard !== true) return guard;
    const db = getServerSupabaseClient();
    const normalized = data.ref.trim().toUpperCase();
    // Fetch the voucher
    const { data: v } = await db
      .from("paywifi_basic_vouchers")
      .select("id, confirmed_at, voided_at, redeemed_at, payment_reference")
      .eq("payment_reference", normalized)
      .maybeSingle();
    if (!v) return { ok: false as const, error: "not_found" };
    if (v.confirmed_at || v.voided_at || v.redeemed_at) {
      return { ok: false as const, error: "already_processed" };
    }
    // Fetch edit log
    const { data: log } = await db
      .from("paywifi_basic_phone_edit_logs")
      .select("*")
      .eq("system_id", data.system_id)
      .eq("payment_reference", normalized)
      .maybeSingle();
    const edits: number[] = log?.edits ?? [];
    const lastEditAt: number = log?.last_edit_at ?? 0;
    const COOLDOWN = 30_000;
    const MAX = 3;
    if (edits.length >= MAX) return { ok: false as const, error: "limit_reached" };
    const now = Date.now();
    if (lastEditAt > 0 && now - lastEditAt < COOLDOWN) {
      return { ok: false as const, error: "cooldown", cooldown_ms: COOLDOWN - (now - lastEditAt) };
    }
    const newEdits = [...edits, now];
    await db.from("paywifi_basic_phone_edit_logs").upsert({
      system_id: data.system_id,
      payment_reference: normalized,
      edits: newEdits,
      last_edit_at: now,
      updated_at: new Date().toISOString(),
    }, { onConflict: "system_id,payment_reference" });
    await db.from("paywifi_basic_vouchers").update({ phone: data.new_phone || null }).eq("id", v.id);
    return { ok: true as const };
  });
