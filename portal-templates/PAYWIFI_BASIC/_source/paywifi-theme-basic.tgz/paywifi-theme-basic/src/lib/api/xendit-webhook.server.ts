/**
 * xendit-webhook.server.ts — server-only webhook helpers.
 *
 * Marked `.server.ts` so Vite strips this whole module (and its node-only
 * imports like `node:process` / `node:crypto`) from the client bundle.
 * Anything in this file MUST stay server-only — never import from it in a
 * .tsx/.ts file that gets client-bundled, except via a `.server.ts`
 * re-export.
 */

import process from "node:process";
import { createHmac, timingSafeEqual } from "node:crypto";

import { getServerSupabaseClient } from "@/lib/supabase.server";
import { getXenditConfig as _getDefaultXenditConfig } from "@/lib/xendit.server"; // re-uses defaults
import { handleXenditPaymentSuccessImpl, handleXenditPaymentFailureImpl } from "@/lib/api/payment-impl.server";

// ─── Xendit webhook payload shape (v2) ───────────────────────────────────
export type XenditWebhookEvent = {
  event?: string;
  data?: {
    id?: string;
    status?: string;
    reference_id?: string;
    metadata?: Record<string, unknown>;
  };
  status?: string;
  reference_id?: string;
  id?: string;
};

// ─── DB lookups ──────────────────────────────────────────────────────────
export async function findSystemIdForTransaction(transactionId: string): Promise<string | null> {
  const db = getServerSupabaseClient();
  const { data } = await db
    .from("paywifi_basic_pending_digital")
    .select("system_id")
    .eq("transaction_id", transactionId)
    .maybeSingle();
  return (data?.system_id as string | undefined) ?? null;
}

export async function getWebhookExpectedToken(systemId: string): Promise<string> {
  const db = getServerSupabaseClient();
  const { data } = await db
    .from("paywifi_basic_xendit_config")
    .select("webhook_token")
    .eq("system_id", systemId)
    .maybeSingle();
  return (
    (data?.webhook_token as string | undefined) ||
    process.env.XENDIT_WEBHOOK_TOKEN ||
    ""
  );
}

// ─── Structured logger ───────────────────────────────────────────────────
function wlog(
  phase: "received" | "validated" | "dispatched" | "duplicate" | "invalid" | "error",
  fields: Record<string, unknown>,
): void {
  try {
    console.info(JSON.stringify({ at: "xendit-webhook", phase, ts: Date.now(), ...fields }));
  } catch {
    console.info("[xendit-webhook]", phase, fields);
  }
}

// ─── Constant-time string equality ───────────────────────────────────────
function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  try {
    return timingSafeEqual(Buffer.from(a, "utf8"), Buffer.from(b, "utf8"));
  } catch {
    return a === b;
  }
}

// ─── HMAC-SHA256 verifier ────────────────────────────────────────────────
function verifyHmacSignature(rawBody: string, headerSig: string | null): boolean {
  const signingKey = process.env.XENDIT_WEBHOOK_SIGNING_KEY ?? "";
  if (!signingKey) return true; // not enforced
  if (!headerSig) return false;
  const expected = createHmac("sha256", signingKey).update(rawBody).digest("hex");
  return safeEqual(expected, headerSig.trim().toLowerCase());
}

// ─── In-memory replay-protection cache ───────────────────────────────────
const REPLAY_TTL_MS = 10 * 60 * 1000;
const replayCache = new Map<string, number>();
function isReplay(key: string): boolean {
  const now = Date.now();
  if (replayCache.size > 1024) {
    for (const [k, ts] of replayCache) {
      if (now - ts > REPLAY_TTL_MS) replayCache.delete(k);
    }
  }
  const seenAt = replayCache.get(key);
  if (seenAt && now - seenAt < REPLAY_TTL_MS) return true;
  replayCache.set(key, now);
  return false;
}

function jsonOk(body: Record<string, unknown> = { received: true }, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });
}

// ─── Main request handler ───────────────────────────────────────────────
export async function handleXenditWebhookRequest(request: Request): Promise<Response> {
  // 1. Read raw body once
  let rawBody = "";
  try {
    rawBody = await request.text();
  } catch (e) {
    wlog("error", { reason: "bad_body", err: String(e) });
    return jsonOk({ ok: false, reason: "bad_body" });
  }
  wlog("received", { bytes: rawBody.length });

  // 2. Parse JSON
  let payload: XenditWebhookEvent;
  try {
    payload = JSON.parse(rawBody) as XenditWebhookEvent;
  } catch {
    wlog("invalid", { reason: "bad_json" });
    return jsonOk({ ok: false, reason: "bad_json" });
  }

  const referenceId = payload.data?.reference_id ?? payload.reference_id ?? null;
  if (!referenceId) {
    wlog("invalid", { reason: "no_reference" });
    return jsonOk({ ok: false, reason: "no_reference" });
  }

  const status = (payload.data?.status ?? payload.status ?? "").toUpperCase();
  const eventId = payload.data?.id ?? payload.id ?? "";

  // 3. Replay short-circuit (in-memory)
  if (isReplay(`${referenceId}:${status}`)) {
    wlog("duplicate", { referenceId, status, eventId });
    return jsonOk({ ok: true, duplicate: true });
  }

  // 4. Resolve system_id from pending row
  const systemId = await findSystemIdForTransaction(referenceId);
  if (!systemId) {
    wlog("validated", { referenceId, status, eventId, result: "no_pending" });
    return jsonOk({ ok: true, reason: "no_pending" });
  }

  // 5. Token check (constant-time)
  const expectedToken = await getWebhookExpectedToken(systemId);
  const incomingToken =
    request.headers.get("x-callback-token") ??
    request.headers.get("X-Callback-Token") ??
    "";

  if (!expectedToken) {
    if (process.env.NODE_ENV === "production" && !process.env.ALLOW_UNVERIFIED_WEBHOOK) {
      wlog("invalid", { reason: "no_token_configured", referenceId });
      return jsonOk({ ok: false, reason: "no_token_configured" });
    }
  } else if (!safeEqual(incomingToken, expectedToken)) {
    wlog("invalid", { reason: "bad_token", referenceId });
    return jsonOk({ ok: false, reason: "bad_token" });
  }

  // 6. Optional HMAC signature
  const sigHeader =
    request.headers.get("x-xendit-signature") ??
    request.headers.get("X-Xendit-Signature");
  if (!verifyHmacSignature(rawBody, sigHeader)) {
    wlog("invalid", { reason: "bad_signature", referenceId });
    return jsonOk({ ok: false, reason: "bad_signature" });
  }

  wlog("validated", { referenceId, status, eventId, systemId });

  // 7. Dispatch
  if (status === "SUCCEEDED") {
    const result = await handleXenditPaymentSuccessImpl(systemId, referenceId);
    if (!result.ok) {
      wlog("error", { reason: "success_handler_failed", referenceId, err: result.error });
    } else {
      wlog("dispatched", {
        referenceId,
        status,
        alreadyIssued: result.alreadyIssued ?? false,
        code: result.code,
      });
    }
    return jsonOk({ ok: result.ok });
  }

  if (status === "FAILED" || status === "VOIDED" || status === "EXPIRED") {
    await handleXenditPaymentFailureImpl(systemId, referenceId);
    wlog("dispatched", { referenceId, status, action: "cleared_pending" });
    return jsonOk({ ok: true });
  }

  wlog("dispatched", { referenceId, status, action: "noop" });
  return jsonOk({ ok: true, status });
}

// Suppress unused warning for the re-exported default config getter (kept
// for future use by the helpers).
void _getDefaultXenditConfig;
