/**
 * payment.functions.ts — TanStack createServerFn wrappers for Xendit.
 *
 * These run server-side only. The client calls them like async functions;
 * TanStack Start serialises the call over HTTP automatically.
 *
 * Config is persisted in Supabase (paywifi_basic_xendit_config), keyed by
 * system_id passed from the client. Falls back to env vars when no DB row exists.
 */

import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import process from "node:process";

import {
  createPaymentRequest,
  getPaymentRequestStatus,
  pingXenditKey,
  defaultXenditConfig,
  XENDIT_CHANNELS,
  type XenditChannel,
  type XenditConfig,
} from "@/lib/xendit.server";
import { getServerSupabaseClient } from "@/lib/supabase.server";

// Re-export types the client side needs.
export type { XenditChannel, XenditConfig };
export { XENDIT_CHANNELS };

// ─── Supabase helpers (server-only) ──────────────────────────────────────────

async function getXenditConfigFromDb(systemId: string): Promise<XenditConfig> {
  try {
    const db = getServerSupabaseClient();
    const { data, error } = await db
      .from("paywifi_basic_xendit_config")
      .select("enabled, active_channel, api_key, webhook_token")
      .eq("system_id", systemId)
      .maybeSingle();
    if (error || !data) return defaultXenditConfig();
    const row = data as {
      enabled: boolean;
      active_channel: string | null;
      api_key: string;
      webhook_token: string;
    };
    return {
      enabled: row.enabled,
      activeChannel: (row.active_channel as XenditChannel | null) ?? null,
      apiKey: row.api_key || process.env.XENDIT_SECRET_KEY || "",
      webhookToken: row.webhook_token || process.env.XENDIT_WEBHOOK_TOKEN || "",
    };
  } catch {
    return defaultXenditConfig();
  }
}

async function saveXenditConfigToDb(systemId: string, config: XenditConfig): Promise<void> {
  try {
    const db = getServerSupabaseClient();
    await db.from("paywifi_basic_xendit_config").upsert(
      {
        system_id: systemId,
        enabled: config.enabled,
        active_channel: config.activeChannel,
        api_key: config.apiKey,
        webhook_token: config.webhookToken,
      },
      { onConflict: "system_id" },
    );
  } catch (e) {
    console.warn("[supabase] saveXenditConfig failed:", e);
  }
}

// ─── initiateXenditPayment ────────────────────────────────────────────────────

/**
 * Normalize a Philippine phone to Xendit's expected E.164 format (+63...).
 * Returns null if the input doesn't look like a PH mobile.
 *
 *   "09171234567"   → "+639171234567"
 *   "9171234567"    → "+639171234567"
 *   "639171234567"  → "+639171234567"
 *   "+639171234567" → "+639171234567"
 *   "abc"           → null
 */
function normalizePhPhone(raw: string | undefined): string | undefined {
  if (!raw) return undefined;
  const digits = raw.replace(/[^\d]/g, "");
  if (digits.length === 11 && digits.startsWith("09")) {
    return `+63${digits.slice(1)}`;
  }
  if (digits.length === 10 && digits.startsWith("9")) {
    return `+63${digits}`;
  }
  if (digits.length === 12 && digits.startsWith("639")) {
    return `+${digits}`;
  }
  if (digits.length === 13 && digits.startsWith("0063")) {
    return `+${digits.slice(2)}`;
  }
  if (raw.startsWith("+63") && digits.length === 12) {
    return `+${digits}`;
  }
  return undefined;
}

const initiateSchema = z.object({
  channel: z.string(),
  amount: z.number().positive(),
  referenceId: z.string(),
  successReturnUrl: z.string().url(),
  failureReturnUrl: z.string().url(),
  phoneNumber: z.string().optional(),
  metadata: z.record(z.string()).optional(),
  system_id: z.string().optional(),
});

export const initiateXenditPayment = createServerFn({ method: "POST" })
  .inputValidator(initiateSchema)
  .handler(async ({ data }) => {
    const systemId = data.system_id ?? "server";
    const config = await getXenditConfigFromDb(systemId);

    if (!config.enabled) {
      return { ok: false as const, error: "Xendit payments are not enabled" };
    }

    const apiKey = config.apiKey || process.env.XENDIT_SECRET_KEY || "";
    if (!apiKey) {
      return { ok: false as const, error: "Xendit API key not configured" };
    }

    return createPaymentRequest({
      amount: data.amount,
      channel: data.channel as XenditChannel,
      referenceId: data.referenceId,
      successReturnUrl: data.successReturnUrl,
      failureReturnUrl: data.failureReturnUrl,
      // Xendit GCash requires Philippine mobile in E.164 format. Normalize
      // common user inputs and drop the value if it doesn't look like a PH
      // mobile so we don't trigger a Xendit validation error on an
      // optional field.
      phoneNumber: normalizePhPhone(data.phoneNumber),
      metadata: data.metadata,
      apiKey,
    });
  });

// ─── getXenditConfigServer ────────────────────────────────────────────────────

const getConfigSchema = z.object({ system_id: z.string() });

export const getXenditConfigServer = createServerFn({ method: "POST" })
  .inputValidator(getConfigSchema)
  .handler(async ({ data }) => {
    const config = await getXenditConfigFromDb(data.system_id);
    const maskedKey = config.apiKey
      ? "x".repeat(Math.max(0, config.apiKey.length - 6)) + config.apiKey.slice(-6)
      : "";
    const maskedWebhook = config.webhookToken
      ? "x".repeat(Math.max(0, config.webhookToken.length - 6)) + config.webhookToken.slice(-6)
      : "";
    return {
      enabled: config.enabled,
      activeChannel: config.activeChannel,
      maskedApiKey: maskedKey,
      // Returns ONLY a masked tail of the webhook token. The full token
      // stays server-side — Xendit's POST callback supplies it via header
      // and we compare it via timingSafeEqual against the stored value.
      webhookToken: maskedWebhook,
      hasEnvApiKey: Boolean(process.env.XENDIT_SECRET_KEY),
      hasEnvWebhookToken: Boolean(process.env.XENDIT_WEBHOOK_TOKEN),
    };
  });

// ─── saveXenditConfigServer ───────────────────────────────────────────────────

const saveConfigSchema = z.object({
  system_id: z.string(),
  enabled: z.boolean(),
  activeChannel: z.string().nullable(),
  newApiKey: z.string().optional(),
});

export const saveXenditConfigServer = createServerFn({ method: "POST" })
  .inputValidator(saveConfigSchema)
  .handler(async ({ data }) => {
    const existing = await getXenditConfigFromDb(data.system_id);
    const updated: XenditConfig = {
      enabled: data.enabled,
      activeChannel: (data.activeChannel as XenditChannel | null) ?? null,
      apiKey: data.newApiKey?.trim() || existing.apiKey || process.env.XENDIT_SECRET_KEY || "",
      webhookToken: existing.webhookToken || process.env.XENDIT_WEBHOOK_TOKEN || "",
    };
    await saveXenditConfigToDb(data.system_id, updated);
    return { ok: true as const };
  });

// ─── pingXenditKeyServer ──────────────────────────────────────────────────────

const pingSchema = z.object({ apiKey: z.string().min(1) });

export const pingXenditKeyServer = createServerFn({ method: "POST" })
  .inputValidator(pingSchema)
  .handler(async ({ data }) => {
    const valid = await pingXenditKey(data.apiKey);
    return { valid };
  });

// ─── pollXenditPaymentStatusServer ───────────────────────────────────────────

const pollStatusSchema = z.object({
  paymentRequestId: z.string().min(1),
  system_id: z.string().optional(),
});

export const pollXenditPaymentStatusServer = createServerFn({ method: "POST" })
  .inputValidator(pollStatusSchema)
  .handler(async ({ data }) => {
    const config = await getXenditConfigFromDb(data.system_id ?? "server");
    const apiKey = config.apiKey || process.env.XENDIT_SECRET_KEY || "";
    if (!apiKey) {
      return { ok: false as const, error: "Xendit API key not configured" };
    }
    return getPaymentRequestStatus({ paymentRequestId: data.paymentRequestId, apiKey });
  });

// ─── resetXenditConfigServer ──────────────────────────────────────────────────

const resetConfigSchema = z.object({ system_id: z.string() });

export const resetXenditConfigServer = createServerFn({ method: "POST" })
  .inputValidator(resetConfigSchema)
  .handler(async ({ data }) => {
    await saveXenditConfigToDb(data.system_id, defaultXenditConfig());
    return { ok: true as const };
  });

// ─── Idempotent voucher issuance — RPC wrapper ────────────────────────────────
// The actual logic lives in payment-impl.server.ts so it can be called from
// both this createServerFn (client polling path) AND the webhook receiver
// (direct in-process call) without dragging server-only modules into the
// client bundle.

const handleSuccessSchema = z.object({
  system_id: z.string(),
  transaction_id: z.string().min(1),
});

export const handleXenditPaymentSuccess = createServerFn({ method: "POST" })
  .inputValidator(handleSuccessSchema)
  .handler(async ({ data }) => {
    const { handleXenditPaymentSuccessImpl } = await import("@/lib/api/payment-impl.server");
    return handleXenditPaymentSuccessImpl(data.system_id, data.transaction_id);
  });

export const handleXenditPaymentFailure = createServerFn({ method: "POST" })
  .inputValidator(handleSuccessSchema)
  .handler(async ({ data }) => {
    const { handleXenditPaymentFailureImpl } = await import("@/lib/api/payment-impl.server");
    return handleXenditPaymentFailureImpl(data.system_id, data.transaction_id);
  });
