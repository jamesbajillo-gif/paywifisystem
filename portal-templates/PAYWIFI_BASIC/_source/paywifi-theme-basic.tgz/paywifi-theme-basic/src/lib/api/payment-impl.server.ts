/**
 * payment-impl.server.ts — server-only implementations of the idempotent
 * payment-success / payment-failure handlers.
 *
 * Marked `.server.ts` so Vite strips it from the client bundle. The plain
 * functions here are called from BOTH:
 *  - The createServerFn wrappers in payment.functions.ts (used by client
 *    polling — exposed as RPC stubs to the browser).
 *  - The webhook request handler in xendit-webhook.server.ts (used by
 *    Xendit callbacks — direct in-process call).
 */

import { getServerSupabaseClient } from "@/lib/supabase.server";

const VOUCHER_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
function generateVoucherCode(): string {
  let payload = "";
  for (let i = 0; i < 12; i++) {
    payload += VOUCHER_ALPHABET[Math.floor(Math.random() * VOUCHER_ALPHABET.length)];
  }
  return `${payload.slice(0, 4)}-${payload.slice(4, 8)}-${payload.slice(8, 12)}`;
}

export type HandleSuccessResult =
  | { ok: true; code: string; planId: string; durationMinutes: number; alreadyIssued: boolean }
  | { ok: false; error: string };

/**
 * Issues a voucher for a confirmed Xendit payment. Idempotent: if a voucher
 * already exists for this transaction_id, returns it unchanged (no
 * double-issue, no credit deduction).
 */
export async function handleXenditPaymentSuccessImpl(
  systemId: string,
  transactionId: string,
): Promise<HandleSuccessResult> {
  const db = getServerSupabaseClient();

  // 1. Idempotency check
  const { data: existing } = await db
    .from("paywifi_basic_vouchers")
    .select("code, plan_id, duration_minutes")
    .eq("transaction_id", transactionId)
    .maybeSingle();

  if (existing?.code) {
    return {
      ok: true,
      code: existing.code as string,
      planId: existing.plan_id as string,
      durationMinutes: existing.duration_minutes as number,
      alreadyIssued: true,
    };
  }

  // 2. Find the pending payment
  const { data: pending } = await db
    .from("paywifi_basic_pending_digital")
    .select("plan_id, method, venue, code, issued_at")
    .eq("system_id", systemId)
    .eq("transaction_id", transactionId)
    .maybeSingle();

  if (!pending) {
    return { ok: false, error: "Pending payment not found for this transaction." };
  }

  // 3. Resolve plan duration
  const { data: planRow } = await db
    .from("paywifi_basic_plans")
    .select("duration_minutes")
    .eq("system_id", systemId)
    .eq("plan_id", pending.plan_id)
    .maybeSingle();

  const durationMinutes =
    (planRow?.duration_minutes as number | undefined) ??
    (pending.plan_id === "hour"
      ? 60
      : pending.plan_id === "week"
      ? 60 * 24 * 7
      : 60 * 24);

  const voucherCode =
    pending.code && (pending.code as string).length > 0
      ? (pending.code as string)
      : generateVoucherCode();

  // 4. Insert the voucher
  const { error: insertErr } = await db.from("paywifi_basic_vouchers").insert({
    system_id: systemId,
    code: voucherCode,
    payment_reference: null,
    plan_id: pending.plan_id,
    issued_at: Date.now(),
    duration_minutes: durationMinutes,
    transaction_id: transactionId,
    phone: null,
    venue: pending.venue,
    store_id: null,
    expires_at: null,
  });

  if (insertErr) {
    // Race: another caller (webhook vs poller) won — re-fetch existing.
    const { data: raced } = await db
      .from("paywifi_basic_vouchers")
      .select("code, plan_id, duration_minutes")
      .eq("transaction_id", transactionId)
      .maybeSingle();
    if (raced?.code) {
      return {
        ok: true,
        code: raced.code as string,
        planId: raced.plan_id as string,
        durationMinutes: raced.duration_minutes as number,
        alreadyIssued: true,
      };
    }
    return { ok: false, error: insertErr.message };
  }

  // 5. Clear pending row
  await db
    .from("paywifi_basic_pending_digital")
    .delete()
    .eq("system_id", systemId)
    .eq("transaction_id", transactionId);

  return {
    ok: true,
    code: voucherCode,
    planId: pending.plan_id as string,
    durationMinutes,
    alreadyIssued: false,
  };
}

export async function handleXenditPaymentFailureImpl(
  systemId: string,
  transactionId: string,
): Promise<{ ok: true }> {
  const db = getServerSupabaseClient();
  await db
    .from("paywifi_basic_pending_digital")
    .delete()
    .eq("system_id", systemId)
    .eq("transaction_id", transactionId);
  return { ok: true };
}
