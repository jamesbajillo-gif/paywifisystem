/**
 * supabase.ts — browser-side Supabase client + system identifier.
 *
 * NEVER import this from a .server.ts file. Use supabase.server.ts there.
 *
 * ─── System identifier ──────────────────────────────────────────────────
 * Each captive portal instance generates a UUID on first boot, stored in
 * localStorage as `paywifi:system_id`. This UUID is stamped on every write
 * so records from multiple physical deployments can coexist in the same DB.
 *
 * VOUCHER READS are global (no system_id filter) — a voucher issued on
 * portal A can be validated on portal B. system_id on vouchers is audit only.
 */

import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { resolveApiBase, getApiBaseSync } from "@/lib/local-api";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL
  ?? import.meta.env.NEXT_PUBLIC_SUPABASE_URL
  ?? "https://db.techpinoy.net";

const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY
  ?? import.meta.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  ?? "";

let _client: SupabaseClient | null = null;

/** Browser-side Supabase client (anon key). Lazily created. */
export function getSupabaseClient(): SupabaseClient {
  if (!_client) {
    _client = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: { persistSession: false },
    });
  }
  return _client;
}

// ─── System ID ────────────────────────────────────────────────────────────

const SYSTEM_ID_KEY = "paywifi:system_id";

/**
 * Returns this portal instance's unique system identifier.
 * Generated once (UUID v4) and persisted in localStorage.
 * Safe to call on the server — returns "server" as a fallback.
 */
export function getSystemId(): string {
  if (typeof window === "undefined") return "server";
  try {
    const existing = window.localStorage.getItem(SYSTEM_ID_KEY);
    if (existing) return existing;
    const id = generateUUID();
    window.localStorage.setItem(SYSTEM_ID_KEY, id);
    return id;
  } catch {
    return "fallback-" + Date.now();
  }
}

function generateUUID(): string {
  if (typeof crypto !== "undefined" && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  // Fallback for older browsers
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

// ─── DB Health Check ──────────────────────────────────────────────────────

export type DbHealthStatus = "online" | "offline" | "checking";

/**
 * Pings the Supabase REST endpoint to verify DB connectivity.
 * Times out after 5 seconds to avoid blocking the UI.
 * Returns true if reachable, false otherwise.
 */
export async function checkDbHealth(): Promise<boolean> {
  // Local-first: prefer the captive-portal-local API base if reachable.
  // Falls back to the WAN Supabase URL when no local proxy responds.
  const base = await resolveApiBase().catch(() => getApiBaseSync());
  const healthUrl = base.endsWith("/api")
    ? `${base}/health`
    : `${base}/rest/v1/`;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    const resp = await fetch(healthUrl, {
      signal: controller.signal,
      headers: { apikey: SUPABASE_ANON_KEY },
    });
    clearTimeout(timer);
    return resp.ok || resp.status === 200;
  } catch {
    return false;
  }
}
