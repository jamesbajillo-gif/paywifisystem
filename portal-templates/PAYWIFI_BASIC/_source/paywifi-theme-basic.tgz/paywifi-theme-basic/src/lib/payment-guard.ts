/**
 * Payment-attempt guard — client-side abuse protection for the mock.
 *
 * ─── Attempt counting rules ───────────────────────────────────────────────
 *
 *   • Digital (GCash / QR PH / Maya) failures → separate "digital" counter.
 *     3 digital failures within the window → digital payments locked out.
 *     Cash is NOT affected by digital failures.
 *
 *   • Cash failures → separate "cash" counter.
 *     3 cash failures within the window → cash payments locked out only.
 *     Digital is NOT affected by cash failures.
 *
 * Both counters are scoped to venue so multi-venue deployments don't bleed.
 * planId scoping is kept for backward compatibility with admin audit helpers.
 *
 * ─── What this stops, and what it doesn't ────────────────────────────────
 * Stops:    casual abuse — same-browser refresh, multiple tabs, page reloads.
 * Doesn't:  incognito mode, device switching, direct API replay. Those need
 *           server-side identity (milestone #1's job).
 */

export const ATTEMPT_WINDOW_MS = 10 * 60 * 1000;  // 10 minutes
export const MAX_ATTEMPTS = 3;
export const LOCKOUT_DURATION_MS = 5 * 60 * 1000; // 5 minutes

// Two separate storage prefixes — one per method group.
const DIGITAL_PREFIX = "paywifi:attempts-digital:";
const CASH_PREFIX    = "paywifi:attempts-cash:";

export type AttemptState = {
  failedTimestamps: number[];
  lockedUntil?: number;
};

// ─── Internal helpers ─────────────────────────────────────────────────────

function storageKey(prefix: string, venue: string, planId: string): string {
  return `${prefix}${venue}:${planId}`;
}

function loadState(prefix: string, venue: string, planId: string): AttemptState {
  if (typeof window === "undefined") return { failedTimestamps: [] };
  try {
    const raw = window.localStorage.getItem(storageKey(prefix, venue, planId));
    if (!raw) return { failedTimestamps: [] };
    return JSON.parse(raw) as AttemptState;
  } catch {
    return { failedTimestamps: [] };
  }
}

function saveState(prefix: string, venue: string, planId: string, state: AttemptState): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(storageKey(prefix, venue, planId), JSON.stringify(state));
  } catch { /* full / disabled */ }
}

function recordFailed(prefix: string, venue: string, planId: string): AttemptState {
  const now = Date.now();
  const state = loadState(prefix, venue, planId);
  const recent = state.failedTimestamps.filter((t) => now - t < ATTEMPT_WINDOW_MS);
  recent.push(now);
  const next: AttemptState = {
    failedTimestamps: recent,
    lockedUntil: state.lockedUntil,
  };
  if (recent.length >= MAX_ATTEMPTS) {
    next.lockedUntil = now + LOCKOUT_DURATION_MS;
  }
  saveState(prefix, venue, planId, next);
  return next;
}

function lockoutRemaining(prefix: string, venue: string, planId: string): number {
  if (typeof window === "undefined") return 0;
  const state = loadState(prefix, venue, planId);
  if (!state.lockedUntil) return 0;
  return Math.max(0, state.lockedUntil - Date.now());
}

// ─── Public API ───────────────────────────────────────────────────────────

/**
 * Record a failed DIGITAL payment attempt.
 * 3 failures → digital lockout (cash unaffected).
 */
export function recordFailedAttempt(venue: string, planId: string): AttemptState {
  return recordFailed(DIGITAL_PREFIX, venue, planId);
}

/**
 * Record a failed CASH payment attempt.
 * 3 failures → cash lockout only. Digital is NOT affected.
 */
export function recordFailedCashAttempt(venue: string, planId: string): AttemptState {
  return recordFailed(CASH_PREFIX, venue, planId);
}

/**
 * Returns ms remaining on the DIGITAL lockout (triggered by digital failures only).
 * 0 if not locked.
 */
export function getLockoutRemainingMs(venue: string, planId: string): number {
  return lockoutRemaining(DIGITAL_PREFIX, venue, planId);
}

/**
 * Returns ms remaining on the CASH lockout (triggered by cash failures only).
 * 0 if not locked.
 */
export function getCashLockoutRemainingMs(venue: string, planId: string): number {
  return lockoutRemaining(CASH_PREFIX, venue, planId);
}

/** Convenience: digital payments currently locked out? */
export function isLockedOut(venue: string, planId: string): boolean {
  return getLockoutRemainingMs(venue, planId) > 0;
}

/** Convenience: cash payments currently locked out? */
export function isCashLockedOut(venue: string, planId: string): boolean {
  return getCashLockoutRemainingMs(venue, planId) > 0;
}

/** Clears BOTH counters on successful payment. */
export function clearAttempts(venue: string, planId: string): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.removeItem(storageKey(DIGITAL_PREFIX, venue, planId));
    window.localStorage.removeItem(storageKey(CASH_PREFIX, venue, planId));
  } catch { /* nothing to clear */ }
}

/** Wipes every attempt record (admin reset). */
export function clearAllAttempts(): void {
  if (typeof window === "undefined") return;
  try {
    const keys: string[] = [];
    for (let i = 0; i < window.localStorage.length; i++) {
      const key = window.localStorage.key(i);
      if (key?.startsWith(DIGITAL_PREFIX) || key?.startsWith(CASH_PREFIX)) {
        keys.push(key);
      }
    }
    keys.forEach((k) => window.localStorage.removeItem(k));
  } catch { /* nothing to wipe */ }
}

/**
 * Total failed attempts across all combos since `sinceMs`.
 * Counts both digital and cash buckets.
 */
export function getRecentFailedAttempts(sinceMs = 0): number {
  if (typeof window === "undefined") return 0;
  let total = 0;
  try {
    for (let i = 0; i < window.localStorage.length; i++) {
      const key = window.localStorage.key(i);
      if (!key?.startsWith(DIGITAL_PREFIX) && !key?.startsWith(CASH_PREFIX)) continue;
      const raw = window.localStorage.getItem(key);
      if (!raw) continue;
      const state = JSON.parse(raw) as AttemptState;
      total += state.failedTimestamps.filter((t) => t >= sinceMs).length;
    }
  } catch { /* return partial */ }
  return total;
}

/** Failed attempts for a specific planId across all venues since `sinceMs`. */
export function getAttemptCountSince(planId: string, sinceMs: number): number {
  if (typeof window === "undefined") return 0;
  const suffix = `:${planId}`;
  let total = 0;
  try {
    for (let i = 0; i < window.localStorage.length; i++) {
      const key = window.localStorage.key(i);
      if (!key?.startsWith(DIGITAL_PREFIX) && !key?.startsWith(CASH_PREFIX)) continue;
      if (!key.endsWith(suffix)) continue;
      const raw = window.localStorage.getItem(key);
      if (!raw) continue;
      const state = JSON.parse(raw) as AttemptState;
      total += state.failedTimestamps.filter((t) => t >= sinceMs).length;
    }
  } catch { /* return partial */ }
  return total;
}

/**
 * List combos currently locked out.
 * Checks both digital and cash lockout buckets — a combo may appear
 * once for each bucket if both are locked simultaneously.
 */
export function getLockedOutCombos(): Array<{ venue: string; planId: string; remainingMs: number }> {
  if (typeof window === "undefined") return [];
  const out: Array<{ venue: string; planId: string; remainingMs: number }> = [];
  try {
    for (const prefix of [DIGITAL_PREFIX, CASH_PREFIX]) {
      for (let i = 0; i < window.localStorage.length; i++) {
        const key = window.localStorage.key(i);
        if (!key?.startsWith(prefix)) continue;
        const raw = window.localStorage.getItem(key);
        if (!raw) continue;
        const state = JSON.parse(raw) as AttemptState;
        if (!state.lockedUntil) continue;
        const remaining = state.lockedUntil - Date.now();
        if (remaining <= 0) continue;
        const tail = key.slice(prefix.length);
        const colon = tail.indexOf(":");
        if (colon < 0) continue;
        out.push({ venue: tail.slice(0, colon), planId: tail.slice(colon + 1), remainingMs: remaining });
      }
    }
  } catch { /* return whatever collected */ }
  return out;
}
