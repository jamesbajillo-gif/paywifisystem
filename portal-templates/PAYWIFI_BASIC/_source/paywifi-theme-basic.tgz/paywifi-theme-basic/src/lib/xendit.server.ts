/**
 * xendit.server.ts — server-only Xendit helpers.
 *
 * The `.server.ts` suffix tells Vite to exclude this file from the client
 * bundle, so the secret key never reaches the browser.
 *
 * Xendit API docs: https://docs.xendit.co/apidocs
 * Test dashboard:  https://dashboard.xendit.co/
 *
 * ─── Environment variables (set in .env.local) ────────────────────────────
 *   XENDIT_SECRET_KEY    xnd_development_…   (or xnd_production_… for live)
 *   XENDIT_WEBHOOK_TOKEN 4vCxrQwUdfu…
 * ──────────────────────────────────────────────────────────────────────────
 */
import process from "node:process";
// ─── Types ────────────────────────────────────────────────────────────────
/** Every Xendit e-wallet / QR / bank channel we expose. */
export type XenditChannel =
  | "GCASH"
  | "PAYMAYA"
  | "SHOPEEPAY"
  | "OVO"
  | "DANA"
  | "LINKAJA"
  | "QRIS"
  | "QRPH"
  | "BPI"
  | "BDO"
  | "RCBC"
  | "UNIONBANK";
/** Human-readable metadata for each channel, used in admin UI. */
export type XenditChannelMeta = {
  id: XenditChannel;
  label: string;
  /** Which Xendit payment method type to use in the API request. */
  type: "EWALLET" | "QR_CODE" | "ONLINE_BANKING";
  /** Country availability note for display. */
  countries: string;
};
/** Full Xendit module config stored per venue. */
export type XenditConfig = {
  /** Master on/off for Xendit integration. When false, cash-only. */
  enabled: boolean;
  /** The single active payment channel. null = enabled but none selected yet. */
  activeChannel: XenditChannel | null;
  /** Stored API key (masked in UI, full value in memory only). */
  apiKey: string;
  /** Webhook token for signature verification. */
  webhookToken: string;
};
/** Shape of a Xendit Payment Request response (v2). */
export type XenditPaymentRequestResponse = {
  id: string;
  status: "PENDING" | "REQUIRES_ACTION" | "SUCCEEDED" | "FAILED" | "VOIDED";
  amount: number;
  currency: string;
  actions?: Array<{ action: string; url: string; url_type?: string }>;
  metadata?: Record<string, unknown>;
};
/** Normalised result from createPaymentRequest. */
export type XenditInitResult =
  | { ok: true; paymentRequestId: string; redirectUrl: string }
  | { ok: false; error: string };
/** Shape of an inbound Xendit webhook payload. */
export type XenditWebhookPayload = {
  event: string;
  data: {
    id: string;
    status: string;
    reference_id?: string;
    metadata?: Record<string, unknown>;
  };
};
// ─── Channel catalog ──────────────────────────────────────────────────────
export const XENDIT_CHANNELS: XenditChannelMeta[] = [
  { id: "GCASH",      label: "GCash",       type: "EWALLET",        countries: "PH" },
  { id: "PAYMAYA",    label: "Maya",         type: "EWALLET",        countries: "PH" },
  { id: "SHOPEEPAY",  label: "ShopeePay",    type: "EWALLET",        countries: "PH, ID" },
  { id: "OVO",        label: "OVO",          type: "EWALLET",        countries: "ID" },
  { id: "DANA",       label: "DANA",         type: "EWALLET",        countries: "ID" },
  { id: "LINKAJA",    label: "LinkAja",      type: "EWALLET",        countries: "ID" },
  { id: "QRPH",       label: "QR PH",        type: "QR_CODE",        countries: "PH" },
  { id: "QRIS",       label: "QRIS",         type: "QR_CODE",        countries: "ID" },
  { id: "BPI",        label: "BPI Online",   type: "ONLINE_BANKING", countries: "PH" },
  { id: "BDO",        label: "BDO Online",   type: "ONLINE_BANKING", countries: "PH" },
  { id: "RCBC",       label: "RCBC",         type: "ONLINE_BANKING", countries: "PH" },
  { id: "UNIONBANK",  label: "UnionBank",    type: "ONLINE_BANKING", countries: "PH" },
];
// ─── Config helpers ───────────────────────────────────────────────────────
const XENDIT_CONFIG_KEY = "paywifi:xendit-config";
/** Default config: Xendit enabled, GCash (EWALLET module) active, keys from env. */
export function defaultXenditConfig(): XenditConfig {
  return {
    enabled: true,
    activeChannel: "GCASH",
    apiKey: process.env.XENDIT_SECRET_KEY ?? "",
    webhookToken: process.env.XENDIT_WEBHOOK_TOKEN ?? "",
  };
}
/**
 * Load Xendit config from localStorage (client) or fall back to env-based
 * defaults.  On the server, always returns the env-seeded default — the
 * localStorage store is client-side only and server functions read from env.
 */
export function getXenditConfig(): XenditConfig {
  if (typeof window === "undefined") return defaultXenditConfig();
  try {
    const raw = window.localStorage.getItem(XENDIT_CONFIG_KEY);
    if (!raw) return defaultXenditConfig();
    const parsed = JSON.parse(raw) as Record<string, unknown>;
    // Migration: old shape had channels: Record<XenditChannel, boolean>
    let activeChannel: XenditChannel | null = null;
    if (parsed.activeChannel && typeof parsed.activeChannel === "string") {
      activeChannel = parsed.activeChannel as XenditChannel;
    } else if (parsed.channels && typeof parsed.channels === "object") {
      const ch = parsed.channels as Record<string, boolean>;
      const first = XENDIT_CHANNELS.find((c) => ch[c.id] === true);
      activeChannel = first?.id ?? null;
    }
    return {
      enabled: typeof parsed.enabled === "boolean" ? parsed.enabled : false,
      activeChannel,
      apiKey: (typeof parsed.apiKey === "string" && parsed.apiKey)
        ? parsed.apiKey
        : (process.env.XENDIT_SECRET_KEY ?? ""),
      webhookToken: (typeof parsed.webhookToken === "string" && parsed.webhookToken)
        ? parsed.webhookToken
        : (process.env.XENDIT_WEBHOOK_TOKEN ?? ""),
    };
  } catch {
    return defaultXenditConfig();
  }
}
/** Persist updated Xendit config to localStorage. */
export function saveXenditConfig(config: XenditConfig): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(XENDIT_CONFIG_KEY, JSON.stringify(config));
  } catch {
    /* storage unavailable — silently ignore */
  }
}
/** Returns the active XenditChannel, or null if disabled / none selected. */
export function getActiveXenditChannel(config: XenditConfig): XenditChannel | null {
  if (!config.enabled) return null;
  return config.activeChannel;
}
// ─── Xendit API ───────────────────────────────────────────────────────────
const XENDIT_BASE = "https://api.xendit.co";
function xenditAuthHeader(apiKey: string): string {
  // Basic auth: base64(apiKey + ":")
  const token = Buffer.from(`${apiKey}:`).toString("base64");
  return `Basic ${token}`;
}
/**
 * Creates a Xendit Payment Request for the given channel.
 *
 * Returns a redirect URL the customer should open to complete payment.
 * For QR channels, the URL contains an embeddable QR image.
 *
 * @param opts.amount     Amount in PHP (or relevant currency), as integer cents.
 * @param opts.channel    Xendit channel id (e.g. "GCASH").
 * @param opts.referenceId Idempotency key — use the local transaction ID.
 * @param opts.successReturnUrl Where Xendit redirects after successful payment.
 * @param opts.failureReturnUrl Where Xendit redirects after failed/cancelled.
 * @param opts.apiKey     Xendit secret key (from config).
 * @param opts.metadata   Arbitrary metadata stored on the Xendit object.
 */
export async function createPaymentRequest(opts: {
  amount: number;
  channel: XenditChannel;
  referenceId: string;
  successReturnUrl: string;
  failureReturnUrl: string;
  apiKey: string;
  metadata?: Record<string, string>;
  phoneNumber?: string;
}): Promise<XenditInitResult> {
  const channelMeta = XENDIT_CHANNELS.find((c) => c.id === opts.channel);
  if (!channelMeta) {
    return { ok: false, error: `Unknown channel: ${opts.channel}` };
  }
  const body: Record<string, unknown> = {
    reference_id: opts.referenceId,
    amount: opts.amount,
    currency: "PHP",
    payment_method: {
      type: channelMeta.type,
      reusability: "ONE_TIME_USE",
      ewallet: channelMeta.type === "EWALLET"
        ? {
            channel_code: opts.channel,
            channel_properties: {
              success_return_url: opts.successReturnUrl,
              failure_return_url: opts.failureReturnUrl,
              cancel_return_url: opts.failureReturnUrl,
              ...(opts.phoneNumber ? { mobile_number: opts.phoneNumber } : {}),
            },
          }
        : undefined,
      qr_code: channelMeta.type === "QR_CODE"
        ? { channel_code: opts.channel }
        : undefined,
      online_banking: channelMeta.type === "ONLINE_BANKING"
        ? {
            channel_code: opts.channel,
            channel_properties: {
              success_return_url: opts.successReturnUrl,
              failure_return_url: opts.failureReturnUrl,
            },
          }
        : undefined,
    },
    metadata: opts.metadata ?? {},
  };
  // Remove undefined keys (Xendit rejects null payment_method sub-objects)
  const pm = body.payment_method as Record<string, unknown>;
  for (const key of ["ewallet", "qr_code", "online_banking"]) {
    if (pm[key] === undefined) delete pm[key];
  }
  try {
    const resp = await fetch(`${XENDIT_BASE}/v2/payment_requests`, {
      method: "POST",
      headers: {
        Authorization: xenditAuthHeader(opts.apiKey),
        "Content-Type": "application/json",
        "api-version": "2022-07-31",
      },
      body: JSON.stringify(body),
    });
    const json = (await resp.json()) as XenditPaymentRequestResponse & { message?: string; error_code?: string };
    if (!resp.ok) {
      return { ok: false, error: json.message ?? `HTTP ${resp.status}` };
    }
    // For eWallets & online banking, Xendit returns an `actions` array with
    // a DESKTOP_WEB or MOBILE_DEEPLINK URL.  For QR codes, it's the QR image.
    const action = json.actions?.find(
      (a) => a.action === "AUTH" || a.action === "DESKTOP_WEB" || a.action === "QR_CODE_URL"
    ) ?? json.actions?.[0];
    if (!action?.url) {
      return { ok: false, error: "Xendit returned no redirect URL" };
    }
    return { ok: true, paymentRequestId: json.id, redirectUrl: action.url };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : "Network error" };
  }
}
/**
 * Verifies an inbound Xendit webhook and returns the parsed payload.
 *
 * Xendit includes the token in the `x-callback-token` header.
 * Compare it directly (constant-time in prod; string compare is fine for demo).
 */
export function verifyAndParseWebhook(
  body: string,
  callbackToken: string,
  expectedToken: string
): { ok: true; payload: XenditWebhookPayload } | { ok: false; error: string } {
  if (callbackToken !== expectedToken) {
    return { ok: false, error: "Invalid webhook token" };
  }
  try {
    const payload = JSON.parse(body) as XenditWebhookPayload;
    return { ok: true, payload };
  } catch {
    return { ok: false, error: "Invalid JSON" };
  }
}
/**
 * Pings the Xendit API to verify the key is valid.
 * Returns true if the key works, false otherwise.
 */
export async function pingXenditKey(apiKey: string): Promise<boolean> {
  try {
    const resp = await fetch(`${XENDIT_BASE}/balance`, {
      headers: { Authorization: xenditAuthHeader(apiKey) },
    });
    return resp.status !== 401 && resp.status !== 403;
  } catch {
    return false;
  }
}
/**
 * Fetches the current status of a Xendit Payment Request by ID.
 *
 * Returns the payment status and, for eWallet channels, the actions array
 * so the client can surface the deep-link / QR URL.
 */
export async function getPaymentRequestStatus(opts: {
  paymentRequestId: string;
  apiKey: string;
}): Promise<{
  ok: true;
  status: XenditPaymentRequestResponse["status"];
  actions?: Array<{ action: string; url: string; url_type?: string }>;
} | { ok: false; error: string }> {
  try {
    const resp = await fetch(
      `${XENDIT_BASE}/v2/payment_requests/${encodeURIComponent(opts.paymentRequestId)}`,
      {
        headers: {
          Authorization: xenditAuthHeader(opts.apiKey),
          "api-version": "2022-07-31",
        },
      },
    );
    const json = (await resp.json()) as XenditPaymentRequestResponse & {
      message?: string;
    };
    if (!resp.ok) {
      return { ok: false, error: json.message ?? `HTTP ${resp.status}` };
    }
    return {
      ok: true,
      status: json.status,
      actions: json.actions,
    };
  } catch (err) {
    return {
      ok: false,
      error: err instanceof Error ? err.message : "Network error",
    };
  }
}
