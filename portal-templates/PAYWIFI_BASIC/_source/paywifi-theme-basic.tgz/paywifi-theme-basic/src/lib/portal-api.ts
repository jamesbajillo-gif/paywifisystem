/**
 * Portal API — single source of truth for all backend interactions.
 *
 * Supabase is now the primary store. localStorage (mock-store) is kept
 * as a local read cache / fallback for SSR and offline scenarios.
 *
 * Write operations (addVoucher, markRedeemed, confirmAndIssue, void) call
 * Supabase server functions. Read operations fall back to the local cache
 * for instant UI response, then refresh from Supabase in background.
 *
 * ─── DB offline guard ────────────────────────────────────────────────────
 * All functions that create or modify data return { ok: false, message }
 * with message containing "DB_OFFLINE" when Supabase is unreachable.
 * The UI checks for this sentinel and shows the offline banner.
 */

import * as store from "@/lib/mock-store";
import * as analytics from "@/lib/analytics";
import * as guard from "@/lib/payment-guard";
import { getSystemId } from "@/lib/supabase";
import {
  addVoucherFn,
  markRedeemedFn,
  confirmAndIssueVoucherFn,
  voidVoucherFn,
  checkDbHealthFn,
  findVoucherFn,
  updateVoucherPhoneFn,
  getPhoneEditLogFn,
  getAllVouchersFn,
  getActiveSessionsFn,
  findPendingForVenueFn,
  getCreditsFn,
  deductCreditsFn,
  getRefundsFn,
  createRefundFn,
  resolveRefundFn,
  recordPendingDigitalFn,
  clearPendingDigitalFn,
  findPendingDigitalFn,
  upsertPlanFn,
  deletePlanFn,
  getPlansFn,
} from "@/lib/api/db.functions";

/** How long a pending cash reference stays valid before it expires. */
export const PENDING_CASH_TTL_MS = 15 * 60 * 1000; // 15 minutes

export type PlanId = "hour" | "day" | "week";

export type Plan = {
  id: PlanId;
  name: string;
  description?: string;
  duration: string;
  durationMinutes: number;
  speed?: string;
  price: number;
  epaymentFee?: number;
  popular?: boolean;
};

export type PaymentMethod = "gcash" | "qrph" | "maya" | "cash";

export type VoucherStatus = "valid" | "invalid" | "expired" | "used";

export type ValidateVoucherResult =
  | { ok: true; code: string; remainingMinutes: number; planId?: PlanId }
  | { ok: false; status: Exclude<VoucherStatus, "valid">; message: string };

export type PaymentResult =
  | { ok: true; code: string; transactionId: string }
  | { ok: true; paymentReference: string; transactionId: string }
  | { ok: false; message: string };

// ─── Static plan catalog ──────────────────────────────────────────────────
export const PLANS: Plan[] = [
  { id: "hour", name: "1 Hour", description: "Perfect for a quick session.", duration: "60 minutes", durationMinutes: 60, speed: "10 Mbps", price: 1.99 },
  { id: "day", name: "Day Pass", description: "Full-day access, great for working or browsing.", duration: "24 hours", durationMinutes: 60 * 24, speed: "25 Mbps", price: 4.99, popular: true },
  { id: "week", name: "Week Pass", description: "Best value for extended stays.", duration: "7 days", durationMinutes: 60 * 24 * 7, speed: "50 Mbps", price: 14.99 },
];

/**
 * Returns the active plan catalog.
 *
 * Reads from Supabase (`paywifi_basic_plans`) so admin edits propagate.
 * Falls back to the hardcoded PLANS array if the DB is unreachable or
 * has no rows yet (acts as the seed catalog).
 */
export async function getPlans(): Promise<Plan[]> {
  try {
    const res = await getPlansFn({ data: { system_id: getSystemId() } });
    if (res.ok && Array.isArray(res.plans) && res.plans.length > 0) {
      const rows = res.plans as Array<Record<string, unknown>>;
      const mapped: Plan[] = rows.map((p) => ({
        id: p.plan_id as PlanId,
        name: p.name as string,
        description: (p.description as string) ?? undefined,
        duration: p.duration as string,
        durationMinutes: p.duration_minutes as number,
        speed: (p.speed as string) ?? undefined,
        price: p.price as number,
        epaymentFee: (p.epayment_fee as number) ?? undefined,
        popular: (p.popular as boolean) ?? false,
      }));
      return mapped;
    }
  } catch { /* DB offline — fall through to static catalog */ }
  return PLANS;
}

export function getPlan(id: PlanId): Plan | undefined {
  return PLANS.find((p) => p.id === id);
}

// ─── Voucher format ───────────────────────────────────────────────────────
const VOUCHER_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
export const VOUCHER_FORMAT_REGEX = /^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/;

export function generateVoucherCode(): string {
  let payload = "";
  for (let i = 0; i < 12; i++) {
    payload += VOUCHER_ALPHABET[Math.floor(Math.random() * VOUCHER_ALPHABET.length)];
  }
  return `${payload.slice(0, 4)}-${payload.slice(4, 8)}-${payload.slice(8, 12)}`;
}

export function generatePaymentReference(): string {
  return generateVoucherCode();
}

export function formatVoucherCode(raw: string): string {
  const clean = raw
    .toUpperCase()
    .replace(/[^A-Z2-9]/g, "")
    .slice(0, 12);
  const parts: string[] = [];
  for (let i = 0; i < clean.length; i += 4) {
    parts.push(clean.slice(i, i + 4));
  }
  return parts.join("-");
}

// (Demo first-attempt-fail simulation removed. If you need to test the
//  failure UX, manually mutate the response in DevTools or use an MSW
//  mock — do not re-introduce simulation flags here.)

export function resetFirstAttemptFlags(): void {
  // No-op kept for API stability — older test code may still call this.
}

// ─── DB health check ──────────────────────────────────────────────────────
export async function checkDbHealth(): Promise<boolean> {
  try {
    const res = await checkDbHealthFn();
    return res.ok;
  } catch {
    return false;
  }
}

// ─── Voucher validation ───────────────────────────────────────────────────
// PROD: 0. Bump (e.g. 1200) only for demo/UX testing of loading states.
const SIMULATED_LATENCY_MS = 0;

export async function validateVoucher(code: string): Promise<ValidateVoucherResult> {
  await delay(SIMULATED_LATENCY_MS);

  const trimmed = code.trim().toUpperCase();
  if (!trimmed) {
    return { ok: false, status: "invalid", message: "Empty code" };
  }

  // Primary: check local cache (includes records written this session)
  const stored = store.findVoucher(trimmed);
  if (stored) {
    if (stored.voidedAt) {
      return { ok: false, status: "invalid", message: "This reference was cancelled." };
    }
    if (stored.expiresAt && !stored.redeemedAt && Date.now() >= stored.expiresAt) {
      return { ok: false, status: "expired", message: "This payment reference has expired." };
    }
    if (stored.transactionId?.startsWith("CASH-") && !stored.confirmedAt && !stored.redeemedAt) {
      return { ok: false, status: "invalid", message: "Voucher pending verification." };
    }
    if (stored.redeemedAt) {
      const expiresAt = stored.redeemedAt + stored.durationMinutes * 60 * 1000;
      if (Date.now() >= expiresAt) {
        return { ok: false, status: "expired", message: "This voucher's time has run out." };
      }
      const when = new Date(stored.redeemedAt).toLocaleString();
      return { ok: false, status: "used", message: `Already used on ${when}.` };
    }
    return { ok: true, code: stored.code, remainingMinutes: stored.durationMinutes, planId: stored.planId };
  }

  // Secondary: query Supabase for cross-device validation (voucher issued on another device)
  try {
    const dbResult = await findVoucherFn({ data: { code: trimmed } });
    if (dbResult.ok && dbResult.voucher) {
      const v = dbResult.voucher;
      // Populate local cache so subsequent lookups are instant
      store.addVoucher({
        code: v.code,
        paymentReference: v.payment_reference ?? undefined,
        planId: v.plan_id as PlanId,
        issuedAt: v.issued_at,
        durationMinutes: v.duration_minutes,
        transactionId: v.transaction_id ?? undefined,
        phone: v.phone ?? undefined,
        venue: v.venue ?? undefined,
        storeId: v.store_id ?? undefined,
        expiresAt: v.expires_at ?? undefined,
        voidedAt: v.voided_at ?? undefined,
        confirmedAt: v.confirmed_at ?? undefined,
        redeemedAt: v.redeemed_at ?? undefined,
      });
      if (v.voided_at) {
        return { ok: false, status: "invalid", message: "This voucher was cancelled." };
      }
      if (v.expires_at && !v.redeemed_at && Date.now() >= v.expires_at) {
        return { ok: false, status: "expired", message: "This payment reference has expired." };
      }
      if (v.transaction_id?.startsWith("CASH-") && !v.confirmed_at && !v.redeemed_at) {
        return { ok: false, status: "invalid", message: "Voucher pending verification." };
      }
      if (v.redeemed_at) {
        const expiresAt = v.redeemed_at + v.duration_minutes * 60 * 1000;
        if (Date.now() >= expiresAt) {
          return { ok: false, status: "expired", message: "This voucher's time has run out." };
        }
        const when = new Date(v.redeemed_at).toLocaleString();
        return { ok: false, status: "used", message: `Already used on ${when}.` };
      }
      return { ok: true, code: v.code, remainingMinutes: v.duration_minutes, planId: v.plan_id as PlanId };
    }
  } catch {
    // DB unavailable — fall through to dev shortcuts
  }

  return { ok: false, status: "invalid", message: "Voucher not found." };
}

// ─── Payment processing ───────────────────────────────────────────────────

export async function processPayment(input: {
  planId: PlanId;
  method: PaymentMethod;
  phone?: string;
  venue?: string;
  storeId?: string;
}): Promise<PaymentResult> {
  await delay(SIMULATED_LATENCY_MS);

  const isCash = input.method === "cash";

  // Note: real digital payments flow through initiateXenditPayment server
  // fn, NOT this path. processPayment is reached only for the cash flow
  // below. The non-cash branch is kept as a no-op for type-symmetry with
  // legacy callers; if you find code routing digital methods through here,
  // route them through initiateXenditPayment instead.

  const plan = getPlan(input.planId);
  if (!plan) return { ok: false, message: "Plan not found." };

  const transactionId = isCash
    ? "CASH-" + Date.now().toString(36).toUpperCase()
    : "TXN-" + Date.now().toString(36).toUpperCase();

  const systemId = getSystemId();

  if (isCash) {
    const paymentReference = generatePaymentReference();
    const voucherData = {
      code: "",
      paymentReference,
      planId: input.planId,
      issuedAt: Date.now(),
      durationMinutes: plan.durationMinutes,
      transactionId,
      phone: input.phone,
      venue: input.venue ?? "default",
      storeId: input.storeId,
      expiresAt: Date.now() + PENDING_CASH_TTL_MS,
    };
    // Write to local cache immediately for instant UI
    store.addVoucher(voucherData);
    // Async write to Supabase (fire-and-forget with error logging)
    addVoucherFn({
      data: {
        system_id: systemId,
        code: "",
        payment_reference: paymentReference,
        plan_id: input.planId,
        issued_at: voucherData.issuedAt,
        duration_minutes: plan.durationMinutes,
        transaction_id: transactionId,
        phone: input.phone,
        venue: input.venue ?? "default",
        store_id: input.storeId,
        expires_at: voucherData.expiresAt,
      }
    }).catch((e) => console.warn("[supabase] addVoucher failed:", e));
    return { ok: true, paymentReference, transactionId };
  }

  const code = generateVoucherCode();
  const voucherData = {
    code,
    planId: input.planId,
    issuedAt: Date.now(),
    durationMinutes: plan.durationMinutes,
    transactionId,
    phone: input.phone,
    venue: input.venue ?? "default",
  };
  store.addVoucher(voucherData);
  addVoucherFn({
    data: {
      system_id: systemId,
      code,
      plan_id: input.planId,
      issued_at: voucherData.issuedAt,
      duration_minutes: plan.durationMinutes,
      transaction_id: transactionId,
      phone: input.phone,
      venue: input.venue ?? "default",
    }
  }).catch((e) => console.warn("[supabase] addVoucher failed:", e));

  if (input.phone) {
    void sendSmsReceipt({ phone: input.phone, code, planId: input.planId });
  }

  return { ok: true, code, transactionId };
}

export type ConfirmAndIssueResult =
  | { ok: true; code: string }
  | { ok: false; reason: "not_found" | "already_confirmed" | "expired" | "voided" | "insufficient_credits"; balance?: number; required?: number };

export async function confirmAndIssueVoucherForReference(paymentReference: string): Promise<ConfirmAndIssueResult> {
  const voucherCode = generateVoucherCode();
  const ok = store.confirmAndIssueVoucher(paymentReference, voucherCode);
  if (!ok) {
    const v = store.findByPaymentReference(paymentReference);
    if (!v) return { ok: false, reason: "not_found" };
    if (v.confirmedAt) return { ok: false, reason: "already_confirmed" };
    if (v.voidedAt) return { ok: false, reason: "voided" };
    if (v.expiresAt && v.expiresAt <= Date.now()) return { ok: false, reason: "expired" };
    return { ok: false, reason: "not_found" };
  }
  // Persist to Supabase (await for consistency — cashier flow is not latency-sensitive)
  await confirmAndIssueVoucherFn({
    data: { payment_reference: paymentReference, voucher_code: voucherCode }
  }).catch((e) => console.warn("[supabase] confirmAndIssue failed:", e));
  return { ok: true, code: voucherCode };
}

// ─── SMS receipt ──────────────────────────────────────────────────────────
// NOT IMPLEMENTED — no real SMS provider is wired up yet.
// When ready, replace the console.info with a real provider call
// (Semaphore PH recommended for local Philippine numbers).
// Until then, this is a no-op that always reports success so callers
// (e.g. processPayment) don't error.
export async function sendSmsReceipt(input: {
  phone: string;
  code: string;
  planId: PlanId;
}): Promise<{ ok: boolean }> {
  console.info("[SMS NOT IMPLEMENTED]", input);
  await delay(300);
  return { ok: true };
}

// ─── Admin: manually issue a voucher ──────────────────────────────────────
export type IssueVoucherResult =
  | { ok: true; code: string }
  | { ok: false; reason: "insufficient_credits"; balance: number; required: number };

export async function issueVoucher(planId: PlanId): Promise<IssueVoucherResult> {
  const plan = getPlan(planId);
  if (!plan) throw new Error(`Unknown plan: ${planId}`);
  // Check credits from Supabase (authoritative), fall back to local
  const creditRec = await getCreditRecord();
  const cost = Math.ceil(plan.price);
  if (creditRec.balance < cost) {
    return { ok: false, reason: "insufficient_credits", balance: creditRec.balance, required: cost };
  }
  // Deduct via Supabase server fn; also updates local cache
  store.deductCredits(plan.price);
  deductCreditsFn({ data: { system_id: getSystemId(), amount: plan.price } })
    .catch((e) => console.warn("[supabase] deductCredits failed:", e));
  await delay(300);
  const code = generateVoucherCode();
  const systemId = getSystemId();
  const voucherData = {
    code,
    planId,
    issuedAt: Date.now(),
    durationMinutes: plan.durationMinutes,
    transactionId: `ADMIN-${Date.now().toString(36).toUpperCase()}`,
  };
  store.addVoucher(voucherData);
  addVoucherFn({
    data: {
      system_id: systemId,
      code,
      plan_id: planId,
      issued_at: voucherData.issuedAt,
      duration_minutes: plan.durationMinutes,
      transaction_id: voucherData.transactionId,
    }
  }).catch((e) => console.warn("[supabase] issueVoucher failed:", e));
  return { ok: true as const, code };
}

// ─── Voucher redemption ───────────────────────────────────────────────────
export async function redeemVoucher(code: string): Promise<{ ok: boolean }> {
  const marked = store.markRedeemed(code);
  if (marked) console.info("[redeem]", code, "(new redemption)");
  // Async write to Supabase
  markRedeemedFn({ data: { code } })
    .catch((e) => console.warn("[supabase] markRedeemed failed:", e));
  await delay(200);
  return { ok: true };
}

// ─── Admin-facing read helpers ────────────────────────────────────────────

/**
 * Returns all vouchers. Queries Supabase first (cross-device), falls back
 * to localStorage cache if DB is offline.
 */
export async function getAllVouchers(): Promise<import("@/lib/mock-store").StoredVoucher[]> {
  try {
    const res = await getAllVouchersFn();
    if (res.ok && res.vouchers.length > 0) {
      // Populate local cache from DB rows
      const dbVouchers = res.vouchers.map((v: Record<string, unknown>) => ({
        code: v.code as string,
        paymentReference: (v.payment_reference as string) ?? undefined,
        planId: v.plan_id as PlanId,
        issuedAt: v.issued_at as number,
        durationMinutes: v.duration_minutes as number,
        transactionId: (v.transaction_id as string) ?? undefined,
        phone: (v.phone as string) ?? undefined,
        venue: (v.venue as string) ?? undefined,
        storeId: (v.store_id as string) ?? undefined,
        expiresAt: (v.expires_at as number) ?? undefined,
        voidedAt: (v.voided_at as number) ?? undefined,
        confirmedAt: (v.confirmed_at as number) ?? undefined,
        redeemedAt: (v.redeemed_at as number) ?? undefined,
      })) as import("@/lib/mock-store").StoredVoucher[];
      return dbVouchers;
    }
  } catch { /* offline */ }
  return store.getAllVouchers();
}

/**
 * Returns currently-active WiFi sessions. Queries Supabase, falls back
 * to localStorage.
 */
export async function getActiveSessions(): Promise<import("@/lib/mock-store").StoredVoucher[]> {
  try {
    const res = await getActiveSessionsFn({ data: { now: Date.now() } });
    if (res.ok && res.sessions.length > 0) {
      return res.sessions.map((v: Record<string, unknown>) => ({
        code: v.code as string,
        paymentReference: (v.payment_reference as string) ?? undefined,
        planId: v.plan_id as PlanId,
        issuedAt: v.issued_at as number,
        durationMinutes: v.duration_minutes as number,
        transactionId: (v.transaction_id as string) ?? undefined,
        phone: (v.phone as string) ?? undefined,
        venue: (v.venue as string) ?? undefined,
        redeemedAt: (v.redeemed_at as number) ?? undefined,
      })) as import("@/lib/mock-store").StoredVoucher[];
    }
  } catch { /* offline */ }
  return store.getActiveSessions();
}

export const getQueuedTimeForPhone = store.getQueuedTimeForPhone;
export const seedDemoData = store.seedDemoData;
export const clearStore = store.clearStore;
export const findVoucher = store.findVoucher;
export const findByPaymentReference = store.findByPaymentReference;

/**
 * Finds a pending cash payment for the given venue.
 * Checks local cache first for instant cashier UX, then falls back to Supabase
 * to catch references created on other devices.
 */
export async function findPendingForVenue(
  venue: string,
): Promise<import("@/lib/mock-store").StoredVoucher | undefined> {
  // Local first for speed
  const local = store.findPendingForVenue(venue);
  if (local) return local;
  // Supabase fallback — catches references from other devices/sessions
  try {
    const res = await findPendingForVenueFn({ data: { venue } });
    if (res.ok && res.voucher) {
      const v = res.voucher as Record<string, unknown>;
      return {
        code: (v.code as string) ?? "",
        paymentReference: v.payment_reference as string,
        planId: v.plan_id as PlanId,
        issuedAt: v.issued_at as number,
        durationMinutes: v.duration_minutes as number,
        transactionId: (v.transaction_id as string) ?? undefined,
        phone: (v.phone as string) ?? undefined,
        venue: (v.venue as string) ?? undefined,
        expiresAt: (v.expires_at as number) ?? undefined,
      } as import("@/lib/mock-store").StoredVoucher;
    }
  } catch { /* offline */ }
  return undefined;
}

export const getAllEvents = analytics.getAllEvents;
export const getFunnelStats = analytics.getFunnelStats;
export const clearEvents = analytics.clearEvents;
export const recordFailedAttempt = guard.recordFailedAttempt;
export const isLockedOut = guard.isLockedOut;
export const getLockoutRemainingMs = guard.getLockoutRemainingMs;
export const clearAttempts = guard.clearAttempts;
export const clearAllAttempts = guard.clearAllAttempts;
export const getRecentFailedAttempts = guard.getRecentFailedAttempts;
export const getAttemptCountSince = guard.getAttemptCountSince;
export const getLockedOutCombos = guard.getLockedOutCombos;
export const MAX_PAYMENT_ATTEMPTS = guard.MAX_ATTEMPTS;

export function voidVoucher(codeOrReference: string): boolean {
  const ok = store.voidVoucher(codeOrReference);
  if (ok) {
    voidVoucherFn({ data: { code_or_reference: codeOrReference } })
      .catch((e) => console.warn("[supabase] voidVoucher failed:", e));
  }
  return ok;
}

export const purgeExpired = store.purgeExpired;

// ─── Pending digital payments ─────────────────────────────────────────────

/**
 * Persists a pending digital payment to both the local cache and Supabase.
 * Returns a promise that resolves when the DB write completes — caller
 * MUST await this before allowing the user to leave the page, otherwise
 * the webhook may arrive before the pending row exists and the voucher
 * will never be issued.
 */
export async function recordPendingDigitalPayment(
  record: import("@/lib/mock-store").PendingDigitalRecord,
): Promise<{ ok: boolean }> {
  // Local cache first for instant UI
  store.recordPendingDigitalPayment(record);
  try {
    const res = await recordPendingDigitalFn({
      data: {
        system_id: getSystemId(),
        transaction_id: record.transactionId,
        plan_id: record.planId,
        method: record.method,
        venue: record.venue,
        issued_at: record.issuedAt,
        expires_at: record.expiresAt,
        code: record.code,
      },
    });
    return { ok: res.ok };
  } catch (e) {
    console.warn("[supabase] recordPendingDigital failed:", e);
    return { ok: false };
  }
}

export function clearPendingDigitalPayment(transactionId: string): void {
  store.clearPendingDigitalPayment(transactionId);
  clearPendingDigitalFn({ data: { system_id: getSystemId(), transaction_id: transactionId } })
    .catch((e) => console.warn("[supabase] clearPendingDigital failed:", e));
}

export async function findAnyPendingPayment(
  venue: string,
): Promise<import("@/lib/mock-store").AnyPendingPayment | null> {
  const local = store.findAnyPendingPayment(venue);
  if (local) return local;
  try {
    const res = await findPendingDigitalFn({ data: { system_id: getSystemId(), venue } });
    if (res.ok && res.record) {
      const r = res.record as Record<string, unknown>;
      return {
        kind: "digital",
        record: {
          transactionId: r.transaction_id as string,
          planId: r.plan_id as PlanId,
          method: r.method as string,
          venue: r.venue as string,
          issuedAt: r.issued_at as number,
          expiresAt: r.expires_at as number,
          code: r.code as string,
        },
      } as import("@/lib/mock-store").AnyPendingPayment;
    }
  } catch { /* offline */ }
  return null;
}

export const DIGITAL_PENDING_TTL_MS = store.DIGITAL_PENDING_TTL_MS;
export type { AnyPendingPayment, PendingDigitalRecord } from "@/lib/mock-store";

// ---- Phone edit ------------------------------------------------------------
export const PHONE_EDIT_COOLDOWN_MS = store.PHONE_EDIT_COOLDOWN_MS;
export const PHONE_EDIT_MAX_CHANGES = store.PHONE_EDIT_MAX_CHANGES;
export type { PhoneEditLog, PhoneUpdateResult } from "@/lib/mock-store";

export function updateVoucherPhone(
  ref: string,
  newPhone: string,
): import("@/lib/mock-store").PhoneUpdateResult {
  const result = store.updateVoucherPhone(ref, newPhone);
  if (result.ok) {
    updateVoucherPhoneFn({
      data: { system_id: getSystemId(), ref, new_phone: newPhone },
    }).catch((e) => console.warn("[supabase] updateVoucherPhone failed:", e));
  }
  return result;
}

export function getPhoneEditLog(
  ref: string,
): import("@/lib/mock-store").PhoneEditLog | null {
  getPhoneEditLogFn({
    data: { system_id: getSystemId(), payment_reference: ref },
  })
    .then((res) => {
      if (res.ok && res.log) {
        const log = res.log as { edits: number[]; last_edit_at: number };
        store.syncPhoneEditLog(ref, log.edits, log.last_edit_at);
      }
    })
    .catch(() => { /* offline */ });
  return store.getPhoneEditLog(ref);
}

// ---- Plan management -------------------------------------------------------
export type { StoredPlan } from "@/lib/mock-store";
export const resetPlans = store.resetStoredPlans;

/**
 * Returns stored plans from Supabase; falls back to localStorage.
 */
export async function getStoredPlans(): Promise<import("@/lib/mock-store").StoredPlan[]> {
  try {
    const res = await getPlansFn({ data: { system_id: getSystemId() } });
    if (res.ok && res.plans.length > 0) {
      return res.plans.map((p: Record<string, unknown>) => ({
        id: p.plan_id as string,
        name: p.name as string,
        description: (p.description as string) ?? "",
        duration: p.duration as string,
        durationMinutes: p.duration_minutes as number,
        speed: (p.speed as string) ?? undefined,
        price: p.price as number,
        epaymentFee: (p.epayment_fee as number) ?? undefined,
        popular: (p.popular as boolean) ?? false,
      })) as import("@/lib/mock-store").StoredPlan[];
    }
  } catch { /* offline */ }
  return store.getStoredPlans();
}

/**
 * Add a new plan to Supabase and local cache.
 */
export async function addPlan(plan: import("@/lib/mock-store").StoredPlan): Promise<void> {
  store.addStoredPlan(plan);
  await upsertPlanFn({
    data: {
      system_id: getSystemId(),
      plan_id: plan.id,
      name: plan.name,
      description: plan.description ?? "",
      duration: plan.duration,
      duration_minutes: plan.durationMinutes,
      speed: plan.speed,
      price: plan.price,
      epayment_fee: plan.epaymentFee,
      popular: plan.popular ?? false,
      sort_order: 0,
      active: true,
    },
  }).catch((e) => console.warn("[supabase] addPlan failed:", e));
}

/**
 * Update an existing plan in Supabase and local cache.
 */
export async function updatePlan(id: string, plan: import("@/lib/mock-store").StoredPlan): Promise<void> {
  store.updateStoredPlan(id, plan);
  await upsertPlanFn({
    data: {
      system_id: getSystemId(),
      plan_id: plan.id,
      name: plan.name,
      description: plan.description ?? "",
      duration: plan.duration,
      duration_minutes: plan.durationMinutes,
      speed: plan.speed,
      price: plan.price,
      epayment_fee: plan.epaymentFee,
      popular: plan.popular ?? false,
      sort_order: 0,
      active: true,
    },
  }).catch((e) => console.warn("[supabase] updatePlan failed:", e));
}

/**
 * Delete (soft-delete) a plan in Supabase and local cache.
 */
export async function deletePlan(id: string): Promise<void> {
  store.deleteStoredPlan(id);
  await deletePlanFn({ data: { system_id: getSystemId(), plan_id: id } })
    .catch((e) => console.warn("[supabase] deletePlan failed:", e));
}

// ---- Credit system ---------------------------------------------------------

export async function getCreditRecord(): Promise<import("@/lib/mock-store").CreditRecord> {
  try {
    const res = await getCreditsFn({ data: { system_id: getSystemId() } });
    if (res.ok && res.record) {
      const r = res.record as Record<string, unknown>;
      return {
        balance: r.balance as number,
        totalPurchased: r.total_purchased as number,
        totalConsumed: r.total_consumed as number,
        reloads: store.getCreditRecord().reloads,
      };
    }
  } catch { /* offline */ }
  return store.getCreditRecord();
}

export async function deductCredits(amount: number): Promise<boolean> {
  store.deductCredits(amount);
  try {
    const res = await deductCreditsFn({ data: { system_id: getSystemId(), amount } });
    return res.ok && (res as { success?: boolean }).success !== false;
  } catch {
    return true;
  }
}

export const createCreditReload = store.createCreditReload;
export const confirmCreditReload = store.confirmCreditReload;
export const failCreditReload = store.failCreditReload;
export const resetCredits = store.resetCredits;
export const CREDIT_PACKAGES = store.CREDIT_PACKAGES;
export const DEFAULT_CREDIT_BALANCE = store.DEFAULT_CREDIT_BALANCE;
export type { CreditRecord, CreditReloadTransaction, CreditReloadPackage } from "@/lib/mock-store";

// ---- Refund system ---------------------------------------------------------
export const getRefundConfig = store.getRefundConfig;
export const setRefundAutoApprove = store.setRefundAutoApprove;

export async function getRefunds(): Promise<import("@/lib/mock-store").RefundRequest[]> {
  try {
    const res = await getRefundsFn({ data: { system_id: getSystemId() } });
    if (res.ok) return (res.refunds as import("@/lib/mock-store").RefundRequest[]) ?? [];
  } catch { /* offline */ }
  return store.getRefunds();
}

export async function createRefundRequest(
  voucherCode: string,
  planId: PlanId,
  saleAmount: number,
  saleTimestamp: number,
  reason: import("@/lib/mock-store").RefundReason,
  notes?: string,
): Promise<import("@/lib/mock-store").RefundRequest | null> {
  try {
    const res = await createRefundFn({
      data: {
        system_id: getSystemId(),
        voucher_code: voucherCode,
        plan_id: planId,
        sale_amount: saleAmount,
        sale_timestamp: saleTimestamp,
        reason,
        notes,
      },
    });
    if (res.ok && res.refund) return res.refund as import("@/lib/mock-store").RefundRequest;
  } catch { /* offline */ }
  return store.createRefundRequest(voucherCode, planId, saleAmount, saleTimestamp, reason, notes);
}

export async function approveRefund(id: string): Promise<boolean> {
  try {
    const res = await resolveRefundFn({ data: { system_id: getSystemId(), id, action: "approve" } });
    if (res.ok) { store.approveRefund(id); return true; }
  } catch { /* offline */ }
  return store.approveRefund(id);
}

export async function rejectRefund(id: string): Promise<boolean> {
  try {
    const res = await resolveRefundFn({ data: { system_id: getSystemId(), id, action: "reject" } });
    if (res.ok) { store.rejectRefund(id); return true; }
  } catch { /* offline */ }
  return store.rejectRefund(id);
}

export const getRefundedVoucherCodes = store.getRefundedVoucherCodes;
export const resetRefunds = store.resetRefunds;
export const REFUND_WINDOW_MS = store.REFUND_WINDOW_MS;
export const REFUND_REASONS = store.REFUND_REASONS;
export type { RefundRequest, RefundConfig, RefundReason } from "@/lib/mock-store";

// ---- helpers ---------------------------------------------------------------
function delay(ms: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, ms));
}
