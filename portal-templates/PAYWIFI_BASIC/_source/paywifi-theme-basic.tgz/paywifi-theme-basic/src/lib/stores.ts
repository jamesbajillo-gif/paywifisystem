/**
 * Dummy roster of physical stores where customers can pay cash.
 *
 * Used on `/checkout` (cash flow) to let the customer pick which store
 * they'll walk to. The selected `storeId` is persisted on the voucher
 * record so the operator's dialog + the customer's pending screen can
 * display the chosen store name + address.
 *
 * TODO(live): when milestone #1 wires the real backend, this list moves
 * to a DB-backed `stores` table scoped by venue (so each venue's
 * customers only see that venue's stores). Today the list is global —
 * fine for a single-store demo.
 */

export type Store = {
  id: string;
  name: string;
  address: string;
  /**
   * Optional venue scoping — if set, this store only appears for that
   * venue. Omitted means "available at all venues". Used by the dropdown
   * to filter the customer-facing list once per-venue stores exist.
   */
  venue?: string;
};

export const STORES: Store[] = [
  {
    id: "main-counter",
    name: "Main Counter",
    address: "Ground floor · near the entrance",
  },
  {
    id: "downtown-branch",
    name: "Downtown Branch",
    address: "456 King Avenue",
  },
  {
    id: "airport-kiosk",
    name: "Airport Kiosk",
    address: "Terminal 2 · departures",
  },
  {
    id: "lobby-desk",
    name: "Lobby Desk",
    address: "Front lobby · 7am–10pm",
  },
];

export function getStore(id: string | undefined): Store | undefined {
  if (!id) return undefined;
  return STORES.find((s) => s.id === id);
}
