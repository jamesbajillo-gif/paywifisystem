/**
 * local-api.ts — local-first API URL resolver.
 *
 * On a captive-portal hotspot, the device usually has reliable access to a
 * local router or local services BEFORE WAN egress works. We try a small
 * list of internal addresses first and only fall back to the WAN endpoint if
 * none respond. The result is cached for the lifetime of the page so we
 * don't ping the candidates on every call.
 *
 * Resolution order:
 *   1. http://127.0.0.1/api        (running on the access point itself)
 *   2. http://10.10.0.1/api        (typical paywifi gateway address)
 *   3. https://db.techpinoy.net    (WAN fallback — the prod Supabase URL)
 *
 * Configure overrides via Vite env vars:
 *   VITE_LOCAL_API_CANDIDATES="http://127.0.0.1/api,http://10.10.0.1/api"
 *   VITE_REMOTE_API_FALLBACK="https://db.techpinoy.net"
 */

const DEFAULT_LOCAL_CANDIDATES = [
  "http://127.0.0.1/api",
  "http://10.10.0.1/api",
];

const PROBE_TIMEOUT_MS = 800; // local probes are fast; bail quickly on WAN

let cachedBase: string | null = null;
let cachedPromise: Promise<string> | null = null;

function readCandidates(): string[] {
  try {
    // Vite-style env access — typed via vite/client
    const raw = (import.meta as unknown as { env?: Record<string, string> }).env?.VITE_LOCAL_API_CANDIDATES;
    if (raw && typeof raw === "string") {
      return raw.split(",").map((s) => s.trim()).filter(Boolean);
    }
  } catch { /* not vite runtime */ }
  return DEFAULT_LOCAL_CANDIDATES;
}

function readRemoteFallback(): string {
  try {
    const raw = (import.meta as unknown as { env?: Record<string, string> }).env?.VITE_REMOTE_API_FALLBACK;
    if (raw && typeof raw === "string") return raw;
    const sb = (import.meta as unknown as { env?: Record<string, string> }).env?.VITE_SUPABASE_URL;
    if (sb && typeof sb === "string") return sb;
  } catch { /* */ }
  return "https://db.techpinoy.net";
}

async function probe(url: string): Promise<boolean> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), PROBE_TIMEOUT_MS);
    const resp = await fetch(`${url}/health`, {
      method: "GET",
      signal: ctrl.signal,
      // Local probes — never send cookies; do not follow redirects to WAN
      credentials: "omit",
      redirect: "manual",
    });
    clearTimeout(t);
    return resp.ok || (resp.status >= 200 && resp.status < 400);
  } catch {
    return false;
  }
}

/**
 * Resolve the best API base URL for this device. Cached after first call.
 * Server-side calls (SSR) skip probing and go straight to the remote
 * fallback — local addresses are only meaningful on the captive device.
 */
export async function resolveApiBase(): Promise<string> {
  if (typeof window === "undefined") return readRemoteFallback();
  if (cachedBase) return cachedBase;
  if (cachedPromise) return cachedPromise;

  cachedPromise = (async () => {
    for (const candidate of readCandidates()) {
      // eslint-disable-next-line no-await-in-loop
      if (await probe(candidate)) {
        cachedBase = candidate;
        return candidate;
      }
    }
    cachedBase = readRemoteFallback();
    return cachedBase;
  })();

  return cachedPromise;
}

/**
 * Synchronous best-effort version — returns the cached base if known,
 * otherwise the remote fallback. Use in code paths that can't await
 * (e.g. constructing a Supabase client at module init).
 */
export function getApiBaseSync(): string {
  return cachedBase ?? readRemoteFallback();
}

/** Reset the cache — used by tests + by manual "Retry" actions. */
export function resetApiBaseCache(): void {
  cachedBase = null;
  cachedPromise = null;
}

/**
 * Fetch helper that tries local candidates first and falls back to remote
 * on a per-call basis. Use this when an individual request really needs
 * local-first behaviour (most code should rely on the cached resolver).
 */
export async function fetchLocalFirst(path: string, init?: RequestInit): Promise<Response> {
  const base = await resolveApiBase();
  return fetch(`${base}${path.startsWith("/") ? path : `/${path}`}`, init);
}
