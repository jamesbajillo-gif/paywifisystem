/**
 * DbOfflineBanner.tsx — friendly "we're refreshing" banner.
 *
 * Only renders once DbStatusContext has confirmed sustained backend
 * unreachability (after ~30 s of silent retries). The wording is
 * deliberately calm: never says "server", "database", "API", or "offline"
 * to the user.
 */

import { RefreshCw } from "lucide-react";
import { useDbStatus } from "@/components/DbStatusContext";

export function DbOfflineBanner() {
  const { status, retry } = useDbStatus();

  // Only show after we have crossed the silent-retry threshold.
  if (status !== "offline") return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between gap-3 bg-amber-500 px-4 py-2.5 text-white shadow-md">
      <div className="flex items-center gap-2 min-w-0">
        <RefreshCw className="h-4 w-4 shrink-0 animate-spin" />
        <span className="text-sm font-medium truncate">
          Refreshing connection… Please wait a moment.
        </span>
      </div>
      <button
        onClick={retry}
        className="flex shrink-0 items-center gap-1.5 rounded bg-white/20 px-2.5 py-1 text-xs font-semibold hover:bg-white/30 transition-colors"
      >
        Retry now
      </button>
    </div>
  );
}
