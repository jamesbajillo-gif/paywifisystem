import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Check,
  Copy,
  Loader2,
  AlertCircle,
  MessageSquare,
  Banknote,
  X,
  CheckCircle2,
  ArrowRight,
  Zap,
} from "lucide-react";
import {
  confirmAndIssueVoucherForReference,
  findByPaymentReference,
  getPlan,
  sendSmsReceipt,
} from "@/lib/portal-api";
import { formatPHP as fmt } from "@/lib/utils";
import { VENUES } from "@/lib/brand";
import { getStore } from "@/lib/stores";
import { trackEvent } from "@/lib/analytics";
import type { StoredVoucher } from "@/lib/mock-store";

type Props = {
  payment: StoredVoucher | null;
  onClose: (didProcess: boolean) => void;
};

type SheetState = "review" | "processing" | "success" | "error";

export function ConfirmPaymentDialog({ payment, onClose }: Props) {
  const [paymentReceived, setPaymentReceived] = useState(false);
  const [state, setState] = useState<SheetState>("review");
  const [issuedCode, setIssuedCode] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const inFlightRef = useRef(false);

  const plan = payment ? getPlan(payment.planId) : undefined;
  const venueName =
    payment?.venue && VENUES[payment.venue]
      ? VENUES[payment.venue].name
      : payment?.venue;
  const store = getStore(payment?.storeId);

  useEffect(() => {
    if (payment) {
      setPaymentReceived(false);
      setState("review");
      setIssuedCode(null);
      setErrorMsg(null);
      setCopied(false);
      inFlightRef.current = false;
    }
  }, [payment?.paymentReference]);

  useEffect(() => {
    if (payment) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [!!payment]);

  const onConfirm = async () => {
    if (!payment?.paymentReference || inFlightRef.current) return;
    inFlightRef.current = true;
    setState("processing");
    await new Promise((r) => setTimeout(r, 600));

    const fresh = findByPaymentReference(payment.paymentReference);
    const fail = (msg: string) => {
      setErrorMsg(msg);
      setState("error");
      inFlightRef.current = false;
    };
    if (!fresh) return fail("Payment reference not found.");
    if (fresh.voidedAt) return fail("This payment was cancelled by the customer.");
    if (fresh.confirmedAt) return fail("This payment was already confirmed.");
    if (fresh.redeemedAt) return fail("This voucher was already redeemed.");
    if (fresh.expiresAt && Date.now() >= fresh.expiresAt) return fail("This payment reference has expired.");

    const issueResult = await confirmAndIssueVoucherForReference(payment.paymentReference);
    if (!issueResult.ok) {
      if (issueResult.reason === "insufficient_credits") {
        return fail(
          "Insufficient credits (balance: " + issueResult.balance + " cr, need: " + issueResult.required + " cr). Please reload credits in the Credits tab before proceeding."
        );
      }
      if (issueResult.reason === "already_confirmed") return fail("This payment was already confirmed by another operator.");
      if (issueResult.reason === "expired") return fail("This payment reference has expired.");
      if (issueResult.reason === "voided") return fail("This payment was cancelled by the customer.");
      return fail("Could not generate voucher. Please refresh and try again.");
    }
    const voucherCode = issueResult.code;

    trackEvent("payment_success", {
      planId: payment.planId,
      method: "cash",
      price: plan?.price ?? 0,
      transactionId: payment.transactionId ?? "",
    });

    if (payment.phone) {
      void sendSmsReceipt({ phone: payment.phone, code: voucherCode, planId: payment.planId });
    }

    setIssuedCode(voucherCode);
    setState("success");
    inFlightRef.current = false;
  };

  const onCopy = () => {
    if (!issuedCode) return;
    navigator.clipboard.writeText(issuedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  if (!payment) return null;

  const isSuccess = state === "success";
  const isError = state === "error";
  const isProcessing = state === "processing";

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col"
      role="dialog"
      aria-modal="true"
      aria-label={isSuccess ? "Voucher issued" : "Confirm payment"}
    >
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={() => !isProcessing && onClose(isSuccess)}
      />

      <div className="relative mt-auto w-full max-h-[96dvh] flex flex-col bg-background rounded-t-3xl shadow-2xl overflow-hidden sm:m-auto sm:max-w-md sm:rounded-3xl sm:max-h-[90dvh]">

        <div className="flex justify-center pt-3 pb-1 shrink-0 sm:hidden">
          <div className="h-1.5 w-12 rounded-full bg-border" />
        </div>

        <div className="flex items-center justify-between gap-3 px-5 pt-4 pb-3 border-b border-border shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className={`h-10 w-10 rounded-2xl flex items-center justify-center shrink-0 ${
              isSuccess ? "bg-success/15" : isError ? "bg-destructive/10" : "bg-primary/10"
            }`}>
              {isSuccess
                ? <CheckCircle2 className="h-5 w-5 text-success" />
                : isError
                  ? <AlertCircle className="h-5 w-5 text-destructive" />
                  : <Banknote className="h-5 w-5 text-primary" />
              }
            </div>
            <div className="min-w-0">
              <p className="text-lg font-bold leading-tight truncate">
                {isSuccess ? "Voucher issued" : isError ? "Cannot complete" : "Confirm payment"}
              </p>
              <p className="text-xs text-muted-foreground truncate">
                {isSuccess
                  ? "Give the code to the customer"
                  : isError
                    ? "Transaction failed"
                    : "Cash at counter"}
              </p>
            </div>
          </div>
          {!isProcessing && (
            <button
              onClick={() => onClose(isSuccess)}
              aria-label="Close"
              className="h-9 w-9 flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground hover:bg-accent transition-colors shrink-0"
            >
              <X className="h-5 w-5" />
            </button>
          )}
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-4 min-h-0">

          {/* REVIEW */}
          {state === "review" && (
            <>
              <div className="rounded-2xl border-2 border-primary bg-primary/5 p-4 text-center shrink-0">
                <p className="text-xs font-bold uppercase tracking-widest text-primary mb-1">Amount due</p>
                <p className="text-5xl font-black text-primary tracking-tight">
                  {plan?.price !== undefined ? fmt(plan.price) : "N/A"}
                </p>
                <p className="mt-1 text-sm text-muted-foreground">Collect this exact amount in cash</p>
              </div>

              <div className="rounded-2xl border-2 border-border bg-card p-4 flex flex-col gap-2.5">
                <DetailRow label="Reference" value={
                  <span className="font-mono font-bold text-base tracking-wider">{payment.paymentReference}</span>
                } />
                <DetailRow label="Plan" value={plan?.name ?? payment.planId} bold />
                {store ? (
                  <DetailRow label="Store" value={
                    <span>
                      {store.name}
                      <span className="block text-xs text-muted-foreground font-normal">{store.address}</span>
                    </span>
                  } />
                ) : venueName ? (
                  <DetailRow label="Venue" value={venueName} bold />
                ) : null}
                {payment.phone && (
                  <DetailRow label="Mobile" value={
                    <span className="inline-flex items-center gap-1.5">
                      <MessageSquare className="h-3.5 w-3.5 text-muted-foreground" />
                      {payment.phone}
                    </span>
                  } />
                )}
                <div className="pt-1 border-t border-border">
                  <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-600 dark:text-amber-400">
                    Awaiting confirmation
                  </span>
                </div>
              </div>

              <label className="flex items-start gap-4 cursor-pointer select-none rounded-2xl border-2 border-border bg-card p-4 active:bg-secondary/50 transition-colors">
                <span
                  className={`mt-0.5 h-7 w-7 rounded-xl border-2 flex items-center justify-center shrink-0 transition-colors ${
                    paymentReceived
                      ? "bg-primary border-primary text-primary-foreground"
                      : "border-border bg-background"
                  }`}
                  aria-hidden="true"
                >
                  {paymentReceived && <Check className="h-4 w-4" strokeWidth={3} />}
                </span>
                <span className="flex-1 min-w-0">
                  <input
                    type="checkbox"
                    checked={paymentReceived}
                    onChange={(e) => setPaymentReceived(e.target.checked)}
                    className="sr-only"
                    aria-label="Payment Received"
                  />
                  <p className="text-base font-bold">Payment received</p>
                  <p className="text-sm text-muted-foreground mt-0.5 leading-snug">
                    Required. Confirm cash is in hand before generating the voucher.
                  </p>
                </span>
              </label>
            </>
          )}

          {/* PROCESSING */}
          {state === "processing" && (
            <div className="flex-1 flex flex-col items-center justify-center text-center gap-4 py-12">
              <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center">
                <Loader2 className="h-10 w-10 text-primary animate-spin" />
              </div>
              <div>
                <p className="text-xl font-bold">Generating voucher...</p>
                <p className="text-sm text-muted-foreground mt-1">Updating customer portal session.</p>
              </div>
            </div>
          )}

          {/* SUCCESS */}
          {state === "success" && issuedCode && (
            <div className="flex flex-col gap-4">

              <div className="flex flex-col items-center text-center gap-2 py-2">
                <div className="h-16 w-16 rounded-full bg-success/15 flex items-center justify-center">
                  <CheckCircle2 className="h-9 w-9 text-success" />
                </div>
                <p className="text-xl font-bold text-success">Payment confirmed!</p>
                <p className="text-sm text-muted-foreground">Read or copy the voucher code to the customer.</p>
              </div>

              <div className="w-full rounded-2xl border-2 border-success/40 bg-success/5 p-5 flex flex-col items-center gap-3">
                <p className="text-xs font-bold uppercase tracking-[0.2em] text-success">Voucher code</p>
                <p className="font-mono font-black text-4xl tracking-[0.25em] text-center break-all leading-tight">
                  {issuedCode}
                </p>
                <button
                  onClick={onCopy}
                  className="inline-flex items-center gap-2 h-12 px-5 rounded-xl text-base font-bold bg-card border-2 border-border hover:border-primary transition-colors w-full justify-center"
                >
                  {copied ? <Check className="h-5 w-5 text-success" /> : <Copy className="h-5 w-5" />}
                  {copied ? "Copied!" : "Copy code"}
                </button>
              </div>

              {plan && (
                <div className="rounded-2xl border-2 border-border bg-card p-4 flex items-start gap-3">
                  <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <Zap className="h-5 w-5 text-primary" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-base font-bold truncate">{plan.name}</p>
                    <p className="text-sm text-muted-foreground mt-0.5">
                      {fmt(plan.price)}
                      {plan.duration ? ` · ${plan.duration}` : ""}
                      {plan.speed ? ` · ${plan.speed}` : ""}
                    </p>
                  </div>
                </div>
              )}

              {payment.phone && (
                <div className="rounded-xl border-2 border-primary/20 bg-primary/5 px-4 py-3 flex items-center gap-2">
                  <MessageSquare className="h-4 w-4 text-primary shrink-0" />
                  <p className="text-sm font-semibold text-primary">
                    Code also sent via SMS to{" "}
                    <span className="font-mono">{payment.phone}</span>
                  </p>
                </div>
              )}
            </div>
          )}

          {/* ERROR */}
          {state === "error" && errorMsg && (
            <div className="flex flex-col items-center text-center gap-4 py-8">
              <div className="h-16 w-16 rounded-full bg-destructive/10 flex items-center justify-center">
                <AlertCircle className="h-9 w-9 text-destructive" />
              </div>
              <div className="w-full rounded-2xl border-2 border-destructive/30 bg-destructive/5 p-4">
                <p className="text-base font-bold text-destructive">Transaction failed</p>
                <p className="text-sm text-muted-foreground mt-2 leading-snug">{errorMsg}</p>
              </div>
            </div>
          )}

        </div>

        <div className="shrink-0 border-t border-border px-5 py-4 safe-bottom flex flex-col gap-3">
          {state === "review" && (
            <>
              <Button
                onClick={onConfirm}
                disabled={!paymentReceived}
                className="w-full h-16 text-lg font-bold rounded-2xl disabled:opacity-40"
              >
                <ArrowRight className="h-5 w-5 mr-2" />
                Confirm and generate voucher
              </Button>
              <Button
                variant="secondary"
                onClick={() => onClose(false)}
                className="w-full h-12 text-base font-semibold rounded-xl border-2 border-border text-muted-foreground"
              >
                Cancel
              </Button>
            </>
          )}
          {state === "success" && (
            <Button
              onClick={() => onClose(true)}
              className="w-full h-16 text-lg font-bold rounded-2xl"
            >
              <Check className="h-5 w-5 mr-2" />
              Done - next customer
            </Button>
          )}
          {state === "error" && (
            <Button
              variant="secondary"
              onClick={() => onClose(false)}
              className="w-full h-14 text-base font-semibold rounded-xl border-2 border-border"
            >
              Close
            </Button>
          )}
        </div>

      </div>
    </div>
  );
}

function DetailRow({
  label,
  value,
  bold,
}: {
  label: string;
  value: React.ReactNode;
  bold?: boolean;
}) {
  return (
    <div className="flex items-start justify-between gap-3 min-w-0">
      <p className="text-sm text-muted-foreground shrink-0">{label}</p>
      <p className={`text-sm text-right min-w-0 ${bold ? "font-bold" : "font-medium"}`}>{value}</p>
    </div>
  );
}
