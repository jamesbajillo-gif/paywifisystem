import { Clock, ArrowRight, MessageSquare, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getPlan } from "@/lib/portal-api";
import { formatPHP } from "@/lib/utils";
import type { StoredVoucher } from "@/lib/mock-store";

type Props = {
  pendingPayments: StoredVoucher[];
  onSelectPayment: (payment: StoredVoucher) => void;
};

export function PendingPaymentsList({ pendingPayments, onSelectPayment }: Props) {
  return (
    <section
      aria-label="Pending payments"
      className="rounded-2xl border-2 border-border bg-card p-4 min-w-0"
    >
      <div className="flex items-center justify-between gap-3 mb-1">
        <div className="flex items-center gap-2 min-w-0">
          <Clock className="h-5 w-5 text-primary shrink-0" />
          <h2 className="text-lg font-bold truncate">Pending payments</h2>
        </div>
        {pendingPayments.length > 0 && (
          <span className="min-w-[1.5rem] h-6 px-2 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center shrink-0 tabular-nums">
            {pendingPayments.length}
          </span>
        )}
      </div>
      <p className="text-xs text-muted-foreground mb-4">
        Cash references awaiting counter confirmation. Tap a row to confirm and issue a voucher.
      </p>

      {pendingPayments.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-8 text-center">
          <Clock className="h-8 w-8 text-muted-foreground/40 mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">
            No pending payments right now.
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            They appear here when customers select Cash on the portal.
          </p>
        </div>
      ) : (
        <ul className="flex flex-col gap-2">
          {pendingPayments.map((p) => (
            <PendingRow key={p.paymentReference} payment={p} onSelect={onSelectPayment} />
          ))}
        </ul>
      )}
    </section>
  );
}

function PendingRow({
  payment,
  onSelect,
}: {
  payment: StoredVoucher;
  onSelect: (payment: StoredVoucher) => void;
}) {
  const plan = getPlan(payment.planId);
  const issuedAgo = formatRelative(payment.issuedAt);
  const expiresInMin =
    payment.expiresAt !== undefined
      ? Math.max(0, Math.round((payment.expiresAt - Date.now()) / 60000))
      : undefined;
  const expiringSoon = expiresInMin !== undefined && expiresInMin <= 3;

  return (
    <li
      className={`rounded-xl border-2 p-3 flex flex-col sm:flex-row sm:items-center gap-3 min-w-0 transition-colors ${
        expiringSoon
          ? "border-destructive/40 bg-destructive/5"
          : "border-border bg-background/40 hover:border-primary/40"
      }`}
    >
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="font-mono font-bold text-sm tracking-wider">
            {payment.paymentReference}
          </p>
          {expiringSoon && (
            <span className="inline-flex items-center gap-1 text-xs font-bold text-destructive bg-destructive/10 px-2 py-0.5 rounded-full">
              <AlertTriangle className="h-3 w-3" />
              Expiring soon
            </span>
          )}
        </div>
        <p className="text-xs text-muted-foreground mt-0.5 truncate">
          {plan?.name ?? payment.planId}
          {plan?.price != null && (
            <> · <span className="font-semibold text-foreground">{formatPHP(plan.price)}</span></>
          )}
          {" · "}issued {issuedAgo}
          {expiresInMin !== undefined && !expiringSoon && (
            <> · expires in {expiresInMin}m</>
          )}
        </p>
        {payment.phone && (
          <p className="text-xs text-muted-foreground mt-0.5 inline-flex items-center gap-1">
            <MessageSquare className="h-3 w-3" />
            {payment.phone}
          </p>
        )}
      </div>
      <Button
        onClick={() => onSelect(payment)}
        className="h-10 px-4 rounded-xl text-sm font-bold shrink-0"
        aria-label={`Confirm payment for reference ${payment.paymentReference}`}
      >
        Confirm
        <ArrowRight className="h-4 w-4 ml-1.5" />
      </Button>
    </li>
  );
}

function formatRelative(ts: number): string {
  const diffMs = Date.now() - ts;
  const min = Math.round(diffMs / 60000);
  if (min < 1) return "just now";
  if (min < 60) return `${min}m ago`;
  const hr = Math.round(min / 60);
  if (hr < 24) return `${hr}h ago`;
  return new Date(ts).toLocaleDateString(undefined, { month: "short", day: "numeric" });
}
