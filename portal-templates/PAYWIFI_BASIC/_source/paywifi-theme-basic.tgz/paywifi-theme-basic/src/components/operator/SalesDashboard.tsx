import { useState, useEffect, useCallback } from "react";
import {
  PhilippinePeso, Ticket, TrendingUp, RefreshCw, RotateCcw,
} from "lucide-react";
import { getPlan, getRefundedVoucherCodes } from "@/lib/portal-api";
import { formatPHP } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { VoucherTable } from "@/components/admin/VoucherTable";
import type { StoredVoucher } from "@/lib/mock-store";

type Props = { vouchers: StoredVoucher[]; onRefresh?: () => void };

export function SalesDashboard({ vouchers, onRefresh }: Props) {
  const [refundedCodes, setRefundedCodes] = useState<Set<string>>(new Set());

  const refresh = useCallback(() => {
    setRefundedCodes(getRefundedVoucherCodes());
    onRefresh?.();
  }, [onRefresh]);

  useEffect(() => { refresh(); }, [refresh]);

  // ── Sales calculations ───────────────────────────────────────────────────
  const startOfToday = (() => {
    const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime();
  })();

  const isConfirmedSale = (v: StoredVoucher) =>
    !v.voidedAt && (v.transactionId?.startsWith("ADMIN-") || !!v.confirmedAt);

  const saleTs = (v: StoredVoucher) => v.confirmedAt ?? v.issuedAt;

  const allSales    = vouchers.filter(isConfirmedSale).sort((a, b) => saleTs(b) - saleTs(a));
  const activeSales = allSales.filter((v) => !refundedCodes.has(v.code));
  const todaySales  = activeSales.filter((v) => saleTs(v) >= startOfToday);

  const totalRevenue  = activeSales.reduce((s, v) => s + (getPlan(v.planId)?.price ?? 0), 0);
  const todayRevenue  = todaySales.reduce((s, v) => s + (getPlan(v.planId)?.price ?? 0), 0);
  const refundCount   = allSales.length - activeSales.length;
  const refundedValue = allSales
    .filter((v) => refundedCodes.has(v.code))
    .reduce((s, v) => s + (getPlan(v.planId)?.price ?? 0), 0);

  return (
    <div className="flex flex-col gap-4">

      {/* ── Today quick stats ──────────────────────────────────────────── */}
      <section aria-label="Today's sales" className="grid grid-cols-2 gap-3">
        <StatCard
          icon={<PhilippinePeso className="h-5 w-5" />}
          label="Today's revenue"
          value={formatPHP(todayRevenue)}
          tone="success"
        />
        <StatCard
          icon={<Ticket className="h-5 w-5" />}
          label="Vouchers sold today"
          value={String(todaySales.length)}
          tone="primary"
        />
      </section>

      {/* ── Financial summary ──────────────────────────────────────────── */}
      <section
        aria-label="Financial summary"
        className="rounded-2xl border-2 border-border bg-card overflow-hidden"
      >
        <div className="px-4 pt-4 pb-3 flex items-center gap-2 border-b border-border">
          <TrendingUp className="h-4 w-4 text-primary" />
          <p className="text-sm font-bold">Financial summary</p>
        </div>

        <div className="px-4 py-4 border-b border-border">
          <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">
            Net revenue (all-time)
          </p>
          <p className="text-4xl font-black tabular-nums">{formatPHP(totalRevenue)}</p>
          <p className="text-xs text-muted-foreground mt-1">
            {activeSales.length} voucher{activeSales.length !== 1 ? "s" : ""} confirmed
          </p>
        </div>

        <div className="divide-y divide-border">
          <FinRow
            label="Gross sales"
            sub="Before refunds"
            value={formatPHP(allSales.reduce((s, v) => s + (getPlan(v.planId)?.price ?? 0), 0))}
            tone="muted"
          />
          {refundCount > 0 && (
            <FinRow
              label={`Refunds (${refundCount})`}
              sub="Approved refunds deducted"
              value={`−${formatPHP(refundedValue)}`}
              tone="destructive"
            />
          )}
          <FinRow
            label="Net revenue"
            sub="Your earnings after refunds"
            value={formatPHP(totalRevenue)}
            tone="success"
          />
        </div>
      </section>

      <Button
        variant="secondary"
        onClick={refresh}
        className="h-12 rounded-xl font-semibold border-2 border-border text-sm"
      >
        <RefreshCw className="h-4 w-4 mr-2" />
        Refresh
      </Button>

      {/* ── Recent sales table ─────────────────────────────────────────── */}
      <VoucherTable
        vouchers={allSales}
        refundedCodes={refundedCodes}
        limit={20}
        title="Recent sales"
        emptyMessage="No sales yet. Confirm a pending payment or issue a manual voucher to see sales here."
        onRefund={refresh}
      />
    </div>
  );
}

// ─── StatCard ─────────────────────────────────────────────────────────────────

function StatCard({
  icon, label, value, tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  tone: "primary" | "success";
}) {
  const iconBg =
    tone === "success" ? "bg-success/15 text-success" : "bg-primary/10 text-primary";
  return (
    <div className="rounded-2xl border-2 border-border bg-card p-4 min-w-0">
      <div className="flex items-center gap-2 mb-3">
        <div className={`h-9 w-9 rounded-xl flex items-center justify-center shrink-0 ${iconBg}`}>
          {icon}
        </div>
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground truncate leading-tight">
          {label}
        </p>
      </div>
      <p className="text-3xl font-bold tracking-tight truncate">{value}</p>
    </div>
  );
}

// ─── FinRow ───────────────────────────────────────────────────────────────────

function FinRow({
  label, sub, value, tone,
}: {
  label: string;
  sub: string;
  value: string;
  tone: "muted" | "success" | "destructive" | "amber";
}) {
  const valueColor =
    tone === "success"     ? "text-success" :
    tone === "destructive" ? "text-destructive" :
    tone === "amber"       ? "text-amber-600 dark:text-amber-400" :
    "text-foreground";
  return (
    <div className="px-4 py-3 flex items-center justify-between gap-3 min-w-0">
      <div className="min-w-0">
        <p className="text-sm font-semibold truncate">{label}</p>
        <p className="text-xs text-muted-foreground truncate">{sub}</p>
      </div>
      <p className={`text-lg font-black tabular-nums shrink-0 ${valueColor}`}>{value}</p>
    </div>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

export { FinRow };
