import { useState, useEffect, useCallback } from "react";
import {
  getCreditRecord,
  createCreditReload,
  confirmCreditReload,
  failCreditReload,
  CREDIT_PACKAGES,
  type CreditRecord,
  type CreditReloadPackage,
  type CreditReloadTransaction,
} from "@/lib/portal-api";
import { formatPHP } from "@/lib/utils";
import { getXenditConfig, getActiveXenditChannelMeta } from "@/lib/xendit-client";
import {
  Coins,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  Clock,
  XCircle,
  ArrowRight,
  X,
  Loader2,
  Copy,
  Check,
  AlertTriangle,
} from "lucide-react";
import { Button } from "@/components/ui/button";

// ─── Credit Panel ─────────────────────────────────────────────────────────────

type Sheet = "closed" | "packages" | "epayment";

export function CreditPanel() {
  // Resolve active Xendit channel for the credit reload payment method.
  // Falls back to "GCash" if Xendit is unconfigured.
  const activeChannelMeta = (() => {
    try {
      const cfg = getXenditConfig();
      return getActiveXenditChannelMeta(cfg) ?? { label: "GCash", id: "GCASH" as const };
    } catch {
      return { label: "GCash", id: "GCASH" as const };
    }
  })();
  const reloadChannelLabel = activeChannelMeta.label;
  const [record, setRecord] = useState<CreditRecord | null>(null);
  const [sheet, setSheet] = useState<Sheet>("closed");
  const [activeTxn, setActiveTxn] = useState<CreditReloadTransaction | null>(null);

  const refresh = useCallback(() => { void getCreditRecord().then(setRecord); }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const onSelectPackage = (pkg: CreditReloadPackage) => {
    const txn = createCreditReload(pkg);
    setActiveTxn(txn);
    setSheet("epayment");
    refresh();
  };

  const onConfirmReload = (ref?: string) => {
    if (!activeTxn) return;
    confirmCreditReload(activeTxn.id, ref);
    setActiveTxn(null);
    setSheet("closed");
    refresh();
  };

  const onCancelReload = () => {
    if (activeTxn) failCreditReload(activeTxn.id);
    setActiveTxn(null);
    setSheet("closed");
    refresh();
  };

  if (!record) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const lowBalance = record.balance < 50;
  const criticalBalance = record.balance < 10;

  return (
    <>
      <div className="flex flex-col gap-4">

        {/* ── Balance hero card ─────────────────────────────────────────── */}
        <div className={`rounded-2xl border-2 p-5 ${
          criticalBalance
            ? "border-destructive/40 bg-destructive/5"
            : lowBalance
              ? "border-amber-500/40 bg-amber-500/8"
              : "border-primary/30 bg-primary/5"
        }`}>
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <Coins className={`h-4 w-4 shrink-0 ${
                  criticalBalance ? "text-destructive" : lowBalance ? "text-amber-600" : "text-primary"
                }`} />
                <p className={`text-xs font-bold uppercase tracking-wider ${
                  criticalBalance ? "text-destructive" : lowBalance ? "text-amber-600" : "text-primary"
                }`}>
                  Credit balance
                </p>
              </div>
              <p className={`text-5xl font-black tabular-nums leading-none ${
                criticalBalance ? "text-destructive" : lowBalance ? "text-amber-700 dark:text-amber-400" : "text-foreground"
              }`}>
                {record.balance.toLocaleString()}
                <span className="text-xl font-bold text-muted-foreground ml-1.5">cr</span>
              </p>
              {criticalBalance && (
                <div className="mt-2 flex items-center gap-1.5 text-destructive">
                  <AlertCircle className="h-3.5 w-3.5 shrink-0" />
                  <p className="text-xs font-semibold">Credits critically low — reload now to keep generating vouchers</p>
                </div>
              )}
              {!criticalBalance && lowBalance && (
                <div className="mt-2 flex items-center gap-1.5 text-amber-600">
                  <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                  <p className="text-xs font-semibold">Balance running low</p>
                </div>
              )}
            </div>
            <Button
              onClick={() => setSheet("packages")}
              className="h-12 px-5 rounded-2xl font-bold shrink-0 text-base"
            >
              Reload
              <ArrowRight className="h-4 w-4 ml-1.5" />
            </Button>
          </div>
        </div>

        {/* ── Stats row ─────────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-2xl border-2 border-border bg-card p-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
              Total purchased
            </p>
            <p className="text-3xl font-black tabular-nums">
              {record.totalPurchased.toLocaleString()}
              <span className="text-sm font-bold text-muted-foreground ml-1">cr</span>
            </p>
          </div>
          <div className="rounded-2xl border-2 border-border bg-card p-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
              Total consumed
            </p>
            <p className="text-3xl font-black tabular-nums">
              {record.totalConsumed.toLocaleString()}
              <span className="text-sm font-bold text-muted-foreground ml-1">cr</span>
            </p>
          </div>
        </div>

        {/* ── How credits work ──────────────────────────────────────────── */}
        <div className="rounded-2xl border-2 border-border bg-card p-4">
          <div className="flex items-center gap-2 mb-3">
            <Coins className="h-4 w-4 text-primary" />
            <p className="text-sm font-bold">How credits work</p>
          </div>
          <div className="flex flex-col gap-2">
            <div className="flex items-start gap-3">
              <span className="text-xs font-black text-primary bg-primary/10 rounded-lg px-2 py-1 shrink-0 tabular-nums">1 cr</span>
              <p className="text-sm text-muted-foreground">= ₱1 voucher value. A ₱15 voucher costs 15 credits.</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-xs font-black text-primary bg-primary/10 rounded-lg px-2 py-1 shrink-0">Auto</span>
              <p className="text-sm text-muted-foreground">Credits deducted automatically on each voucher generated.</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-xs font-black text-primary bg-primary/10 rounded-lg px-2 py-1 shrink-0">{reloadChannelLabel}</span>
              <p className="text-sm text-muted-foreground">Reload via {reloadChannelLabel}. Credits added only after payment is confirmed.</p>
            </div>
          </div>
        </div>

        {/* ── Reload history ────────────────────────────────────────────── */}
        {record.reloads.length > 0 && (
          <div className="rounded-2xl border-2 border-border bg-card overflow-hidden">
            <div className="px-4 pt-4 pb-2 flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <p className="text-sm font-bold">Reload history</p>
            </div>
            <div className="divide-y divide-border">
              {record.reloads.slice(0, 10).map((txn) => (
                <ReloadHistoryRow key={txn.id} txn={txn} onRefresh={refresh} />
              ))}
            </div>
          </div>
        )}

        <Button
          variant="secondary"
          onClick={refresh}
          className="h-12 rounded-xl font-semibold border-2 border-border text-sm"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh balance
        </Button>
      </div>

      {/* ── Full-screen overlays — portal wizard style ─────────────────── */}
      {sheet === "packages" && (
        <PackageScreen
          channelLabel={reloadChannelLabel}
          onSelect={onSelectPackage}
          onBack={() => setSheet("closed")}
        />
      )}
      {sheet === "epayment" && activeTxn && (
        <EPaymentScreen
          txn={activeTxn}
          channelLabel={reloadChannelLabel}
          onConfirm={onConfirmReload}
          onCancel={onCancelReload}
        />
      )}
    </>
  );
}

// ─── Reload history row ───────────────────────────────────────────────────────

function ReloadHistoryRow({
  txn,
  onRefresh,
}: {
  txn: CreditReloadTransaction;
  onRefresh: () => void;
}) {
  return (
    <div className="px-4 py-3 flex items-center gap-3 min-w-0">
      <div className="shrink-0">
        {txn.status === "confirmed" ? (
          <CheckCircle2 className="h-4 w-4 text-success" />
        ) : txn.status === "failed" ? (
          <XCircle className="h-4 w-4 text-destructive" />
        ) : (
          <Clock className="h-4 w-4 text-amber-500" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-baseline justify-between gap-2">
          <p className="text-sm font-bold truncate">+{txn.credits.toLocaleString()} cr</p>
          <p className="text-xs text-muted-foreground shrink-0">{formatPHP(txn.price)}</p>
        </div>
        <p className="text-xs text-muted-foreground truncate">
          {txn.status === "confirmed"
            ? `Confirmed ${formatRelTime(txn.confirmedAt ?? txn.createdAt)}`
            : txn.status === "failed"
              ? "Cancelled"
              : `Pending · ${formatRelTime(txn.createdAt)}`}
          {txn.transactionRef && ` · ref ${txn.transactionRef}`}
        </p>
      </div>
      {txn.status === "pending" && (
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => { confirmCreditReload(txn.id); onRefresh(); }}
            className="h-8 px-2.5 rounded-xl text-xs font-bold bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 transition-colors"
          >
            Confirm
          </button>
          <button
            onClick={() => { failCreditReload(txn.id); onRefresh(); }}
            className="h-8 px-2.5 rounded-xl text-xs font-bold bg-destructive/10 text-destructive border border-destructive/20 hover:bg-destructive/20 transition-colors"
          >
            Fail
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Package picker — portal wizard style ────────────────────────────────────

function PackageScreen({
  channelLabel,
  onSelect,
  onBack,
}: {
  channelLabel: string;
  onSelect: (pkg: CreditReloadPackage) => void;
  onBack: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-background">
      {/* Close button row — matches PortalShell showClose pattern */}
      <div className="safe-top safe-x pt-3 flex items-center justify-end shrink-0 px-4">
        <button
          onClick={onBack}
          aria-label="Back to credits"
          className="h-9 w-9 flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Header — same as PortalShell main */}
      <div className="safe-x px-4 pt-2 pb-1 shrink-0">
        <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary mb-1">
          Operator · Reload credits
        </p>
        <h1 className="text-3xl font-bold tracking-tight leading-tight">
          Choose a package
        </h1>
        <p className="mt-1 text-base text-muted-foreground leading-snug">
          Credits are added only after your {channelLabel} payment is confirmed.
        </p>
      </div>

      {/* Scrollable body */}
      <div className="flex-1 overflow-y-auto safe-x px-4 py-5 flex flex-col gap-4 min-h-0">
        {CREDIT_PACKAGES.map((pkg) => (
          <button
            key={pkg.id}
            onClick={() => onSelect(pkg)}
            className="w-full rounded-2xl border-2 border-border bg-card hover:border-primary active:scale-[0.98] transition-all p-5 text-left flex items-center justify-between gap-4 min-w-0"
          >
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 mb-1">
                <Coins className="h-5 w-5 text-primary shrink-0" />
                <p className="text-2xl font-black leading-none">
                  {pkg.credits.toLocaleString()}
                  <span className="text-base font-bold text-muted-foreground ml-1">credits</span>
                </p>
              </div>
              <p className="text-sm text-muted-foreground">
                {(pkg.price / pkg.credits * 100).toFixed(1)}¢ per credit · pay via {channelLabel}
              </p>
            </div>
            <div className="shrink-0 text-right">
              <p className="text-3xl font-black text-primary leading-none">{formatPHP(pkg.price)}</p>
            </div>
          </button>
        ))}

        {/* Value comparison note */}
        <div className="rounded-2xl border-2 border-border bg-secondary/60 p-4 flex items-start gap-3">
          <AlertCircle className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
          <p className="text-sm text-muted-foreground leading-snug">
            Larger packages give better value. The 1,000 cr pack costs ₱0.50/credit vs ₱0.60/credit for the 500 cr pack.
          </p>
        </div>
      </div>

      {/* Sticky footer */}
      <div className="shrink-0 safe-x safe-bottom px-4 pt-3 pb-4 border-t border-border">
        <Button
          variant="secondary"
          onClick={onBack}
          className="w-full h-12 rounded-xl text-sm font-semibold border-2 border-border text-muted-foreground"
        >
          <X className="h-4 w-4 mr-1.5" />
          Cancel
        </Button>
      </div>
    </div>
  );
}

// ─── E-Payment screen — portal wizard style ──────────────────────────────────

function EPaymentScreen({
  txn,
  channelLabel,
  onConfirm,
  onCancel,
}: {
  txn: CreditReloadTransaction;
  channelLabel: string;
  onConfirm: (ref?: string) => void;
  onCancel: () => void;
}) {
  const [ref, setRef] = useState("");
  const [copied, setCopied] = useState(false);

  // Demo number — replace with real in production
  const EPAYMENT_NUMBER = "0917 123 4567";
  const EPAYMENT_NAME = "PayWifi Reload";

  const onCopyNumber = () => {
    navigator.clipboard.writeText(EPAYMENT_NUMBER.replace(/\s/g, ""));
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-background">
      {/* Close button row */}
      <div className="safe-top safe-x pt-3 flex items-center justify-end shrink-0 px-4">
        <button
          onClick={onCancel}
          aria-label="Cancel reload"
          className="h-9 w-9 flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Header */}
      <div className="safe-x px-4 pt-2 pb-1 shrink-0">
        <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary mb-1">
          Operator · {channelLabel} reload
        </p>
        <h1 className="text-3xl font-bold tracking-tight leading-tight">
          Send payment
        </h1>
        <p className="mt-1 text-base text-muted-foreground leading-snug">
          Send exactly{" "}
          <span className="font-bold text-foreground">{formatPHP(txn.price)}</span>{" "}
          via {channelLabel} to receive{" "}
          <span className="font-bold text-foreground">{txn.credits.toLocaleString()} credits</span>.
        </p>
      </div>

      {/* Scrollable body */}
      <main className="flex-1 overflow-y-auto safe-x px-4 py-4 flex flex-col gap-4 min-h-0">

        {/* Amount card */}
        <div className="rounded-2xl border-2 border-border bg-secondary/60 p-4 flex items-center justify-between gap-3 shrink-0 min-w-0">
          <div className="min-w-0 flex-1">
            <p className="text-xl font-bold truncate">
              {txn.credits.toLocaleString()} credits
            </p>
            <p className="text-sm text-muted-foreground mt-0.5">via {channelLabel}</p>
          </div>
          <p className="text-3xl font-bold shrink-0 whitespace-nowrap">
            {formatPHP(txn.price)}
          </p>
        </div>

        {/* Send-to card */}
        <div className="rounded-2xl border-2 border-border bg-card p-4 flex flex-col gap-3">
          <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
            Send to
          </p>
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground mb-0.5">{channelLabel} number</p>
              <p className="text-xl font-bold font-mono">{EPAYMENT_NUMBER}</p>
            </div>
            <button
              onClick={onCopyNumber}
              className="h-10 px-3 rounded-xl border-2 border-border bg-card hover:border-primary flex items-center gap-1.5 text-sm font-semibold transition-colors shrink-0"
            >
              {copied ? <Check className="h-4 w-4 text-primary" /> : <Copy className="h-4 w-4" />}
              {copied ? "Copied" : "Copy"}
            </button>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-0.5">Account name</p>
            <p className="text-base font-bold">{EPAYMENT_NAME}</p>
          </div>
        </div>

        {/* Optional transaction reference */}
        <div className="flex flex-col gap-2">
          <p className="text-sm font-semibold text-muted-foreground px-0.5">
            {channelLabel} reference number{" "}
            <span className="font-normal text-muted-foreground/60">(optional)</span>
          </p>
          <input
            type="text"
            value={ref}
            onChange={(e) => setRef(e.target.value.toUpperCase())}
            placeholder="e.g. ABC123456789"
            className="h-14 w-full rounded-xl border-2 border-border bg-input px-4 font-mono text-lg focus:outline-none focus:border-primary transition-colors"
          />
        </div>

        {/* Warning */}
        <div className="rounded-2xl border-2 border-amber-500/30 bg-amber-500/8 p-4 flex items-start gap-3">
          <div className="h-10 w-10 rounded-xl bg-amber-500/20 flex items-center justify-center shrink-0">
            <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold text-foreground">Credits added after confirmation</p>
            <p className="text-sm text-muted-foreground mt-0.5 leading-snug">
              Your balance will update once we confirm receipt of your {channelLabel} payment.
              This usually only takes a few minutes.
            </p>
          </div>
        </div>
      </main>

      {/* Sticky footer */}
      <div className="shrink-0 safe-x safe-bottom px-4 pt-3 pb-4 border-t border-border flex flex-col gap-2">
        <Button
          onClick={() => onConfirm(ref.trim() || undefined)}
          size="lg"
          className="w-full h-16 text-lg font-bold rounded-2xl"
        >
          <CheckCircle2 className="h-5 w-5 mr-2" />
          I have sent the payment
        </Button>
        <Button
          variant="secondary"
          onClick={onCancel}
          className="w-full h-12 text-base font-semibold rounded-xl border-2 border-border text-muted-foreground"
        >
          <X className="h-4 w-4 mr-1.5" />
          Cancel this reload
        </Button>
      </div>
    </div>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatRelTime(ts: number): string {
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60_000);
  const hrs = Math.floor(diff / 3_600_000);
  const days = Math.floor(diff / 86_400_000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  if (hrs < 24) return `${hrs}h ago`;
  return `${days}d ago`;
}
