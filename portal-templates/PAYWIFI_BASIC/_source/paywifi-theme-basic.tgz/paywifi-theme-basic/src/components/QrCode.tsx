import { useEffect, useState } from "react";

/**
 * Inline SVG QR code renderer.
 *
 * The captive portal often runs offline (the user has not yet redeemed
 * their voucher), so we cannot fetch from an external QR API. This wraps
 * `qrcode`'s SVG output and renders it client-side.
 *
 * The `qrcode` package is loaded with a dynamic import + `@vite-ignore`
 * so that the dev server doesn't crash if the dep hasn't been installed
 * yet. When the package is missing, the component renders a small text
 * fallback instead of breaking the page.
 *
 * `size` controls the rendered pixel size of the square. `value` is the
 * payload (typically a voucher code, but can be a URL / arbitrary string).
 */
type Props = {
  value: string;
  size?: number;
  className?: string;
  /** Margin in QR modules around the symbol. Smaller = denser layout. */
  margin?: number;
  /** Accessible label — falls back to a generic description. */
  ariaLabel?: string;
};

type RenderState =
  | { kind: "loading" }
  | { kind: "ready"; svg: string }
  | { kind: "missing-dep" };

export function QrCode({
  value,
  size = 144,
  className,
  margin = 1,
  ariaLabel,
}: Props) {
  const [state, setState] = useState<RenderState>({ kind: "loading" });

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        // @vite-ignore so Vite doesn't fail dev-time module resolution if the
        // package isn't installed yet. Once `bun install` has been run, this
        // resolves normally and the catch branch is never hit.
        const mod = await import(/* @vite-ignore */ "qrcode");
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const QRCode = ((mod as any).default ?? mod) as typeof mod;
        const output = await (QRCode as {
          toString: (
            text: string,
            opts: {
              type: "svg";
              errorCorrectionLevel: "L" | "M" | "Q" | "H";
              margin: number;
              color: { dark: string; light: string };
            },
          ) => Promise<string>;
        }).toString(value, {
          type: "svg",
          errorCorrectionLevel: "M",
          margin,
          color: { dark: "#000000", light: "#ffffff" },
        });
        if (!cancelled) setState({ kind: "ready", svg: output });
      } catch {
        if (!cancelled) setState({ kind: "missing-dep" });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [value, margin]);

  if (state.kind === "missing-dep") {
    return (
      <div
        role="img"
        aria-label={ariaLabel ?? `QR code for ${value}`}
        className={className}
        style={{
          width: size,
          height: size,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#f5f5f5",
          color: "#666",
          fontSize: 11,
          textAlign: "center",
          padding: 8,
          borderRadius: 8,
          lineHeight: 1.3,
        }}
      >
        Run <code>bun install</code> to enable QR rendering
      </div>
    );
  }

  return (
    <div
      role="img"
      aria-label={ariaLabel ?? `QR code for ${value}`}
      className={className}
      style={{ width: size, height: size, lineHeight: 0 }}
      // The SVG is generated locally from a known input — safe to inject.
      dangerouslySetInnerHTML={{
        __html: state.kind === "ready" ? state.svg : "",
      }}
    />
  );
}
