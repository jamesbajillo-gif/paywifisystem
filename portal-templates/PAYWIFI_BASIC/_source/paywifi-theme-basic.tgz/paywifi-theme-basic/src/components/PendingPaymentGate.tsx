/**
 * PendingPaymentGate
 *
 * Full-screen portal-style page shown when a customer has an unpaid
 * pending payment. Matches the captive portal wizard layout:
 *   - Sticky header  (brand + title)
 *   - Scrollable body (payment details)
 *   - Sticky footer  (large action buttons)
 *
 * NOT dismissible — customer must Resume or Cancel.
 */
import { useEffect, useState, type ReactNode } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
  findAnyPendingPayment,
  clearPendingDigitalPayment,
  voidVoucher,
  getPlan,
  type AnyPendingPayment,
  type PaymentMethod,
  type PlanId,
} from "@/lib/portal-api";
import { useBrand } from "@/lib/brand";
import { Button } from "@/components/ui/button";
import { QrCode } from "@/components/QrCode";
import { formatPHP } from "@/lib/utils";
import { getStore } from "@/lib/stores";
import {
  Clock,
  CheckCircle2,
  X,
  AlertTriangle,
  Banknote,
  Smartphone,
  Zap,
  MapPin,
  MessageSquare,
} from "lucide-react";

interface Props {
  venue: string;
  children: ReactNode;
}

export function PendingPaymentGate({ venue, children }: Props) {
  const [pending, setPending] = useState<AnyPendingPayment | undefined>(undefined);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    const check = () => {
      void findAnyPendingPayment(venue).then((p) => {
        setPending(p ?? undefined);
        setChecked(true);
      });
    };
    check();
    const onStorage = (e: StorageEvent) => {
      if (e.key === "paywifi:vouchers:v2" || e.key === "paywifi:pending-digital:v1") {
        check();
      }
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, [venue]);

  // Don't flash children before the check completes
  if (!checked) return null;

  // No pending — render page normally
  if (!pending) return <>{children}</>;

  return <PendingScreen pending={pending} venue={venue} onClear={() => setPending(undefined)} />;
}

// ─── Full-screen pending screen ───────────────────────────────────────────
function PendingScreen({
  pending,
  onClear,
}: {
  pending: AnyPendingPayment;
  venue: string;
  onClear: () => void;
}) {
  const navigate = useNavigate();
  const brand = useBrand();

  const isCash = pending.kind === "cash";
  const planId = isCash ? pending.voucher.planId : (pending.record.planId as PlanId);
  const issuedAt = isCash ? pending.voucher.issuedAt : pending.record.issuedAt;
  const expiresAt = isCash ? (pending.voucher.expiresAt ?? 0) : pending.record.expiresAt;
  const existingPlan = getPlan(planId);
  const minsAgo = Math.max(1, Math.round((Date.now() - issuedAt) / 60000));
  const expiresInMins = Math.max(0, Math.round((expiresAt - Date.now()) / 60000));
  const methodLabel = isCash ? "Cash at counter" : pending.record.method.toUpperCase();

  // Cash-specific
  const paymentReference = isCash ? pending.voucher.paymentReference : undefined;
  const cashStore = isCash ? getStore(pending.voucher.storeId) : undefined;
  const cashPhone = isCash ? pending.voucher.phone : undefined;

  const onResume = () => {
    if (isCash) {
      const v = pending.voucher;
      navigate({
        to: "/result",
        search: {
          status: "pending",
          paymentReference: v.paymentReference,
          phone: v.phone,
          planId: v.planId,
          method: "cash",
          price: existingPlan?.price,
          transactionId: v.transactionId,
          storeId: v.storeId,
        },
      });
    } else {
      const r = pending.record;
      navigate({
        to: "/result",
        search: {
          status: "success",
          code: r.code,
          planId: r.planId as PlanId,
          method: r.method as PaymentMethod,
          // transactionId is required so SuccessView can call
          // clearPendingDigitalPayment and lift the gate on mount.
          transactionId: r.transactionId,
        },
      });
    }
  };

  const onCancel = () => {
    if (isCash) {
      if (pending.voucher.paymentReference) voidVoucher(pending.voucher.paymentReference);
    } else {
      clearPendingDigitalPayment(pending.record.transactionId);
    }
    onClear();
  };

  return (
    <div className="min-h-dvh w-full flex flex-col bg-background">
      {/* Sticky header — matches plans.tsx / checkout.tsx */}
      <header className="sticky top-0 z-20 bg-background/95 backdrop-blur border-b border-border safe-top safe-x pb-4">
        <div className="mx-auto w-full max-w-md pt-3">
          <div className="flex items-start justify-between gap-3">
            {/* Non-destructive close — lifts the gate without cancelling
                the payment. Only the explicit "Cancel payment" button in
                the footer actually voids the invoice/QR. */}
            <button
              type="button"
              onClick={onClear}
              aria-label="Close — keeps your payment active"
              className="h-9 w-9 flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground hover:bg-accent transition-colors shrink-0"
            >
              <X className="h-4 w-4" />
            </button>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 mb-0.5">
                <AlertTriangle className="h-3.5 w-3.5 text-amber-500 shrink-0" />
                <p className="text-xs font-bold uppercase tracking-[0.2em] text-amber-600 truncate">
                  {brand.name} · Pending payment
                </p>
              </div>
              <h1 className="text-3xl font-bold tracking-tight leading-tight">
                {isCash ? "Pay at the counter" : "Unpaid payment"}
              </h1>
            </div>
          </div>
        </div>
      </header>

      {/* Scrollable body */}
      <main className="flex-1 overflow-y-auto safe-x pt-4 pb-2 min-h-0">
        <div className="mx-auto w-full max-w-md flex flex-col gap-3">

          {/* Amount hero */}
          {existingPlan && (
            <div className="rounded-2xl border-2 border-primary bg-primary/5 p-4 text-center">
              <p className="text-xs font-bold uppercase tracking-widest text-primary mb-1">Amount due</p>
              <p className="text-5xl font-black text-primary tracking-tight">
                {formatPHP(existingPlan.price)}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">Pay this exact amount in cash at the counter</p>
            </div>
          )}

          {/* Store location */}
          {isCash && cashStore && (
            <div className="rounded-2xl border-2 border-border bg-card p-3 flex items-center gap-3">
              <div className="h-9 w-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                <MapPin className="h-4 w-4 text-primary" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Pay in person at</p>
                <p className="text-base font-bold text-foreground">{cashStore.name}</p>
                <p className="text-sm text-muted-foreground">{cashStore.address}</p>
              </div>
            </div>
          )}

          {/* Payment reference card — QR top, number below (matches result.tsx) */}
          {isCash && paymentReference && (
            <div className="rounded-2xl border-2 border-primary/30 bg-primary/5 p-4 text-center min-w-0 overflow-hidden">
              <p className="text-xs uppercase tracking-wider text-primary font-semibold">
                Payment reference
              </p>
              <div className="mt-2 flex justify-center">
                <div className="rounded-xl bg-white p-2 border-2 border-border">
                  <QrCode value={paymentReference} size={128} ariaLabel={`Payment reference ${paymentReference}`} />
                </div>
              </div>
              <p className="mt-2 font-mono font-bold text-lg break-all tracking-wider">
                {paymentReference}
              </p>
              {expiresInMins > 0 && (
                <p className={`text-xs font-semibold mt-1 ${expiresInMins < 3 ? "text-destructive" : "text-muted-foreground"}`}>
                  <Clock className="inline h-3 w-3 mr-1" />
                  Expires in {expiresInMins}m
                </p>
              )}
            </div>
          )}

          {/* Digital / non-cash: plan + method card */}
          {!isCash && (
            <div className="rounded-2xl border-2 border-border bg-card p-4">
              <div className="flex items-start gap-3">
                <div className="h-10 w-10 rounded-xl bg-secondary flex items-center justify-center shrink-0">
                  <Smartphone className="h-5 w-5 text-foreground" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-base font-bold truncate">{existingPlan?.name ?? planId}</p>
                  <p className="text-sm text-muted-foreground mt-0.5">{methodLabel}</p>
                  {existingPlan?.duration && (
                    <div className="mt-1.5 inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-semibold">
                      <Zap className="h-3 w-3" />
                      {existingPlan.duration}
                      {existingPlan.speed ? ` · ${existingPlan.speed}` : ""}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Plan badge for cash (shown below reference card) */}
          {isCash && existingPlan && (
            <div className="flex items-center gap-3 px-4 py-3 rounded-2xl border-2 border-border bg-card">
              <div className="h-9 w-9 rounded-xl bg-secondary flex items-center justify-center shrink-0">
                <Banknote className="h-4 w-4 text-foreground" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-bold truncate">{existingPlan.name}</p>
                <div className="flex items-center gap-1 mt-0.5">
                  <Zap className="h-3 w-3 text-primary" />
                  <p className="text-xs text-muted-foreground">
                    {existingPlan.duration}
                    {existingPlan.speed ? ` · ${existingPlan.speed}` : ""}
                  </p>
                </div>
              </div>
              <p className="text-sm text-muted-foreground shrink-0">
                Started <span className="font-semibold text-foreground">{minsAgo}m ago</span>
              </p>
            </div>
          )}

          {/* SMS receipt row (cash only, read-only) */}
          {isCash && cashPhone && (
            <div className="flex items-center gap-3 px-4 py-3 rounded-2xl border-2 border-border bg-card">
              <MessageSquare className="h-4 w-4 text-muted-foreground shrink-0" />
              <p className="text-sm text-muted-foreground min-w-0 flex-1 truncate">
                SMS to <span className="text-foreground font-bold">{cashPhone}</span>
              </p>
            </div>
          )}

          {/* Timing row (digital only) */}
          {!isCash && (
            <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-secondary/50 border border-border">
              <Clock className="h-4 w-4 text-muted-foreground shrink-0" />
              <p className="text-sm text-muted-foreground">
                Started <span className="font-semibold text-foreground">{minsAgo}m ago</span>
                {expiresInMins > 0 && (
                  <> · expires in <span className="font-semibold text-amber-600">{expiresInMins}m</span></>
                )}
              </p>
            </div>
          )}

          {/* Context message */}
          <p className="text-sm text-muted-foreground leading-snug">
            {isCash
              ? "Show the reference number above to the cashier and pay the exact amount. Once you have paid, tap below to receive your voucher."
              : "You have an ongoing payment. Once you have paid, tap below to receive your voucher."}
          </p>

        </div>
      </main>

      {/* Sticky footer — matches plans.tsx / checkout.tsx */}
      <footer className="sticky bottom-0 z-20 bg-background/95 backdrop-blur border-t border-border safe-bottom safe-x pt-3 pb-4">
        <div className="mx-auto w-full max-w-md flex flex-col gap-2">
          <Button
            onClick={onResume}
            size="lg"
            className="w-full h-16 text-lg font-bold rounded-2xl"
          >
            {isCash
              ? <><CheckCircle2 className="h-5 w-5 mr-2" /> I&apos;ve already paid</>
              : <><CheckCircle2 className="h-5 w-5 mr-2" /> I&apos;ve already paid</>
            }
          </Button>
          <Button
            onClick={onCancel}
            variant="secondary"
            className="w-full h-14 text-base font-semibold rounded-2xl border-2 border-border text-muted-foreground"
          >
            <X className="h-4 w-4 mr-1.5" />
            {isCash ? "Cancel this payment" : "Cancel this payment"}
          </Button>
        </div>
      </footer>
    </div>
  );
}
