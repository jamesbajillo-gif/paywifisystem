import { Megaphone } from "lucide-react";

/**
 * Ads widget — placeholder ad slot for the captive-portal home screen.
 * Adopts the same card language as plan tiles: rounded-2xl, border-2, big tap target.
 * Replace the `onInquire` handler with a real mailto/route when going live.
 */
export function AdsWidget({ onInquire }: { onInquire?: () => void }) {
  const handleClick = () => {
    if (onInquire) return onInquire();
    // TODO(live): swap for real inquiry flow (mailto, /contact route, or API).
    window.location.href = "mailto:ads@example.com?subject=Ad%20slot%20inquiry";
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      aria-label="Your ads here — submit to inquire"
      className="w-full text-left rounded-2xl border-2 border-dashed border-border bg-card/60 hover:border-primary hover:bg-card active:scale-[0.99] transition-all p-5 flex items-center gap-4 min-w-0"
    >
      <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
        <Megaphone className="h-6 w-6 text-primary" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-lg font-bold truncate">Your Ads Here</p>
        <p className="text-sm text-muted-foreground mt-0.5 truncate">Submit to inquire</p>
      </div>
    </button>
  );
}
