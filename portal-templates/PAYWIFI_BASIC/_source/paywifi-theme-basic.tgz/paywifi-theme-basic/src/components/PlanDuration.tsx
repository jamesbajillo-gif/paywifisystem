import { useEffect, useState } from "react";
import { Clock } from "lucide-react";
import type { Plan } from "@/lib/portal-api";

type Props = {
  plan: Plan;
  /**
   * When the voucher was redeemed (ms since epoch). If provided, the
   * component renders a live countdown of the remaining window. If
   * omitted, it shows the static plan duration ("1 day of WiFi").
   */
  redeemedAt?: number;
  className?: string;
};

/**
 * Plan-duration badge. Two modes:
 *   - Pre-redemption: "1 Day of WiFi" — anticipated duration before the
 *     user clicks Start browsing.
 *   - Post-redemption: live ticking countdown ("23h 47m left") based on
 *     `redeemedAt + durationMinutes`. Updates every second.
 *
 * For long durations (≥ 1 hour remaining) we show coarse `Hh Mm` so the
 * label doesn't visually thrash; under an hour switches to `Mm Ss`.
 */
export function PlanDuration({ plan, redeemedAt, className }: Props) {
  const [now, setNow] = useState<number>(() => Date.now());

  useEffect(() => {
    if (!redeemedAt) return;
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, [redeemedAt]);

  const display = redeemedAt
    ? formatRemaining(redeemedAt, plan.durationMinutes, now)
    : `${plan.name} · ${plan.duration} of WiFi`;

  return (
    <div
      className={`inline-flex items-center gap-2 px-3 h-9 rounded-full bg-primary/10 text-primary text-sm font-bold ${className ?? ""}`}
    >
      <Clock className="h-4 w-4" />
      <span>{display}</span>
    </div>
  );
}

function formatRemaining(
  redeemedAt: number,
  durationMinutes: number,
  now: number,
): string {
  const expiresAt = redeemedAt + durationMinutes * 60 * 1000;
  const remainingMs = Math.max(0, expiresAt - now);
  if (remainingMs <= 0) return "Time's up";

  const totalSec = Math.floor(remainingMs / 1000);
  const hours = Math.floor(totalSec / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;

  if (hours >= 1) {
    return `${hours}h ${mins}m left`;
  }
  return `${mins}m ${secs}s left`;
}
