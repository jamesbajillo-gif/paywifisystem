import { Wifi, PhilippinePeso, Ticket, TrendingUp } from "lucide-react";
import type { ReactNode } from "react";
import { formatPHP } from "@/lib/utils";

type Props = {
  activeSessions: number;
  todayRevenue: number;
  todayVouchersIssued: number;
  conversionRatePercent: number; // 0..100
};

export function StatsBar({
  activeSessions,
  todayRevenue,
  todayVouchersIssued,
  conversionRatePercent,
}: Props) {
  return (
    <section
      aria-label="Today's stats"
      className="grid grid-cols-2 sm:grid-cols-4 gap-3"
    >
      <StatCard
        icon={<Wifi className="h-5 w-5" />}
        label="Active sessions"
        value={String(activeSessions)}
        tone="primary"
      />
      <StatCard
        icon={<PhilippinePeso className="h-5 w-5" />}
        label="Today's revenue"
        value={formatPHP(todayRevenue)}
        tone="success"
      />
      <StatCard
        icon={<Ticket className="h-5 w-5" />}
        label="Vouchers today"
        value={String(todayVouchersIssued)}
        tone="default"
      />
      <StatCard
        icon={<TrendingUp className="h-5 w-5" />}
        label="Conversion"
        value={`${conversionRatePercent.toFixed(1)}%`}
        tone="default"
      />
    </section>
  );
}

function StatCard({
  icon,
  label,
  value,
  tone,
}: {
  icon: ReactNode;
  label: string;
  value: string;
  tone: "primary" | "success" | "default";
}) {
  const iconBgClass =
    tone === "primary"
      ? "bg-primary/10 text-primary"
      : tone === "success"
        ? "bg-success/15 text-success"
        : "bg-secondary text-foreground";

  return (
    <div className="rounded-2xl border-2 border-border bg-card p-4 min-w-0">
      <div className="flex items-center gap-2 mb-3">
        <div
          className={`h-9 w-9 rounded-xl flex items-center justify-center shrink-0 ${iconBgClass}`}
        >
          {icon}
        </div>
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground truncate leading-tight">
          {label}
        </p>
      </div>
      <p className="text-3xl font-bold tracking-tight truncate">{value}</p>
    </div>
  );
}
