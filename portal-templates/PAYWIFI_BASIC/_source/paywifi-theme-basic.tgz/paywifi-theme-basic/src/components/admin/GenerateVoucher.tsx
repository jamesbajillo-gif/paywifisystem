import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { QrCode } from "@/components/QrCode";
import {
  Check,
  Copy,
  Loader2,
  Link2,
  Ticket,
  AlertCircle,
  ClipboardPaste,
  MessageSquare,
} from "lucide-react";
import {
  getPlans,
  issueVoucher,
  confirmAndIssueVoucherForReference,
  findByPaymentReference,
  sendSmsReceipt,
  formatVoucherCode,
  getPlan,
  type PlanId,
  type Plan,
} from "@/lib/portal-api";
import { trackEvent } from "@/lib/analytics";
import type { StoredVoucher } from "@/lib/mock-store";
import { formatPHP } from "@/lib/utils";

type Props = {
  /** Called after a voucher is successfully issued or confirmed. */
  onIssued: () => void;
  /**
   * Controlled reference value. When supplied, the parent owns the
   * input state — useful for /operator where clicking a pending row
   * needs to pre-fill the form. When omitted, the component manages
   * its own internal state (backward-compat for /admin's standalone use).
   */
  referenceValue?: string;
  onReferenceChange?: (value: string) => void;
};

/**
 * Cashier voucher-generation panel.
 *
 * Two modes, gated behind the required "Payment Received" checkbox:
 *
 *  • **Linked confirmation** — cashier enters the customer's payment
 *    reference. If it matches a pending CASH-* voucher, the matched
 *    card shows the customer's plan + amount + phone. On Generate,
 *    `confirmAndIssueVoucherForReference` sets `confirmedAt` + writes
 *    a freshly-generated voucher code into the record, the captive portal
 *    screen in the customer's tab auto-flips to success via the
 *    `storage` event listener, and SMS fires if a phone was provided.
 *
 *  • **Standalone manual** — no reference entered. Cashier picks a
 *    plan and `issueVoucher` mints a fresh ADMIN- tagged voucher.
 *    Used for walk-ins paying cash without going through the portal first.
 *
 * The "Payment Received" checkbox prevents both accidental issuance and
 * the most common cashier mistake (releasing a voucher before money is
 * in hand).
 */
export function GenerateVoucher({
  onIssued,
  referenceValue,
  onReferenceChange,
}: Props) {
  // Controlled / uncontrolled toggle: prop wins if supplied.
  const [internalRef, setInternalRef] = useState("");
  const isControlled = referenceValue !== undefined;
  const reference = isControlled ? referenceValue : internalRef;
  const setReference = (next: string) => {
    if (onReferenceChange) onReferenceChange(next);
    if (!isControlled) setInternalRef(next);
  };
  const [refError, setRefError] = useState<string | null>(null);
  const [creditError, setCreditError] = useState<string | null>(null);
  const [matched, setMatched] = useState<StoredVoucher | undefined>(undefined);

  const [planId, setPlanId] = useState<PlanId>("day");
  const [paymentReceived, setPaymentReceived] = useState(false);
  const [issuing, setIssuing] = useState(false);

  const [issued, setIssued] = useState<{ code: string; mode: "linked" | "manual"; phone?: string } | null>(null);
  const [copied, setCopied] = useState(false);

  const linkedMode = !!matched;

  const [plans, setPlans] = useState<Plan[]>([]);
  useEffect(() => {
    getPlans().then(setPlans);
  }, []);

  // ─── Payment-reference lookup ──────────────────────────────────────
  // Lookup is keyed on `paymentReference` — NOT on the voucher `code`.
  // The two are separate fields per the two-code architecture: the
  // payment reference is the cashier-desk ID, and the voucher code is
  // generated separately at confirmation time.
  useEffect(() => {
    const trimmed = reference.trim().toUpperCase();
    if (!trimmed) {
      setRefError(null);
      setMatched(undefined);
      return;
    }
    const v = findByPaymentReference(trimmed);
    if (!v) {
      setRefError("Payment reference not found.");
      setMatched(undefined);
      return;
    }
    if (v.voidedAt) {
      setRefError("This payment reference was cancelled by the customer.");
      setMatched(undefined);
      return;
    }
    if (v.confirmedAt) {
      setRefError("This payment reference was already confirmed.");
      setMatched(undefined);
      return;
    }
    if (v.redeemedAt) {
      setRefError("This voucher was already redeemed.");
      setMatched(undefined);
      return;
    }
    if (v.expiresAt && v.expiresAt <= Date.now()) {
      setRefError("This payment reference has expired.");
      setMatched(undefined);
      return;
    }
    // All good — link.
    setRefError(null);
    setMatched(v);
    setPlanId(v.planId);
  }, [reference]);

  // Reference can be pasted from a customer's screenshot.
  const onPaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setReference(formatVoucherCode(text));
    } catch {
      /* permission denied — let the user type instead */
    }
  };

  const matchedPlan = useMemo(
    () => (matched ? getPlan(matched.planId) : undefined),
    [matched],
  );

  // Generate is enabled when payment is acknowledged AND either no
  // reference is being looked up, or the reference resolved cleanly.
  const refIsEmpty = reference.trim().length === 0;
  const canGenerate = paymentReceived && (refIsEmpty || linkedMode) && !issuing;

  // ─── Submit ────────────────────────────────────────────────────────
  const onGenerate = async () => {
    if (!canGenerate) return;
    setIssuing(true);

    // Mock counter-side processing latency.
    await new Promise((r) => setTimeout(r, 600));

    try {
      if (linkedMode && matched && matched.paymentReference) {
        // Issue the voucher code (a *separate* string from the payment
        // reference) and write it into the record alongside confirmedAt.
        const issueResult = await confirmAndIssueVoucherForReference(matched.paymentReference);
        if (!issueResult.ok) {
          // Race: state changed between lookup and submit (e.g. customer
          // hit "Confirm payment" in-portal at the same moment).
          setRefError("Could not confirm — state changed. Refresh and try again.");
          setMatched(undefined);
          return;
        }
        const voucherCode = issueResult.code;
        const planPrice = matchedPlan?.price ?? 0;
        // Funnel beat — money is in hand.
        trackEvent("payment_success", {
          planId: matched.planId,
          method: "cash",
          price: planPrice,
          transactionId: matched.transactionId ?? "",
        });
        // SMS uses the newly-issued voucher code, NOT the payment
        // reference — the customer's redemption credential is the
        // voucher code, never the reference.
        if (matched.phone) {
          void sendSmsReceipt({
            phone: matched.phone,
            code: voucherCode,
            planId: matched.planId,
          });
        }
        setIssued({ code: voucherCode, mode: "linked", phone: matched.phone });
        // Reset form for the next customer.
        setReference("");
        setMatched(undefined);
        setPaymentReceived(false);
        onIssued();
      } else {
        // Standalone manual issuance — no portal session to link.
        const result = await issueVoucher(planId);
        if (!result.ok) {
          setCreditError(
            `Insufficient credits — balance ${result.balance} cr, need ${result.required} cr. Please reload credits in the Credits tab.`
          );
          return;
        }
        setCreditError(null);
        setIssued({ code: result.code, mode: "manual" });
        setPaymentReceived(false);
        setReference("");
        onIssued();
      }
    } finally {
      setIssuing(false);
    }
  };

  const onCopy = () => {
    if (!issued) return;
    navigator.clipboard.writeText(issued.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <section
      aria-label="Generate voucher"
      className="rounded-2xl border-2 border-border bg-card p-4"
    >
      <div className="flex items-center gap-2">
        <Ticket className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-bold">Generate voucher</h2>
      </div>
      <p className="text-sm text-muted-foreground mt-1">
        Confirm a customer's cash payment, or issue a manual voucher for a counter walk-in.
      </p>

      {/* ─── Payment-reference lookup ────────────────────────────────── */}
      <div className="mt-4 flex flex-col gap-1.5">
        <label htmlFor="cashier-reference" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Payment reference number (optional)
        </label>
        <div className="relative">
          <Input
            id="cashier-reference"
            value={reference}
            onChange={(e) => setReference(formatVoucherCode(e.target.value))}
            placeholder="XXXX-XXXX-XXXX"
            maxLength={14}
            inputMode="text"
            autoCapitalize="characters"
            autoCorrect="off"
            spellCheck={false}
            className="h-12 font-mono text-base bg-input border-2 border-border rounded-xl pr-12"
          />
          <button
            type="button"
            onClick={onPaste}
            aria-label="Paste reference from clipboard"
            className="absolute right-1.5 top-1/2 -translate-y-1/2 h-9 w-9 rounded-lg bg-card border-2 border-border hover:border-primary flex items-center justify-center transition-colors"
          >
            <ClipboardPaste className="h-4 w-4" />
          </button>
        </div>

        {/* Inline feedback below the input. */}
        {refError && (
          <div className="mt-1 flex items-center gap-1.5 text-destructive">
            <AlertCircle className="h-3.5 w-3.5 shrink-0" />
            <p className="text-xs font-semibold">{refError}</p>
          </div>
        )}
        {!reference.trim() && !refError && (
          <p className="text-xs text-muted-foreground">
            Leave blank to issue a manual voucher.
          </p>
        )}
      </div>

      {/* ─── Matched-reference card ──────────────────────────────────── */}
      {linkedMode && matched && (
        <div className="mt-3 rounded-xl border-2 border-success/40 bg-success/5 p-3 min-w-0">
          <div className="flex items-start gap-2">
            <Link2 className="h-4 w-4 text-success shrink-0 mt-0.5" />
            <div className="min-w-0 flex-1">
              <p className="text-xs uppercase tracking-wider font-bold text-success">
                Linked pending payment
              </p>
              <p className="text-sm font-bold mt-1 truncate">
                {matchedPlan?.name ?? matched.planId}
                {typeof matchedPlan?.price === "number" && (
                  <> · <span className="text-success">${matchedPlan.price.toFixed(2)}</span></>
                )}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5 truncate">
                Reference {matched.paymentReference} · issued {formatRelative(matched.issuedAt)}
                {matched.phone && <> · SMS to {matched.phone}</>}
                {matched.venue && matched.venue !== "default" && <> · {matched.venue}</>}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ─── Plan picker (locked when linked) ────────────────────────── */}
      <div className="mt-3">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
          Plan {linkedMode && <span className="text-success">(from reference)</span>}
        </p>
        <div className="grid grid-cols-3 gap-2">
          {plans.map((p) => {
            const active = planId === p.id;
            const tileDisabled = linkedMode && matched?.planId !== p.id;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => !tileDisabled && setPlanId(p.id)}
                disabled={tileDisabled}
                aria-disabled={tileDisabled}
                className={`rounded-xl border-2 p-3 text-left min-w-0 transition-all ${
                  tileDisabled
                    ? "opacity-30 border-border bg-card cursor-not-allowed"
                    : active
                      ? "border-primary bg-primary/5"
                      : "border-border bg-card hover:border-primary/40"
                }`}
              >
                <p className="text-sm font-bold truncate">{p.name}</p>
                <p className="text-xs text-muted-foreground mt-0.5 truncate">${p.price}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* ─── Payment-received checkbox ───────────────────────────────── */}
      <label className="mt-4 flex items-start gap-3 cursor-pointer select-none">
        <span
          className={`mt-0.5 h-6 w-6 rounded-md border-2 flex items-center justify-center shrink-0 transition-colors ${
            paymentReceived
              ? "bg-primary border-primary text-primary-foreground"
              : "border-border bg-card"
          }`}
          aria-hidden="true"
        >
          {paymentReceived && <Check className="h-4 w-4" strokeWidth={3} />}
        </span>
        <span className="flex-1 min-w-0">
          <input
            type="checkbox"
            checked={paymentReceived}
            onChange={(e) => setPaymentReceived(e.target.checked)}
            className="sr-only"
            aria-label="Payment received"
          />
          <p className="text-sm font-bold">Payment received</p>
          <p className="text-xs text-muted-foreground mt-0.5">
            Required. Confirm you have the customer's payment in hand before issuing the voucher.
          </p>
        </span>
      </label>

      <Button
        onClick={onGenerate}
        disabled={!canGenerate}
        className="w-full h-12 mt-4 rounded-xl font-bold disabled:opacity-50"
      >
        {issuing ? (
          <>
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            {linkedMode ? "Confirming payment…" : "Generating…"}
          </>
        ) : linkedMode ? (
          "Confirm payment & generate voucher"
        ) : (
          "Generate manual voucher"
        )}
      </Button>

      {/* ─── Issued voucher card ─────────────────────────────────────── */}
      {creditError && (
        <div className="mt-3 rounded-xl border-2 border-destructive/30 bg-destructive/5 px-4 py-3 flex items-start gap-2">
          <AlertCircle className="h-4 w-4 text-destructive shrink-0 mt-0.5" />
          <p className="text-sm text-destructive font-semibold leading-snug">{creditError}</p>
        </div>
      )}

      {issued && (
        <div className="mt-4 rounded-xl border-2 border-success/40 bg-success/5 p-3 text-center">
          <p className="text-xs uppercase tracking-wider font-semibold text-success">
            {issued.mode === "linked" ? "Payment confirmed · voucher issued" : "Voucher issued"}
          </p>
          {issued.mode === "linked" && (
            <p className="text-xs text-muted-foreground mt-1 px-2">
              This is the voucher code — different from the payment reference.
              Give it to the customer (or the SMS will).
            </p>
          )}
          <div className="mt-2 flex justify-center">
            <div className="rounded-lg bg-white p-2 border-2 border-border">
              <QrCode value={issued.code} size={112} ariaLabel={`Voucher ${issued.code}`} />
            </div>
          </div>
          <p className="mt-2 font-mono font-bold text-lg break-all tracking-wider">
            {issued.code}
          </p>
          <button
            onClick={onCopy}
            className="mt-2 inline-flex items-center gap-2 h-10 px-3 rounded-lg text-sm font-semibold bg-card border-2 border-border hover:border-primary transition"
          >
            {copied ? <Check className="h-4 w-4 text-success" /> : <Copy className="h-4 w-4" />}
            {copied ? "Copied!" : "Copy code"}
          </button>
          {issued.phone && (
            <div className="mt-2 inline-flex items-center gap-2 h-8 px-3 rounded-full bg-primary/10 text-primary text-xs font-semibold">
              <MessageSquare className="h-3.5 w-3.5" />
              SMS sent to {issued.phone}
            </div>
          )}
        </div>
      )}
    </section>
  );
}

/** Compact relative-time formatter — matches VoucherTable's. */
function formatRelative(ts: number): string {
  const diffMs = Date.now() - ts;
  const min = Math.round(diffMs / 60000);
  if (min < 1) return "just now";
  if (min < 60) return `${min}m ago`;
  const hr = Math.round(min / 60);
  if (hr < 24) return `${hr}h ago`;
  return new Date(ts).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
  });
}
