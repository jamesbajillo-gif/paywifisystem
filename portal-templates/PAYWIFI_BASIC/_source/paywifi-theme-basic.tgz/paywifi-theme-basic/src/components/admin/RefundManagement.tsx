import { useState, useEffect, useCallback } from "react";
import {
  RotateCcw, CheckCircle2, XCircle, Clock, ChevronDown, ChevronUp, AlertTriangle, Shield,
} from "lucide-react";
import {
  getRefunds, approveRefund, rejectRefund, getRefundConfig, setRefundAutoApprove,
  type RefundRequest,
} from "@/lib/portal-api";
import { getPlan } from "@/lib/portal-api";
import { formatPHP } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export function RefundManagement() {
  const [refunds, setRefunds]       = useState<RefundRequest[]>([]);
  const [autoApprove, setAutoApproveState] = useState(true);
  const [filter, setFilter]         = useState<"all" | "pending" | "approved" | "rejected">("pending");

  const refresh = useCallback(() => {
    void getRefunds().then(setRefunds);
    setAutoApproveState(getRefundConfig().autoApprove);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const onToggleAutoApprove = () => {
    setRefundAutoApprove(!autoApprove);
    refresh();
  };

  const onApprove = (id: string) => { void approveRefund(id).then(() => refresh()); };
  const onReject  = (id: string) => { void rejectRefund(id).then(() => refresh()); };

  const visible = refunds.filter((r) =>
    filter === "all" ? true : r.status === filter,
  );

  const pendingCount = refunds.filter((r) => r.status === "pending").length;

  return (
    <div className="flex flex-col gap-4">

      {/* Auto-approve toggle */}
      <div className="rounded-2xl border-2 border-border bg-card p-4 flex items-start gap-3">
        <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <Shield className="h-5 w-5 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold">Auto-approve refunds</p>
          <p className="text-xs text-muted-foreground mt-0.5 leading-snug">
            When enabled, refund requests are approved immediately without admin review.
          </p>
        </div>
        <button
          onClick={onToggleAutoApprove}
          aria-pressed={autoApprove}
          className={`relative h-7 w-12 rounded-full transition-colors shrink-0 mt-1 ${
            autoApprove ? "bg-primary" : "bg-secondary border-2 border-border"
          }`}
        >
          <span
            className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-transform ${
              autoApprove ? "translate-x-6" : "translate-x-1"
            }`}
          />
        </button>
      </div>

      {/* Filter tabs */}
      <div
        role="tablist"
        aria-label="Refund filter"
        className="flex gap-1 p-1 rounded-xl bg-secondary/50"
      >
        {(["pending", "approved", "rejected", "all"] as const).map((f) => (
          <button
            key={f}
            role="tab"
            type="button"
            aria-selected={filter === f}
            onClick={() => setFilter(f)}
            className={`flex-1 h-9 rounded-lg font-semibold text-xs transition-colors flex items-center justify-center gap-1 ${
              filter === f
                ? "bg-card text-foreground shadow-sm border border-border"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
            {f === "pending" && pendingCount > 0 && (
              <span className={`min-w-[1.25rem] h-4 px-1 rounded-full text-xs font-bold flex items-center justify-center ${
                filter === "pending" ? "bg-primary text-primary-foreground" : "bg-foreground/10"
              }`}>
                {pendingCount}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Refund list */}
      {visible.length === 0 ? (
        <div className="rounded-2xl border-2 border-border bg-card p-8 text-center">
          <p className="text-sm text-muted-foreground">No {filter === "all" ? "" : filter} refund requests.</p>
        </div>
      ) : (
        <div className="rounded-2xl border-2 border-border bg-card overflow-hidden">
          <ul className="divide-y divide-border">
            {visible.map((r) => (
              <RefundRow
                key={r.id}
                refund={r}
                onApprove={onApprove}
                onReject={onReject}
              />
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

// ─── RefundRow ────────────────────────────────────────────────────────────────

function RefundRow({
  refund, onApprove, onReject,
}: {
  refund: RefundRequest;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const plan = getPlan(refund.planId as Parameters<typeof getPlan>[0]);

  return (
    <li className="px-4 py-3 min-w-0">
      <div className="flex items-center gap-3 min-w-0">
        <div className="shrink-0">
          {refund.status === "approved"
            ? <CheckCircle2 className="h-4 w-4 text-success" />
            : refund.status === "rejected"
              ? <XCircle className="h-4 w-4 text-destructive" />
              : <Clock className="h-4 w-4 text-amber-500" />}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline justify-between gap-2">
            <p className="text-sm font-bold truncate font-mono">{refund.voucherCode}</p>
            <p className="text-xs text-muted-foreground shrink-0">{formatRelTime(refund.createdAt)}</p>
          </div>
          <p className="text-xs text-muted-foreground truncate mt-0.5">
            {plan?.name ?? refund.planId}
            {" · "}
            <span className="font-semibold text-foreground">{formatPHP(refund.saleAmount)}</span>
            {" · "}
            {refund.reason}
          </p>
        </div>
        <button
          onClick={() => setExpanded((e) => !e)}
          className="h-7 w-7 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent transition-colors shrink-0"
        >
          {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </button>
      </div>

      {expanded && (
        <div className="mt-3 pl-7 flex flex-col gap-2">
          {refund.notes && (
            <p className="text-xs text-muted-foreground bg-secondary/50 rounded-lg px-3 py-2 leading-relaxed">
              {refund.notes}
            </p>
          )}
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span>Status: <span className={`font-bold ${
              refund.status === "approved" ? "text-success" :
              refund.status === "rejected" ? "text-destructive" : "text-amber-600"
            }`}>{refund.status}</span></span>
            {refund.resolvedBy && <span>· resolved by {refund.resolvedBy}</span>}
          </div>
          {refund.status === "pending" && (
            <div className="flex gap-2 mt-1">
              <button
                onClick={() => onApprove(refund.id)}
                className="h-8 px-3 rounded-xl text-xs font-bold bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 transition-colors"
              >
                Approve
              </button>
              <button
                onClick={() => onReject(refund.id)}
                className="h-8 px-3 rounded-xl text-xs font-bold bg-destructive/10 text-destructive border border-destructive/20 hover:bg-destructive/20 transition-colors"
              >
                Reject
              </button>
            </div>
          )}
        </div>
      )}
    </li>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatRelTime(ts: number): string {
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60_000);
  const hrs  = Math.floor(diff / 3_600_000);
  const days = Math.floor(diff / 86_400_000);
  if (mins < 1)  return "just now";
  if (mins < 60) return `${mins}m ago`;
  if (hrs  < 24) return `${hrs}h ago`;
  return `${days}d ago`;
}
