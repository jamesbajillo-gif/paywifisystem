import { useEffect, useState } from "react";
import { ShieldAlert, Lock, Clock, TrendingDown } from "lucide-react";
import {
  getRecentFailedAttempts,
  getAttemptCountSince,
  getLockedOutCombos,
  getPlans,
  MAX_PAYMENT_ATTEMPTS,
  type Plan,
} from "@/lib/portal-api";

type Props = {
  refreshKey: number;
};

export function PaymentAttemptsCard({ refreshKey }: Props) {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [stats, setStats] = useState<{
    lastHour: number;
    last24h: number;
    perPlanLastHour: Array<{ planId: string; planName: string; count: number }>;
    locked: Array<{ venue: string; planId: string; remainingMs: number }>;
  } | null>(null);

  useEffect(() => {
    getPlans().then(setPlans);
  }, []);

  useEffect(() => {
    const recompute = () => {
      const now = Date.now();
      const sinceHour = now - 60 * 60 * 1000;
      setStats({
        lastHour: getRecentFailedAttempts(sinceHour),
        last24h: getRecentFailedAttempts(now - 24 * 60 * 60 * 1000),
        perPlanLastHour: plans.map((p) => ({
          planId: p.id,
          planName: p.name,
          count: getAttemptCountSince(p.id, sinceHour),
        })),
        locked: getLockedOutCombos(),
      });
    };
    recompute();
    const id = setInterval(recompute, 5000);
    return () => clearInterval(id);
  }, [refreshKey, plans]);

  const hasLockouts = stats && stats.locked.length > 0;

  return (
    <section
      aria-label="Payment-attempt audit"
      className={`rounded-2xl border-2 bg-card p-4 min-w-0 ${
        hasLockouts ? "border-destructive/40" : "border-border"
      }`}
    >
      {/* Header */}
      <div className="flex items-center gap-3 mb-1">
        <div className={`h-10 w-10 rounded-2xl flex items-center justify-center shrink-0 ${
          hasLockouts ? "bg-destructive/10" : "bg-primary/10"
        }`}>
          <ShieldAlert className={`h-5 w-5 ${hasLockouts ? "text-destructive" : "text-primary"}`} />
        </div>
        <div className="min-w-0">
          <h2 className="text-lg font-bold leading-tight">Payment attempts</h2>
          <p className="text-xs text-muted-foreground">
            3-strike guard · ≥{MAX_PAYMENT_ATTEMPTS} fails triggers a cooldown
          </p>
        </div>
      </div>

      {!stats ? (
        <p className="text-sm text-muted-foreground text-center py-8">Loading…</p>
      ) : (
        <div className="flex flex-col gap-3 mt-3">

          {/* Failed attempt counts */}
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-2xl border-2 border-border bg-background/40 p-4">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Last hour</p>
              </div>
              <p className="text-3xl font-bold tabular-nums">{stats.lastHour}</p>
              <p className="text-xs text-muted-foreground mt-0.5">failed attempts</p>
            </div>
            <div className="rounded-2xl border-2 border-border bg-background/40 p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingDown className="h-4 w-4 text-muted-foreground" />
                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">24 hours</p>
              </div>
              <p className="text-3xl font-bold tabular-nums">{stats.last24h}</p>
              <p className="text-xs text-muted-foreground mt-0.5">failed attempts</p>
            </div>
          </div>

          {/* Per-plan breakdown */}
          <div className="rounded-2xl border-2 border-border bg-card overflow-hidden">
            <div className="px-4 py-3 border-b border-border">
              <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">By plan · last hour</p>
            </div>
            <ul className="divide-y divide-border">
              {stats.perPlanLastHour.map((row) => (
                <li key={row.planId} className="flex items-center justify-between gap-3 px-4 py-3 min-w-0">
                  <p className="text-sm font-semibold truncate">{row.planName}</p>
                  <span className={`text-sm font-mono font-bold shrink-0 tabular-nums px-2.5 py-0.5 rounded-lg ${
                    row.count >= MAX_PAYMENT_ATTEMPTS
                      ? "bg-destructive/10 text-destructive"
                      : row.count > 0
                        ? "bg-amber-500/10 text-amber-600 dark:text-amber-400"
                        : "text-muted-foreground"
                  }`}>
                    {row.count}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Active lockouts */}
          <div className="rounded-2xl border-2 border-border bg-card overflow-hidden">
            <div className="px-4 py-3 border-b border-border flex items-center justify-between">
              <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Active lockouts</p>
              {stats.locked.length > 0 && (
                <span className="text-xs font-bold text-destructive bg-destructive/10 px-2 py-0.5 rounded-full">
                  {stats.locked.length} active
                </span>
              )}
            </div>
            {stats.locked.length === 0 ? (
              <p className="px-4 py-4 text-sm text-muted-foreground">No active lockouts.</p>
            ) : (
              <ul className="divide-y divide-border">
                {stats.locked.map((entry) => (
                  <li
                    key={`${entry.venue}:${entry.planId}`}
                    className="flex items-center gap-3 px-4 py-3 min-w-0 bg-destructive/5"
                  >
                    <Lock className="h-4 w-4 text-destructive shrink-0" />
                    <p className="text-sm font-mono truncate flex-1">
                      {entry.venue} · {entry.planId}
                    </p>
                    <p className="text-sm font-mono font-bold text-destructive shrink-0 tabular-nums">
                      {formatRemaining(entry.remainingMs)}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </div>

        </div>
      )}
    </section>
  );
}

function formatRemaining(ms: number): string {
  const m = Math.floor(ms / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  return `${m}:${String(s).padStart(2, "0")}`;
}
