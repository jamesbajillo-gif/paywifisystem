/**
 * PaymentSettings — admin tab panel for the Xendit payment module.
 *
 * One active channel at a time (radio selection, not checkboxes).
 * Selecting a channel deselects any previously active one.
 */

import { useEffect, useState, useCallback } from "react";
import {
  CreditCard, CheckCircle2, XCircle, Loader2, Eye, EyeOff,
  RefreshCw, AlertTriangle, Webhook, Zap, Wifi, FlaskConical,
  Radio,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  XENDIT_CHANNELS,
  type XenditChannel,
} from "@/lib/xendit-client";
import {
  getXenditConfigServer,
  saveXenditConfigServer,
  pingXenditKeyServer,
  resetXenditConfigServer,
} from "@/lib/api/payment.functions";
import { getSystemId } from "@/lib/supabase";

// ─── Types ────────────────────────────────────────────────────────────────

type RemoteConfig = Awaited<ReturnType<typeof getXenditConfigServer>>;
type PingStatus = "idle" | "loading" | "ok" | "fail";

// Group channels for display
const CHANNEL_GROUPS: { label: string; channels: XenditChannel[] }[] = [
  { label: "E-Wallets (Philippines)", channels: ["GCASH", "PAYMAYA"] },
  { label: "E-Wallets (Indonesia)",   channels: ["SHOPEEPAY", "OVO", "DANA", "LINKAJA"] },
  { label: "QR Payments",             channels: ["QRPH", "QRIS"] },
  { label: "Online Banking",          channels: ["BPI", "BDO", "RCBC", "UNIONBANK"] },
];

// ─── Component ────────────────────────────────────────────────────────────

export function PaymentSettings() {
  const [remote, setRemote] = useState<RemoteConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState<string | null>(null);

  // Local editable state (mirrors remote after load)
  const [enabled, setEnabled] = useState(false);
  const [activeChannel, setActiveChannel] = useState<XenditChannel | null>(null);
  const [newApiKey, setNewApiKey] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [pingStatus, setPingStatus] = useState<PingStatus>("idle");
  const [resetConfirm, setResetConfirm] = useState(false);

  // ── Load config ──────────────────────────────────────────────────────
  const loadConfig = useCallback(async () => {
    setLoading(true);
    try {
      const cfg = await getXenditConfigServer({ data: { system_id: getSystemId() } });
      setRemote(cfg);
      setEnabled(cfg.enabled);
      setActiveChannel((cfg.activeChannel as XenditChannel | null) ?? null);
    } catch {
      // Client-side fallback (pure localStorage)
      if (typeof window !== "undefined") {
        try {
          const raw = window.localStorage.getItem("paywifi:xendit-config");
          if (raw) {
            const parsed = JSON.parse(raw) as Record<string, unknown>;
            const ch = (parsed.activeChannel as XenditChannel | null) ?? null;
            setEnabled(typeof parsed.enabled === "boolean" ? parsed.enabled : false);
            setActiveChannel(ch);
            setRemote({
              enabled: typeof parsed.enabled === "boolean" ? parsed.enabled : false,
              activeChannel: ch,
              maskedApiKey: typeof parsed.apiKey === "string" && parsed.apiKey
                ? `${"•".repeat(Math.max(0, (parsed.apiKey as string).length - 6))}${(parsed.apiKey as string).slice(-6)}`
                : "",
              webhookToken: typeof parsed.webhookToken === "string" ? parsed.webhookToken : "",
              hasEnvApiKey: false,
              hasEnvWebhookToken: false,
            });
          } else {
            setRemote({
              enabled: false, activeChannel: null,
              maskedApiKey: "", webhookToken: "",
              hasEnvApiKey: false, hasEnvWebhookToken: false,
            });
          }
        } catch { /* ignore */ }
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadConfig(); }, [loadConfig]);

  // ── Save ─────────────────────────────────────────────────────────────
  const handleSave = async () => {
    setSaving(true);
    setSaveMsg(null);
    try {
      await saveXenditConfigServer({
        data: {
          system_id: getSystemId(),
          enabled,
          activeChannel: activeChannel ?? null,
          newApiKey: newApiKey.trim() || undefined,
        },
      });
      setNewApiKey("");
      setSaveMsg("Saved");
      await loadConfig();
    } catch {
      // Client-side fallback
      if (typeof window !== "undefined") {
        try {
          const existing = JSON.parse(window.localStorage.getItem("paywifi:xendit-config") ?? "{}") as Record<string, unknown>;
          window.localStorage.setItem("paywifi:xendit-config", JSON.stringify({
            ...existing,
            enabled,
            activeChannel,
            ...(newApiKey.trim() ? { apiKey: newApiKey.trim() } : {}),
          }));
          setNewApiKey("");
          setSaveMsg("Saved");
          await loadConfig();
        } catch { setSaveMsg("Save failed"); }
      }
    } finally {
      setSaving(false);
      setTimeout(() => setSaveMsg(null), 3000);
    }
  };

  // ── Ping ─────────────────────────────────────────────────────────────
  const handlePing = async () => {
    const keyToTest = newApiKey.trim() || remote?.maskedApiKey || "";
    if (!keyToTest || keyToTest.includes("•")) {
      setSaveMsg("Enter the full API key first, then ping.");
      setTimeout(() => setSaveMsg(null), 3000);
      return;
    }
    setPingStatus("loading");
    try {
      const { valid } = await pingXenditKeyServer({ data: { apiKey: keyToTest } });
      setPingStatus(valid ? "ok" : "fail");
    } catch {
      try {
        const token = btoa(`${keyToTest}:`);
        const resp = await fetch("https://api.xendit.co/balance", {
          headers: { Authorization: `Basic ${token}` },
        });
        setPingStatus(resp.status !== 401 && resp.status !== 403 ? "ok" : "fail");
      } catch {
        setPingStatus("fail");
      }
    }
    setTimeout(() => setPingStatus("idle"), 5000);
  };

  // ── Reset ─────────────────────────────────────────────────────────────
  const handleReset = async () => {
    try {
      await resetXenditConfigServer({ data: { system_id: getSystemId() } });
    } catch {
      if (typeof window !== "undefined") {
        window.localStorage.removeItem("paywifi:xendit-config");
      }
    }
    setResetConfirm(false);
    await loadConfig();
  };

  // ── Channel select (radio) ────────────────────────────────────────────
  const selectChannel = (id: XenditChannel) => {
    // Toggle off if already selected; otherwise select exclusively
    setActiveChannel((prev) => (prev === id ? null : id));
  };

  // Test mode detection
  const isTestMode =
    newApiKey.startsWith("xnd_development_") ||
    (remote?.maskedApiKey
      ? !remote.maskedApiKey.startsWith("xnd_production_")
      : true);

  // ── Render ────────────────────────────────────────────────────────────
  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const activeMeta = activeChannel
    ? XENDIT_CHANNELS.find((c) => c.id === activeChannel)
    : null;

  // All channels in the same module as the selected channel
  const activeModuleChannels = activeMeta
    ? XENDIT_CHANNELS.filter((c) => c.type === activeMeta.type)
    : [];

  return (
    <div className="flex flex-col gap-5">

      {/* ── Test / Live mode banner ── */}
      <div className={`rounded-xl border-2 px-4 py-3 flex items-start gap-3 ${
        isTestMode
          ? "border-amber-400/50 bg-amber-50 dark:bg-amber-950/20"
          : "border-green-400/50 bg-green-50 dark:bg-green-950/20"
      }`}>
        <FlaskConical className={`h-5 w-5 shrink-0 mt-0.5 ${isTestMode ? "text-amber-600" : "text-green-600"}`} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <p className={`text-xs font-bold uppercase tracking-wider ${isTestMode ? "text-amber-700" : "text-green-700"}`}>
              {isTestMode ? "Test Configuration" : "Live Configuration"}
            </p>
            <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
              isTestMode
                ? "bg-amber-200 text-amber-800"
                : "bg-green-200 text-green-800"
            }`}>
              {isTestMode ? "Sandbox" : "Production"}
            </span>
          </div>
          <p className={`text-sm mt-0.5 leading-snug ${isTestMode ? "text-amber-800/80" : "text-green-800/80"}`}>
            {isTestMode
              ? "Using Xendit test (development) credentials. Payments are simulated — no real money is charged. Switch to a production API key to go live."
              : "Using Xendit production credentials. Real payments will be processed."}
          </p>
        </div>
      </div>

      {/* ── Section 1: Master toggle ── */}
      <div className="rounded-2xl border-2 border-border bg-card p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3 min-w-0">
            <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <CreditCard className="h-5 w-5 text-primary" />
            </div>
            <div className="min-w-0">
              <p className="text-base font-bold">Xendit Payments</p>
              <p className="text-sm text-muted-foreground mt-0.5 leading-snug">
                Enable Xendit to offer a digital payment module at checkout.
                Selecting a channel activates all channels in its group. Cash is always shown.
              </p>
            </div>
          </div>
          {/* Toggle switch */}
          <button
            type="button"
            role="switch"
            aria-checked={enabled}
            onClick={() => setEnabled((v) => !v)}
            className={`shrink-0 relative inline-flex h-7 w-12 items-center rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary ${
              enabled ? "bg-primary" : "bg-muted"
            }`}
          >
            <span className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
              enabled ? "translate-x-6" : "translate-x-1"
            }`} />
          </button>
        </div>

        {/* Status badge */}
        <div className={`mt-4 flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-semibold ${
          enabled && activeMeta
            ? "bg-green-50 text-green-700 border border-green-200"
            : enabled
              ? "bg-amber-50 text-amber-700 border border-amber-200"
              : "bg-muted text-muted-foreground border border-border"
        }`}>
          {enabled && activeMeta ? (
            <><Wifi className="h-4 w-4" /> Active — {activeMeta.type.replace(/_/g, " ").toLowerCase()} module ({activeModuleChannels.length} channel{activeModuleChannels.length !== 1 ? "s" : ""})</>
          ) : enabled ? (
            <><Radio className="h-4 w-4" /> Enabled — no module selected yet</>
          ) : (
            <><XCircle className="h-4 w-4" /> Disabled — cash-only checkout</>
          )}
        </div>
      </div>

      {/* ── Section 2: API Key ── */}
      <div className="rounded-2xl border-2 border-border bg-card p-5">
        <div className="flex items-center gap-2 mb-3">
          <Zap className="h-4 w-4 text-primary" />
          <p className="text-sm font-bold">API Key</p>
          {remote?.hasEnvApiKey && (
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-primary/10 text-primary">
              from .env
            </span>
          )}
        </div>

        {remote?.maskedApiKey && (
          <div className="mb-3 flex items-center gap-2 px-3 py-2 rounded-xl bg-secondary border border-border font-mono text-sm">
            <span className="flex-1 truncate text-muted-foreground">
              {remote.maskedApiKey}
            </span>
            <button
              type="button"
              onClick={() => setShowKey((v) => !v)}
              className="text-muted-foreground hover:text-foreground"
              aria-label={showKey ? "Hide key" : "Show key suffix"}
            >
              {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        )}

        <div className="flex gap-2">
          <Input
            type="password"
            value={newApiKey}
            onChange={(e) => setNewApiKey(e.target.value)}
            placeholder={remote?.maskedApiKey ? "Enter new key to update…" : "xnd_development_…"}
            className="flex-1 h-11 font-mono text-sm bg-input border-2 border-border rounded-xl"
          />
          <Button
            type="button"
            variant="secondary"
            onClick={handlePing}
            disabled={pingStatus === "loading"}
            className="h-11 px-4 rounded-xl border-2 border-border text-sm font-semibold shrink-0"
          >
            {pingStatus === "loading" ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : pingStatus === "ok" ? (
              <CheckCircle2 className="h-4 w-4 text-green-600" />
            ) : pingStatus === "fail" ? (
              <XCircle className="h-4 w-4 text-destructive" />
            ) : (
              "Test"
            )}
          </Button>
        </div>

        <p className="text-xs text-muted-foreground mt-2">
          <span className="font-semibold text-amber-600">Test keys</span> start with <span className="font-mono">xnd_development_</span> (default).{" "}
          <span className="font-semibold text-green-600">Live keys</span> start with <span className="font-mono">xnd_production_</span>.{" "}
          Get yours at{" "}
          <a href="https://dashboard.xendit.co/settings/developers#api-keys" target="_blank" rel="noopener noreferrer" className="underline">
            dashboard.xendit.co
          </a>.
        </p>
      </div>

      {/* ── Section 3: Webhook Token ── */}
      <div className="rounded-2xl border-2 border-border bg-card p-5">
        <div className="flex items-center gap-2 mb-3">
          <Webhook className="h-4 w-4 text-primary" />
          <p className="text-sm font-bold">Webhook Verification Token</p>
          {remote?.hasEnvWebhookToken && (
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-primary/10 text-primary">
              from .env
            </span>
          )}
        </div>
        <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-secondary border border-border font-mono text-sm">
          <span className="flex-1 truncate text-muted-foreground select-all">
            {remote?.webhookToken
              ? `${"•".repeat(Math.max(0, remote.webhookToken.length - 8))}${remote.webhookToken.slice(-8)}`
              : "Not configured"}
          </span>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          Set in your Xendit dashboard under Webhooks → Verification Token. The server compares{" "}
          <span className="font-mono">x-callback-token</span> against this value.
        </p>
        {/* Webhook URL — what to paste into Xendit's dashboard */}
        <div className="mt-4 pt-4 border-t border-border">
          <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">
            Webhook Callback URL
          </p>
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-secondary border border-border font-mono text-xs">
            <span className="flex-1 truncate select-all">
              {typeof window !== "undefined"
                ? `${window.location.origin}/api/xendit/webhook`
                : "/api/xendit/webhook"}
            </span>
            <button
              type="button"
              onClick={() => {
                if (typeof navigator !== "undefined" && navigator.clipboard) {
                  void navigator.clipboard.writeText(
                    `${window.location.origin}/api/xendit/webhook`,
                  );
                }
              }}
              className="shrink-0 px-2 py-1 rounded-md bg-primary/10 text-primary text-[10px] font-bold uppercase tracking-wider hover:bg-primary/20"
            >
              Copy
            </button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Paste this URL into your Xendit dashboard under Settings → Webhooks → Callback URL.
            Xendit will <code className="font-mono">POST</code> payment status changes here.
          </p>
        </div>
      </div>

      {/* ── Section 4: Channel selection (radio) ── */}
      <div className="rounded-2xl border-2 border-border bg-card overflow-hidden">
        <div className="p-5 border-b border-border">
          <p className="text-sm font-bold">Active Payment Channel</p>
          <p className="text-sm text-muted-foreground mt-0.5">
            Select <span className="font-semibold">one</span> channel to show at customer checkout alongside Cash.
            Only the selected channel will appear. Cash is always available and cannot be removed.
          </p>
        </div>

        {CHANNEL_GROUPS.map((group) => (
          <div key={group.label} className="border-b border-border last:border-0">
            {/* Group header */}
            <div className="px-5 py-2.5 bg-secondary/30">
              <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                {group.label}
              </p>
            </div>
            {/* Channel rows — radio selection */}
            <div className="flex flex-col divide-y divide-border/60">
              {group.channels.map((id) => {
                const meta = XENDIT_CHANNELS.find((c) => c.id === id)!;
                const selected = activeChannel === id;
                return (
                  <button
                    key={id}
                    type="button"
                    role="radio"
                    aria-checked={selected}
                    onClick={() => selectChannel(id)}
                    className={`flex items-center justify-between gap-3 px-5 py-3.5 transition-all text-left w-full ${
                      selected ? "bg-primary/5" : "hover:bg-accent/50"
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      {/* Radio indicator */}
                      <div className={`h-5 w-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-colors ${
                        selected ? "border-primary bg-primary" : "border-muted-foreground/40"
                      }`}>
                        {selected && <div className="h-2 w-2 rounded-full bg-white" />}
                      </div>
                      <div className="min-w-0">
                        <p className={`text-sm font-bold truncate ${selected ? "text-primary" : "text-foreground"}`}>
                          {meta.label}
                        </p>
                        <p className="text-xs text-muted-foreground truncate">
                          {meta.type.replace(/_/g, " ").toLowerCase()} · {meta.countries}
                        </p>
                      </div>
                    </div>
                    {selected && (
                      <span className="shrink-0 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-primary text-primary-foreground">
                        Active
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}

        {/* No selection hint */}
        {!activeChannel && (
          <div className="px-5 py-3 bg-amber-50/50 dark:bg-amber-950/10 border-t border-amber-200/50">
            <p className="text-xs text-amber-700 dark:text-amber-400 font-semibold">
              No channel selected — customers will only see Cash at checkout.
            </p>
          </div>
        )}
      </div>

      {/* ── Save bar ── */}
      <div className="flex items-center gap-3">
        <Button
          onClick={handleSave}
          disabled={saving}
          className="h-12 px-6 rounded-xl text-sm font-bold"
        >
          {saving ? (
            <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Saving…</>
          ) : (
            "Save settings"
          )}
        </Button>
        {saveMsg && (
          <span className={`text-sm font-semibold flex items-center gap-1.5 ${
            saveMsg === "Saved" ? "text-green-600" : "text-destructive"
          }`}>
            {saveMsg === "Saved"
              ? <CheckCircle2 className="h-4 w-4" />
              : <AlertTriangle className="h-4 w-4" />
            }
            {saveMsg}
          </span>
        )}
        <Button
          variant="secondary"
          onClick={loadConfig}
          className="h-12 px-4 rounded-xl text-sm font-semibold border-2 border-border ml-auto"
        >
          <RefreshCw className="h-4 w-4 mr-1.5" />
          Reload
        </Button>
      </div>

      {/* ── Danger zone ── */}
      <div className="mt-2 pt-5 border-t border-border">
        <p className="text-xs font-bold uppercase tracking-[0.15em] text-muted-foreground mb-3">
          Danger zone
        </p>
        <div className="rounded-2xl border-2 border-border bg-card p-4">
          <div className="flex items-start gap-3 mb-3">
            <AlertTriangle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold">Reset Xendit config</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Clears all saved settings. API key and webhook token fall back to <span className="font-mono">.env.local</span>.
              </p>
            </div>
          </div>
          {resetConfirm ? (
            <div className="flex gap-2">
              <Button
                onClick={handleReset}
                variant="secondary"
                className="flex-1 h-11 rounded-xl text-sm font-bold border-2 border-destructive/50 text-destructive hover:bg-destructive/10"
              >
                Yes, reset
              </Button>
              <Button
                variant="secondary"
                onClick={() => setResetConfirm(false)}
                className="flex-1 h-11 rounded-xl text-sm font-semibold border-2 border-border"
              >
                Cancel
              </Button>
            </div>
          ) : (
            <Button
              variant="secondary"
              onClick={() => setResetConfirm(true)}
              className="w-full h-11 rounded-xl text-sm font-semibold border-2 border-border"
            >
              Reset to defaults
            </Button>
          )}
        </div>
      </div>

    </div>
  );
}
