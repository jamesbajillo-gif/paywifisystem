import { BarChart3 } from "lucide-react";
import type { FunnelStats } from "@/lib/analytics";
import { formatPHP } from "@/lib/utils";

type Props = {
  stats: FunnelStats;
};

const BEATS: { key: keyof FunnelStats; label: string }[] = [
  { key: "home_view", label: "Home viewed" },
  { key: "plan_picked", label: "Plan selected" },
  { key: "checkout_submit", label: "Checkout submitted" },
  { key: "payment_success", label: "Payment succeeded" },
  { key: "start_browsing", label: "Started browsing" },
  { key: "voucher_submitted", label: "Voucher submitted" },
  { key: "voucher_validated_valid", label: "Voucher valid" },
  { key: "payment_failed", label: "Payment failed" },
  { key: "voucher_validated_failed", label: "Voucher invalid" },
];

export function FunnelChart({ stats }: Props) {
  const rows = BEATS.map((b) => ({ ...b, count: stats[b.key] as number }));
  const max = rows.reduce((acc, r) => Math.max(acc, r.count), 0);

  return (
    <section
      aria-label="Conversion funnel"
      className="rounded-2xl border-2 border-border bg-card p-4 min-w-0"
    >
      <div className="flex items-center gap-2 mb-1">
        <BarChart3 className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-bold">Conversion funnel</h2>
      </div>
      <div className="flex flex-wrap gap-x-4 gap-y-0.5 mb-4">
        <p className="text-xs text-muted-foreground">
          Home → pay:{" "}
          <span className="font-semibold text-foreground">
            {(stats.conversion_rate_home_to_pay * 100).toFixed(1)}%
          </span>
        </p>
        <p className="text-xs text-muted-foreground">
          Pay → browse:{" "}
          <span className="font-semibold text-foreground">
            {(stats.conversion_rate_pay_to_browse * 100).toFixed(1)}%
          </span>
        </p>
        <p className="text-xs text-muted-foreground">
          Revenue:{" "}
          <span className="font-semibold text-foreground">
            {formatPHP(stats.total_revenue)}
          </span>
        </p>
      </div>

      {max === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-8">
          No events yet. Walk through the flow or seed demo data.
        </p>
      ) : (
        <ul className="flex flex-col gap-2.5">
          {rows.map((r) => {
            const pct = max > 0 ? (r.count / max) * 100 : 0;
            const isFailure =
              r.key === "payment_failed" || r.key === "voucher_validated_failed";
            return (
              <li key={r.key} className="min-w-0">
                <div className="flex items-baseline justify-between gap-3 min-w-0 mb-1">
                  <p className={`text-sm font-medium truncate ${isFailure ? "text-muted-foreground" : ""}`}>
                    {r.label}
                  </p>
                  <p className={`text-sm font-mono font-bold shrink-0 tabular-nums ${isFailure && r.count > 0 ? "text-destructive" : ""}`}>
                    {r.count}
                  </p>
                </div>
                <div className="h-1.5 rounded-full bg-border overflow-hidden">
                  <div
                    className={isFailure ? "h-full bg-destructive/50 rounded-full" : "h-full bg-primary rounded-full"}
                    style={{ width: `${pct}%`, transition: "width 0.4s ease" }}
                  />
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
