import { useState, useCallback } from "react";
import {
  History, CheckCircle2, Clock, Wifi, RotateCcw, X, AlertTriangle, ChevronDown,
} from "lucide-react";
import {
  getPlan, createRefundRequest, REFUND_WINDOW_MS, REFUND_REASONS,
  type RefundReason,
} from "@/lib/portal-api";
import { formatPHP } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import type { StoredVoucher } from "@/lib/mock-store";

type Props = {
  vouchers: StoredVoucher[];
  refundedCodes?: Set<string>;
  limit?: number;
  title?: string;
  emptyMessage?: string;
  onRefund?: () => void;
};

type VoucherStatus = "issued" | "active" | "expired";

function getVoucherStatus(v: StoredVoucher): VoucherStatus {
  if (!v.redeemedAt) return "issued";
  const expiresAt = v.redeemedAt + v.durationMinutes * 60 * 1000;
  return Date.now() < expiresAt ? "active" : "expired";
}

const STATUS_META: Record<VoucherStatus, { label: string; className: string; icon: React.ReactNode }> = {
  issued: {
    label: "Issued",
    className: "bg-secondary text-foreground",
    icon: <Clock className="h-3 w-3" />,
  },
  active: {
    label: "Active",
    className: "bg-success/15 text-success",
    icon: <Wifi className="h-3 w-3" />,
  },
  expired: {
    label: "Expired",
    className: "bg-muted text-muted-foreground",
    icon: <CheckCircle2 className="h-3 w-3" />,
  },
};

export function VoucherTable({
  vouchers,
  refundedCodes = new Set(),
  limit = 20,
  title = "Recent vouchers",
  emptyMessage = "No vouchers yet. Generate one above or seed demo data.",
  onRefund,
}: Props) {
  const [refundTarget, setRefundTarget] = useState<StoredVoucher | null>(null);
  const visible = vouchers.slice(0, limit);

  const handleRefundDone = useCallback(() => {
    setRefundTarget(null);
    onRefund?.();
  }, [onRefund]);

  return (
    <>
      <section
        aria-label={title}
        className="rounded-2xl border-2 border-border bg-card p-4 min-w-0"
      >
        <div className="flex items-center justify-between gap-3 mb-1">
          <div className="flex items-center gap-2 min-w-0">
            <History className="h-5 w-5 text-primary shrink-0" />
            <h2 className="text-lg font-bold truncate">{title}</h2>
          </div>
          <p className="text-xs text-muted-foreground shrink-0 tabular-nums">
            {vouchers.length === 0 ? "—" : `${visible.length} of ${vouchers.length}`}
          </p>
        </div>

        {visible.length === 0 ? (
          <p className="mt-4 text-sm text-muted-foreground text-center py-8">
            {emptyMessage}
          </p>
        ) : (
          <ul className="mt-3 flex flex-col divide-y divide-border -mx-4">
            {visible.map((v) => (
              <VoucherRow
                key={v.code}
                voucher={v}
                isRefunded={refundedCodes.has(v.code)}
                onRequestRefund={onRefund ? () => setRefundTarget(v) : undefined}
              />
            ))}
          </ul>
        )}
      </section>

      {refundTarget && (
        <RefundSheet
          voucher={refundTarget}
          onClose={() => setRefundTarget(null)}
          onDone={handleRefundDone}
        />
      )}
    </>
  );
}

// ─── VoucherRow ───────────────────────────────────────────────────────────────

function VoucherRow({
  voucher,
  isRefunded,
  onRequestRefund,
}: {
  voucher: StoredVoucher;
  isRefunded: boolean;
  onRequestRefund?: () => void;
}) {
  const status = getVoucherStatus(voucher);
  const meta = STATUS_META[status];
  const plan = getPlan(voucher.planId);
  const isAdminIssued = voucher.transactionId?.startsWith("ADMIN-");
  const saleTs = voucher.confirmedAt ?? voucher.issuedAt;
  const withinWindow = Date.now() - saleTs < REFUND_WINDOW_MS;
  const canRefund = !!onRequestRefund && !isRefunded && withinWindow;

  return (
    <li className="px-4 py-2.5 flex items-center gap-3 min-w-0 hover:bg-secondary/30 transition-colors">
      <div className="flex-1 min-w-0">
        <p className={`font-mono font-bold text-sm tracking-wider ${isRefunded ? "line-through opacity-40" : ""}`}>
          {voucher.code}
        </p>
        <p className="text-xs text-muted-foreground mt-0.5 truncate">
          {plan?.name ?? voucher.planId}
          {plan?.price != null && (
            <> · <span className={`font-semibold ${isRefunded ? "line-through opacity-50" : "text-foreground"}`}>{formatPHP(plan.price)}</span></>
          )}
          {" · "}{formatRelative(saleTs)}
          {isAdminIssued && <span className="ml-1 opacity-40">(manual)</span>}
          {isRefunded && <span className="ml-1 font-semibold text-destructive/70"> · refunded</span>}
        </p>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <span className={`inline-flex items-center gap-1 text-xs font-bold uppercase tracking-wide px-2 py-1 rounded-lg ${meta.className}`}>
          {meta.icon}
          {meta.label}
        </span>
        {canRefund && (
          <button
            onClick={onRequestRefund}
            title="Request refund"
            className="h-7 w-7 flex items-center justify-center rounded-lg border border-destructive/30 text-destructive/60 hover:text-destructive hover:bg-destructive/10 transition-colors"
          >
            <RotateCcw className="h-3.5 w-3.5" />
          </button>
        )}
      </div>
    </li>
  );
}

// ─── RefundSheet ──────────────────────────────────────────────────────────────

function RefundSheet({
  voucher,
  onClose,
  onDone,
}: {
  voucher: StoredVoucher;
  onClose: () => void;
  onDone: () => void;
}) {
  const [reason, setReason]     = useState<RefundReason | "">("");
  const [notes, setNotes]       = useState("");
  const [error, setError]       = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone]         = useState(false);
  const [autoApproved, setAutoApproved] = useState(false);

  const plan   = getPlan(voucher.planId);
  const saleTs = voucher.confirmedAt ?? voucher.issuedAt;

  const onSubmit = () => {
    if (!reason) { setError("Please select a reason."); return; }
    setError(null);
    setSubmitting(true);

    void createRefundRequest(
      voucher.code,
      voucher.planId,
      plan?.price ?? 0,
      saleTs,
      reason as RefundReason,
      notes.trim() || undefined,
    ).then((result) => {
      setSubmitting(false);
      if (!result) {
        setError("Refund window has closed (48 hours exceeded). Cannot process this refund.");
        return;
      }
      setAutoApproved(result.status === "approved");
      setDone(true);
    }).catch(() => {
      setSubmitting(false);
      setError("Failed to submit refund request. Please try again.");
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-background">
      {/* Close button */}
      <div className="safe-top safe-x pt-3 flex items-center justify-end shrink-0 px-4">
        <button
          onClick={onClose}
          aria-label="Close"
          className="h-9 w-9 flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {!done ? (
        <>
          {/* Header */}
          <div className="safe-x px-4 pt-2 pb-1 shrink-0">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-destructive mb-1">
              Operator · Refund request
            </p>
            <h1 className="text-3xl font-bold tracking-tight leading-tight">Request refund</h1>
            <p className="mt-1 text-base text-muted-foreground leading-snug">
              Tag this sale for refund. Refunds within 48 hours are auto-approved by default.
            </p>
          </div>

          {/* Body */}
          <main className="flex-1 overflow-y-auto safe-x px-4 py-4 flex flex-col gap-4 min-h-0">
            {/* Voucher summary */}
            <div className="rounded-2xl border-2 border-border bg-secondary/60 p-4 flex items-center justify-between gap-3 shrink-0">
              <div className="min-w-0 flex-1">
                <p className="font-mono font-bold text-sm tracking-widest truncate">{voucher.code}</p>
                <p className="text-sm text-muted-foreground mt-0.5 truncate">
                  {plan?.name ?? voucher.planId}
                </p>
              </div>
              {plan?.price != null && (
                <p className="text-2xl font-black shrink-0">{formatPHP(plan.price)}</p>
              )}
            </div>

            {/* Reason picker */}
            <div className="flex flex-col gap-2">
              <p className="text-sm font-semibold text-muted-foreground px-0.5">
                Reason for refund <span className="text-destructive">*</span>
              </p>
              <div className="relative">
                <select
                  value={reason}
                  onChange={(e) => setReason(e.target.value as RefundReason | "")}
                  className="h-14 w-full rounded-xl border-2 border-border bg-input px-4 text-base appearance-none focus:outline-none focus:border-primary transition-colors pr-10"
                >
                  <option value="">Select a reason…</option>
                  {REFUND_REASONS.map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground pointer-events-none" />
              </div>
            </div>

            {/* Notes */}
            <div className="flex flex-col gap-2">
              <p className="text-sm font-semibold text-muted-foreground px-0.5">
                Additional notes{" "}
                <span className="font-normal text-muted-foreground/60">(optional)</span>
              </p>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Customer requested refund — double-charged"
                rows={3}
                className="w-full rounded-xl border-2 border-border bg-input px-4 py-3 text-base focus:outline-none focus:border-primary transition-colors resize-none"
              />
            </div>

            {/* Warning */}
            <div className="rounded-2xl border-2 border-amber-500/30 bg-amber-500/8 p-4 flex items-start gap-3">
              <div className="h-10 w-10 rounded-xl bg-amber-500/20 flex items-center justify-center shrink-0">
                <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-bold text-foreground">Refunds are forwarded to admin</p>
                <p className="text-sm text-muted-foreground mt-0.5 leading-snug">
                  This sale will be deducted from revenue calculations once approved.
                  Auto-approved if admin settings allow it.
                </p>
              </div>
            </div>

            {error && (
              <p className="text-sm text-destructive font-semibold px-1">{error}</p>
            )}
          </main>

          {/* Footer */}
          <div className="shrink-0 safe-x safe-bottom px-4 pt-3 pb-4 border-t border-border flex flex-col gap-2">
            <Button
              onClick={onSubmit}
              disabled={submitting || !reason}
              size="lg"
              variant="destructive"
              className="w-full h-16 text-lg font-bold rounded-2xl"
            >
              <RotateCcw className="h-5 w-5 mr-2" />
              Submit refund request
            </Button>
            <Button
              variant="secondary"
              onClick={onClose}
              className="w-full h-12 text-base font-semibold rounded-xl border-2 border-border text-muted-foreground"
            >
              <X className="h-4 w-4 mr-1.5" />
              Cancel
            </Button>
          </div>
        </>
      ) : (
        <>
          {/* Success state */}
          <div className="safe-x px-4 pt-2 pb-1 shrink-0">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-primary mb-1">
              Refund submitted
            </p>
            <h1 className="text-3xl font-bold tracking-tight leading-tight">
              {autoApproved ? "Refund approved" : "Awaiting approval"}
            </h1>
            <p className="mt-1 text-base text-muted-foreground leading-snug">
              {autoApproved
                ? "This sale has been removed from revenue calculations."
                : "The refund request has been sent to admin for review."}
            </p>
          </div>

          <main className="flex-1 overflow-y-auto safe-x px-4 py-4 flex flex-col gap-4 min-h-0">
            <div className={`rounded-2xl border-2 p-4 flex items-center gap-3 ${
              autoApproved
                ? "border-primary/30 bg-primary/5"
                : "border-amber-500/30 bg-amber-500/8"
            }`}>
              <CheckCircle2 className={`h-6 w-6 shrink-0 ${autoApproved ? "text-primary" : "text-amber-600"}`} />
              <p className="text-sm font-semibold leading-snug">
                {autoApproved
                  ? `${formatPHP(plan?.price ?? 0)} deducted from your net revenue.`
                  : "Admin will review and approve or reject this request."}
              </p>
            </div>
          </main>

          <div className="shrink-0 safe-x safe-bottom px-4 pt-3 pb-4 border-t border-border">
            <Button
              onClick={onDone}
              size="lg"
              className="w-full h-16 text-lg font-bold rounded-2xl"
            >
              Done
            </Button>
          </div>
        </>
      )}
    </div>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatRelative(ts: number): string {
  const diffMs = Date.now() - ts;
  const min = Math.round(diffMs / 60000);
  if (min < 1) return "just now";
  if (min < 60) return `${min}m ago`;
  const hr = Math.round(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.round(hr / 24);
  return `${day}d ago`;
}
