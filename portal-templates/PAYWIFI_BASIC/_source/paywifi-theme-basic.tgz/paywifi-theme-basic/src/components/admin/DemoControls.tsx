import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Database, RotateCcw, Trash2 } from "lucide-react";
import {
  seedDemoData,
  clearStore,
  clearEvents,
  resetFirstAttemptFlags,
  clearAllAttempts,
} from "@/lib/portal-api";
import { resetCredits, resetRefunds } from "@/lib/portal-api";

type Props = {
  onChange: () => void;
};

/**
 * Demo-only controls — populate the local store with fake vouchers or
 * wipe everything to start over.
 */
export function DemoControls({ onChange }: Props) {
  const [confirming, setConfirming] = useState(false);
  const [confirmingNuke, setConfirmingNuke] = useState(false);

  const onSeed = () => {
    seedDemoData();
    onChange();
  };

  const onReset = () => {
    if (!confirming) {
      setConfirming(true);
      setTimeout(() => setConfirming(false), 3000);
      return;
    }
    clearStore();
    clearEvents();
    resetFirstAttemptFlags();
    clearAllAttempts();
    resetCredits();
    resetRefunds();
    setConfirming(false);
    onChange();
  };

  const onNukeAll = () => {
    if (!confirmingNuke) {
      setConfirmingNuke(true);
      setTimeout(() => setConfirmingNuke(false), 3000);
      return;
    }
    // Wipe every paywifi: key from localStorage
    if (typeof window !== "undefined") {
      const keys = Object.keys(window.localStorage).filter((k) =>
        k.startsWith("paywifi:"),
      );
      keys.forEach((k) => window.localStorage.removeItem(k));
    }
    setConfirmingNuke(false);
    onChange();
  };

  return (
    <section
      aria-label="Demo controls"
      className="rounded-2xl border-2 border-dashed border-border bg-secondary/30 p-4"
    >
      <p className="text-xs uppercase tracking-wider font-bold text-muted-foreground">
        Demo data
      </p>
      <p className="text-sm text-muted-foreground mt-1">
        These controls only exist on the mock build. Seed the store with sample
        vouchers in mixed states, or wipe everything to start fresh.
      </p>
      <div className="mt-3 flex flex-col sm:flex-row gap-2">
        <Button
          onClick={onSeed}
          variant="secondary"
          className="flex-1 h-11 rounded-xl font-semibold border-2 border-border"
        >
          <Database className="h-4 w-4 mr-2" />
          Seed demo vouchers
        </Button>
        <Button
          onClick={onReset}
          variant={confirming ? "destructive" : "secondary"}
          className={`flex-1 h-11 rounded-xl font-semibold ${
            confirming ? "" : "border-2 border-border"
          }`}
        >
          <RotateCcw className="h-4 w-4 mr-2" />
          {confirming ? "Tap again to confirm" : "Reset vouchers"}
        </Button>
      </div>
      <div className="mt-2">
        <Button
          onClick={onNukeAll}
          variant={confirmingNuke ? "destructive" : "secondary"}
          className={`w-full h-11 rounded-xl font-semibold ${
            confirmingNuke ? "" : "border-2 border-destructive/30 text-destructive hover:bg-destructive/10"
          }`}
        >
          <Trash2 className="h-4 w-4 mr-2" />
          {confirmingNuke ? "Tap again — clears ALL session data" : "Clear all session data"}
        </Button>
      </div>
    </section>
  );
}
