import type { ReactNode } from "react";
import { useNavigate } from "@tanstack/react-router";
import { X } from "lucide-react";

interface Props {
  title: string;
  subtitle?: string;
  children: ReactNode;
  showClose?: boolean;
  step?: number;
  totalSteps?: number;
}

export function PortalShell({ title, subtitle, children, showClose }: Props) {
  const navigate = useNavigate();

  return (
    <div className="min-h-dvh w-full flex flex-col bg-background">
      {showClose && (
        <div className="safe-top safe-x pt-3 flex items-center justify-end shrink-0">
          <button
            onClick={() => navigate({ to: "/" })}
            aria-label="Close and return to portal"
            className="h-9 w-9 flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      )}
      <main className="flex-1 flex flex-col safe-x pt-4 pb-2 min-h-0">
        <div className="shrink-0">
          <h1 className="text-3xl font-bold tracking-tight leading-tight">{title}</h1>
          {subtitle && (
            <p className="mt-1 text-base text-muted-foreground leading-snug">{subtitle}</p>
          )}
        </div>
        <div className="flex-1 flex flex-col mt-5 min-h-0">{children}</div>
      </main>
      <div className="safe-bottom" />
    </div>
  );
}
