/**
 * DbStatusContext.tsx — global backend reachability state.
 *
 * Tracks whether the backend is reachable. We do NOT alarm the user during
 * brief blips. The status machine:
 *
 *   checking → reach test → online | offline
 *   online   → re-check every 60s, blip → silent retry, only flips to
 *              "offline" after N consecutive failed checks (~30 s).
 *   offline  → fast retry every 5 s. Flips back to "online" the moment a
 *              check succeeds.
 *
 * Components consume this via useDbStatus() / useDbOnline().
 * The "offline" state is what triggers the friendly banner — we deliberately
 * wait through transient failures so the user never sees a flash of red.
 */

"use client";
import { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { checkDbHealth } from "@/lib/supabase";

export type DbStatus = "checking" | "online" | "offline";

type DbStatusContextValue = {
  status: DbStatus;
  retry: () => void;
};

const DbStatusContext = createContext<DbStatusContextValue>({
  status: "checking",
  retry: () => {},
});

/** Healthy-interval poll cadence. */
const POLL_INTERVAL_ONLINE_MS = 60_000;
/** Re-try cadence while we believe we're offline. */
const POLL_INTERVAL_OFFLINE_MS = 5_000;
/** Number of consecutive failed checks before we surface "offline" to UI. */
const FAILURES_BEFORE_OFFLINE = 6; // 6 × 5 s = ~30 s of silent retry

export function DbStatusProvider({ children }: { children: React.ReactNode }) {
  const [status, setStatus] = useState<DbStatus>("checking");
  // Use a ref so the in-flight failure counter doesn't trigger renders.
  const failureCountRef = useRef(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const scheduleNext = useCallback((nextStatus: DbStatus) => {
    if (timerRef.current) clearTimeout(timerRef.current);
    const delay = nextStatus === "online" ? POLL_INTERVAL_ONLINE_MS : POLL_INTERVAL_OFFLINE_MS;
    timerRef.current = setTimeout(() => { void runCheck(); }, delay);
  }, []);

  const runCheck = useCallback(async () => {
    const ok = await checkDbHealth();
    if (ok) {
      failureCountRef.current = 0;
      setStatus("online");
      scheduleNext("online");
    } else {
      failureCountRef.current += 1;
      // Stay in "checking" until we cross the threshold. Components that
      // need to know we're degraded can still infer from useDbOnline()
      // returning false (since checking !== online).
      if (failureCountRef.current >= FAILURES_BEFORE_OFFLINE) {
        setStatus("offline");
      }
      scheduleNext("offline");
    }
  }, [scheduleNext]);

  // Manual retry — used by the banner button. Resets backoff.
  const retry = useCallback(() => {
    failureCountRef.current = 0;
    setStatus("checking");
    void runCheck();
  }, [runCheck]);

  useEffect(() => {
    void runCheck();
    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <DbStatusContext.Provider value={{ status, retry }}>
      {children}
    </DbStatusContext.Provider>
  );
}

/** Returns the current DB status and a manual retry function. */
export function useDbStatus(): DbStatusContextValue {
  return useContext(DbStatusContext);
}

/** True when the backend is confirmed reachable. */
export function useDbOnline(): boolean {
  const { status } = useDbStatus();
  return status === "online";
}
