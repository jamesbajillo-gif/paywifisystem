import { defineConfig, devices } from "@playwright/test";

/**
 * Captive-portal responsive regression suite.
 * Run with: `bunx playwright test`
 * Install once: `bun add -d @playwright/test && bunx playwright install chromium`
 */
export default defineConfig({
  testDir: "./tests/e2e",
  fullyParallel: true,
  reporter: [["list"]],
  use: {
    baseURL: process.env.PLAYWRIGHT_BASE_URL ?? "http://localhost:3000",
    trace: "retain-on-failure",
  },
  webServer: process.env.PLAYWRIGHT_BASE_URL
    ? undefined
    : {
        command: "bun run dev",
        url: "http://localhost:3000",
        reuseExistingServer: true,
        timeout: 120_000,
      },
  projects: [
    { name: "iphone-se-320", use: { ...devices["iPhone SE"], viewport: { width: 320, height: 568 } } },
    { name: "iphone-375",    use: { ...devices["iPhone 13 mini"], viewport: { width: 375, height: 812 } } },
    { name: "ipad-768",      use: { ...devices["iPad Mini"], viewport: { width: 768, height: 1024 } } },
    { name: "landscape-667", use: { viewport: { width: 667, height: 375 } } },
  ],
});
