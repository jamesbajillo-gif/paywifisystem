# Captive Portal — Page Audit & Wiring Map

A page-by-page breakdown of the current portal: what each screen does, what
actions live on it, where they go, and which mock function in
`src/lib/portal-api.ts` will be swapped when going live.

## Logical user flow

```text
                ┌──────────────────────────┐
                │   /  (index)             │   Enter voucher OR buy a plan
                │   Sticky form + widgets  │
                └────────────┬─────────────┘
                             │
              has voucher?   │   no voucher?
                 ┌───────────┴───────────┐
                 ▼                       ▼
        /validate?code=XXXX        /plans
        ─ validateVoucher()        ─ static PLANS list
                 │                       │
        invalid │ valid                  ▼
          ┌─────┴─────┐            /checkout?plan=hour|day|week
          ▼           ▼            ─ processPayment()
        retry      Start              │
        /plans     browsing           ▼
                   (online)        /result?status=success|failed
                                   ─ redeemVoucher()  (fire-and-forget)
                                      │
                                      ▼
                                   Start browsing
```

## Pages

### 1. `/` — Home (`src/routes/index.tsx`)

**Purpose:** primary entry — voucher input. Optimized for older eyes.

**Layout:** sticky header with voucher form + scrollable widgets below.

| Action | Element | Wired to | Mock fn |
|---|---|---|---|
| Submit voucher | `<form>` → `Connect` button | `navigate('/validate?code=…')` | — |
| Buy a plan | "Buy one" button | `<Link to="/plans">` | — |
| Ads inquiry | `AdsWidget` tile | `mailto:ads@example.com` (placeholder) | `TODO(live)` in `AdsWidget.tsx` |

**Widgets area:** `src/components/widgets/`. Add new widgets to the scroll
section in `index.tsx` — voucher form stays sticky at the top.

### 2. `/plans` — Plan picker (`src/routes/plans.tsx`)

**Purpose:** present 3 tiers (hour / day / week).

| Action | Element | Wired to | Mock fn |
|---|---|---|---|
| Pick plan | Plan card | `navigate('/checkout?plan=…')` | `PLANS` (static) → `getPlans()` |
| Back | "Back" button | `<Link to="/">` | — |

### 3. `/checkout` — Pay (`src/routes/checkout.tsx`)

**Purpose:** select payment method, optional SMS, submit.

| Action | Element | Wired to | Mock fn |
|---|---|---|---|
| Pick method | 4 tiles (GCash/QR PH/Maya/Cash) | local state | — |
| Enter phone | `<Input>` | local state | — |
| Submit payment | `Pay $X` button | `processPayment()` → `/result` | `processPayment` |
| SMS receipt | (server-side after payment) | — | `sendSmsReceipt` |
| Change plan | secondary button | `<Link to="/plans">` | — |

### 4. `/validate` — Voucher check (`src/routes/validate.tsx`)

**Purpose:** verify a voucher entered on `/`.

| State | UI | Action |
|---|---|---|
| `checking` | spinner + big "Verifying your code" | runs `validateVoucher(code)` |
| `valid` | green check + "Connected" + code | "Start browsing" → external |
| `invalid` | red X + reason | "Try another" → `/`, "Buy voucher" → `/plans` |

Mock fn: `validateVoucher` (returns `{ ok, code, remainingMinutes }` or `{ ok:false, status, message }`).

### 5. `/result` — Post-payment (`src/routes/result.tsx`)

**Purpose:** show purchase outcome.

| State | UI | Action |
|---|---|---|
| `success` | green check + "Payment received" + voucher + copy + SMS confirmation | "Start browsing" calls `redeemVoucher` then leaves portal |
| `failed` | red X + "Payment failed" + reason | "Try again" → `/plans` |

Mock fn: `redeemVoucher` (fire-and-forget on Start browsing).

## API contract (currently mocked)

All wiring funnels through `src/lib/portal-api.ts`. To go live, swap each
`TODO(live)`-marked block — no component changes needed.

| Fn | Inputs | Returns | Swap target |
|---|---|---|---|
| `getPlans()` | — | `Plan[]` | DB query |
| `validateVoucher(code)` | `string` | `ValidateVoucherResult` | server fn → `vouchers` |
| `processPayment({planId, method, phone?})` | — | `PaymentResult` | payment provider |
| `sendSmsReceipt({phone, code, planId})` | — | `void` | Twilio / Semaphore |
| `redeemVoucher(code)` | `string` | `void` | mark used + create session |

## Responsive QA checklist

Run through this **for every route** at each breakpoint, in both portrait
and landscape, before shipping:

| Breakpoint | Device proxy | Portrait | Landscape |
|---|---|---|---|
| 320 × 568 | iPhone SE (1st gen) | ✓ | ✓ |
| 375 × 667 | iPhone SE (2/3) | ✓ | ✓ |
| 375 × 812 | iPhone 13 mini | ✓ | ✓ |
| 414 × 896 | iPhone 11 Pro Max | ✓ | ✓ |
| 768 × 1024 | iPad mini | ✓ | ✓ |

**Pass criteria for each cell:**

- [ ] No horizontal scrollbar (body `overflow-x: hidden` already enforced)
- [ ] Voucher code, prices, headings do not wrap onto a 2nd line awkwardly
- [ ] Primary CTA visible above the fold without scrolling
- [ ] All buttons ≥ 44 × 44 px (enforced globally in `src/styles.css`)
- [ ] Inputs ≥ 44 px tall AND ≥ 16 px font-size (prevents iOS zoom on focus)
- [ ] Status text (`text-status`) readable from ~50 cm
- [ ] Safe-area insets respected: nothing under the notch/home indicator
- [ ] In landscape, the form + first CTA still fit in the viewport
- [ ] Sticky voucher form on `/` does not cover the next widget

## Safe-area / notched device support

- `viewport` meta uses `viewport-fit=cover` (in `src/routes/__root.tsx`)
- Utility classes in `src/styles.css`:
  `.safe-top`, `.safe-bottom`, `.safe-left`, `.safe-right`, `.safe-x`, `.safe-y`
- Applied to `PortalShell` (all subpages) and `/` (header + widget area + footer spacer)

## Automated regression — Playwright

See `tests/e2e/portal.spec.ts`. Captures a screenshot of every route at the
three key breakpoints and asserts `document.documentElement.scrollWidth ===
clientWidth` to fail the build on any horizontal overflow regression.

Run locally:

```bash
bun add -d @playwright/test
bunx playwright install chromium
bunx playwright test
```
