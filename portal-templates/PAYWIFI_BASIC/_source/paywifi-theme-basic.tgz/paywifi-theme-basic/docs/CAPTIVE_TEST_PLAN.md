# Captive Portal Manual Test Plan

> Real-device tests for the PayWiFi Xendit/GCash payment flow on iOS and
> Android captive portal assistants. These cannot be automated from the
> CI runner — they require a phone connected to the hotspot.

Each scenario lists the **setup**, the **steps**, the **expected behaviour**,
and the **pass/fail criteria**.

---

## Pre-flight checklist (run once per build)

- [ ] `bun run build` succeeds
- [ ] `bunx tsc --noEmit` shows zero errors
- [ ] `paywifi_basic_xendit_config.webhook_token` matches the value in Xendit dashboard
- [ ] `XENDIT_SECRET_KEY` is set in `.env.local` and pings green via `pingXenditKeyServer`
- [ ] Hotspot serves the captive portal at the expected captive URL
- [ ] `/api/xendit/webhook` is reachable over HTTPS from the public internet
  (test with `curl -X POST https://<domain>/api/xendit/webhook -d '{}'` — should return `{"ok":false,...}` and log `[xendit-webhook] invalid`)

---

## A — iOS happy path (GCash)

### Setup
- Fresh iOS device (Safari, no PayWiFi cookies)
- Captive portal assistant turned ON (default)
- GCash app installed and logged in

### Steps
1. Connect device to PayWiFi SSID
2. Captive assistant opens automatically — pick a plan
3. Tap GCash tile → tap **Pay ₱X.XX**
4. Wait for sheet → tap **Open GCash app**
5. Complete payment in GCash
6. Return to Safari (captive assistant)

### Expected
- Sheet auto-updates to "Payment confirmed" within ~3 s of returning
- Voucher code appears
- Tapping **Start browsing** closes captive assistant
- Browsing the open web works

### Pass criteria
- [ ] Voucher arrives without manual refresh
- [ ] Captive assistant closes cleanly (no stuck "Sign in" UI)
- [ ] Internet works after voucher activation

### Common iOS failure modes
- **Captive assistant traps user:** indicates the success page didn't trigger the `<a href="https://google.com">` link — verify `Start browsing` button uses an external URL with `onClick` handler.
- **Sheet stays in "polling" forever:** check `pollXenditPaymentStatusServer` is reachable from iOS Safari (TLS errors, mixed content).

---

## B — Android happy path (GCash)

### Setup
- Fresh Android device (Chrome captive browser)
- GCash app installed and logged in

### Steps
Same as A, but Android captive browser handles redirect differently.

### Expected
Same as A — sheet auto-updates, voucher appears, **Start browsing** triggers captive exit.

### Pass criteria
- [ ] Voucher arrives without manual refresh
- [ ] Captive browser closes / hands control to system browser
- [ ] Internet works after voucher activation

### Common Android failure modes
- **Chrome captive browser doesn't render the SVG QR code:** rare — fallback is the deep-link button. Verify the QR component still renders without errors in DevTools.
- **Voucher arrives but captive doesn't close:** Android captive uses an HTTP probe to determine connectivity. Verify the gateway clears the captive lock immediately on voucher redeem.

---

## C — Reconnect recovery (refresh mid-payment)

### Setup
- Same as A
- Device with payment sheet open in "polling" state

### Steps
1. Pick a plan, tap GCash → Pay
2. Sheet opens with QR + deep link
3. Pull-to-refresh in Safari/Chrome
4. Observe what happens after reload

### Expected
- Page reloads
- Same payment sheet re-appears in "polling" state
- Same transactionId (visible as Session ID in header)
- Countdown resumes from approximately where it was (within ~5 s of the original expiresAt)
- Within ~3 s the next poll tick discovers the actual Xendit status

### Pass criteria
- [ ] Sheet rehydrates with same Session ID
- [ ] Countdown is monotonically decreasing
- [ ] No duplicate Xendit invoice is created (check Xendit dashboard)

### Edge cases
- Reload AFTER payment completed but BEFORE polling saw SUCCEEDED — webhook should have already issued the voucher; polling rediscovers via `handleXenditPaymentSuccess` and navigates to /result?status=success.
- Reload AFTER 3-minute TTL — sessionStorage is auto-cleared; user lands back at /checkout with no sheet.

---

## D — Webhook-only confirmation (close tab mid-payment)

### Setup
- Same as A

### Steps
1. Pick a plan, tap GCash → Pay
2. Sheet opens
3. **Close Safari/Chrome entirely** (kill the tab)
4. Complete payment in GCash app
5. Reopen Safari and navigate to /plans

### Expected
- Webhook receives SUCCEEDED from Xendit ~10–30 s after payment
- `paywifi_basic_vouchers` table has a row for this transactionId
- `paywifi_basic_pending_digital` row is cleared

### Pass criteria
- [ ] Voucher exists in DB with correct plan + duration
- [ ] No credit deduction from operator balance
- [ ] Re-opening the portal does not show stale pending state

### How to verify
```bash
ssh root@192.168.88.66
docker exec supabase-db psql -U postgres -c \
  "SELECT code, transaction_id, plan_id, issued_at FROM paywifi_basic_vouchers ORDER BY issued_at DESC LIMIT 5;"
```

---

## E — Backend interruption (Supabase blip)

### Setup
- Device with PayWiFi portal open

### Steps
1. Browse /plans normally — confirm UI is fully responsive
2. On the Supabase host: `docker compose stop supabase-rest` (simulates outage)
3. Wait ~10 s — UI should remain responsive, no banner yet (silent retry phase)
4. Wait ~35 s total — orange "Refreshing connection…" banner appears
5. Bring REST back up: `docker compose start supabase-rest`
6. Within ~5 s the banner disappears

### Pass criteria
- [ ] No alarming "server offline" / "database error" wording is ever shown
- [ ] Banner is amber, not red
- [ ] Banner self-clears once the backend returns
- [ ] No payment flow that was already in flight is corrupted

---

## F — Duplicate webhook protection

### Setup
- A completed Xendit payment with a known transaction_id (referenceId)
- Webhook URL + token

### Steps
1. Replay the SUCCEEDED callback with the same body twice:
   ```bash
   curl -X POST https://<domain>/api/xendit/webhook \
     -H "x-callback-token: $WEBHOOK_TOKEN" \
     -H "content-type: application/json" \
     -d '{"event":"payment.succeeded","data":{"id":"...","status":"SUCCEEDED","reference_id":"<known_txn_id>"}}'
   ```
2. Repeat the same `curl` immediately

### Expected
- First call logs `dispatched` with `alreadyIssued=false` (or true if voucher exists from polling)
- Second call logs `duplicate` (in-memory replay window) OR `dispatched` with `alreadyIssued=true`
- Vouchers table still has exactly ONE row for this transactionId

### Pass criteria
- [ ] No second voucher row is created
- [ ] Operator credit balance is unchanged across the two requests

---

## G — Bad webhook token

### Steps
```bash
curl -X POST https://<domain>/api/xendit/webhook \
  -H "x-callback-token: WRONG-TOKEN" \
  -d '{"data":{"reference_id":"<any-known-txn>","status":"SUCCEEDED"}}'
```

### Expected
- Response body: `{"ok":false,"reason":"bad_token"}`
- Server log: `[xendit-webhook] invalid reason=bad_token`
- No voucher is issued
- Returns HTTP 200 (so Xendit doesn't retry-storm)

---

## Recording results

For each pass/fail, capture:
- Device + OS version
- Network conditions (wifi only / cellular fallback)
- Time of test
- Screenshots of any unexpected UI
- Server log excerpts for any failing webhook event

Store under `tests/manual/` with filename `<date>-<scenario>-<device>.md`.
