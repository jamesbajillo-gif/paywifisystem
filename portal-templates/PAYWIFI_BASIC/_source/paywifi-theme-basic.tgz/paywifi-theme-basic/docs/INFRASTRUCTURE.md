# Infrastructure & Server Configuration

> Persistent reference for PayWiFi Basic theme deployment.
> Last updated: 2026-05-29

---

## Supabase Server (Self-Hosted)

**Host:** `db.techpinoy.net`
**Type:** Self-hosted Supabase stack (Docker Compose)
**Server IP:** `192.168.88.66` (LAN)
**Public URL:** `https://db.techpinoy.net`

### SSH Access

```bash
ssh root@192.168.88.66
# password: d3cipl3s
```

### Common Operations

```bash
# Verify all Supabase containers healthy
docker ps --filter name=supabase --format "table {{.Names}}\t{{.Status}}"

# Check all paywifi tables exist
docker exec supabase-db psql -U postgres -c "\dt paywifi_basic_*"

# Restart Supabase stack
cd ~/supabase/docker && docker compose restart

# Tail REST API logs
docker logs supabase-rest -f --tail 50

# Tail DB logs
docker logs supabase-db -f --tail 50
```

### Health Check (from browser/terminal)

```bash
curl -s https://db.techpinoy.net/rest/v1/ \
  -H "apikey: <ANON_KEY>" | python3 -m json.tool | head -5
# 200 OK = online
```

---

## Environment Configuration

### `.env.local` (project root)

```env
NEXT_PUBLIC_SUPABASE_URL=https://db.techpinoy.net
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...anon...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...service_role...
VITE_SUPABASE_URL=https://db.techpinoy.net
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...anon...
```

> Actual keys are stored in `.env.local` at the project root — never commit.

### Client References

- Browser client: `src/lib/supabase.ts` (uses `VITE_SUPABASE_URL` / `VITE_SUPABASE_ANON_KEY`)
- Server client: `src/lib/supabase.server.ts` (uses `SUPABASE_SERVICE_ROLE_KEY`)
- Hardcoded fallback: `https://db.techpinoy.net` in both clients (acceptable for single-venue deployment).

---

## Database Tables (paywifi_basic_*)

Run on the Supabase host to verify schema:

```bash
docker exec supabase-db psql -U postgres -c "\dt paywifi_basic_*"
```

Expected tables include:
- `paywifi_basic_plans`
- `paywifi_basic_xendit_config`
- `paywifi_basic_vouchers`
- `paywifi_basic_transactions`
- (and others — confirm against `supabase/` migrations folder)

---

## Notes

- Single-venue deployment — multi-venue (multi-store) support is a future concern.
- Supabase stack runs via `docker compose` on the host; restart-safe.
- If REST API returns non-200, check `docker logs supabase-rest` first, then `supabase-db`.

---

## Known Limitations (accepted for this deployment)

### T6 — STORES roster is hardcoded
`src/lib/stores.ts` ships a fixed array of physical store locations. There is no
`paywifi_basic_stores` table. This is acceptable for a single-venue setup.

**When to fix:** Multi-venue rollout — create a `paywifi_basic_stores` table
keyed by `venue` and replace `STORES` with a `getStores(venue)` DB call.

### T7 — SMS receipts not wired
`sendSmsReceipt` in `src/lib/portal-api.ts` is a no-op (logs `[SMS NOT IMPLEMENTED]`).
Vouchers are still issued correctly; only the SMS confirmation is missing.

**When to fix:** Integrate a Philippine SMS provider (Semaphore PH recommended).
Replace the body of `sendSmsReceipt` with the provider call.

### T10 — Supabase URL fallback is hardcoded
Both `src/lib/supabase.ts` and `src/lib/supabase.server.ts` fall back to
`https://db.techpinoy.net` when env vars are missing. This is intentional —
this codebase is dedicated to this deployment.

**When to fix:** Only if this codebase is forked for another venue. Remove the
fallback and rely solely on env vars.

---

## Local-first API resolution (Phase 9)

`src/lib/local-api.ts` resolves the best API base URL for each device on first
use. The resolver probes a list of candidates in order and caches the first one
that answers `/health`:

1. `http://127.0.0.1/api` — running on the access point itself
2. `http://10.10.0.1/api` — typical paywifi gateway address
3. WAN fallback (default `https://db.techpinoy.net`) — only used if both local
   candidates fail to respond within `PROBE_TIMEOUT_MS` (800 ms)

The resolver is consumed by `src/lib/supabase.ts` `checkDbHealth()` so the
"backend reachable?" check works even when WAN egress is down.

### Configuration

Override the candidate list and fallback via Vite env vars (in `.env.local`):

```env
VITE_LOCAL_API_CANDIDATES="http://127.0.0.1/api,http://10.10.0.1/api"
VITE_REMOTE_API_FALLBACK="https://db.techpinoy.net"
```

### Required local proxy contract

For the local-first probe to succeed, the captive-portal hotspot must expose a
`GET /health` endpoint at one of the candidate addresses that returns HTTP 2xx.
This is typically a simple Nginx/Caddy reverse proxy in front of the on-box
Supabase Postgrest or a thin health stub.

If the proxy isn't deployed, the resolver transparently falls through to the
WAN URL — nothing breaks, you just lose the local-first speed/reliability
benefit.
