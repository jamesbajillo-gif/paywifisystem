# Gap Analysis — Brief vs. Current Codebase

Comparison of `docs/Instruction.MD` (north-star + roadmap + constraints)
against the code as of 2026-05-28. Sibling to `docs/Structure.MD` (what
exists) and `docs/AUDIT.md` (QA checklist).

## Verdict at a glance

The **frontend shell is roughly milestone-zero done**: all five end-user
routes exist, the design system is in place, safe-area utilities are
wired, and the mock API contract in `src/lib/portal-api.ts` cleanly
isolates every future backend swap. **Nothing on the ranked roadmap (#1
through #8) has shipped.** A handful of small constraint slips — none
structural — are listed below.

## Roadmap status

| # | Milestone | Status | Evidence |
|---|---|---|---|
| 1 | Enable Lovable Cloud + wire `portal-api.ts` to Postgres | **Not started** | Every function in `src/lib/portal-api.ts` returns mock data (`Math.random()` for payment, hard-coded `PLANS` array, `console.info` for SMS). No `@supabase/supabase-js`, pg client, or equivalent in `package.json`. |
| 2 | QR code on the result page | **Done** | `src/components/QrCode.tsx` wraps the `qrcode` library and emits inline SVG. `/result` success state now centres a 144×144 QR above the voucher code, with the text code + Copy button preserved as fallback. |
| 3 | `/admin` dashboard | **UI done; auth gating still TODO(live)** | `src/routes/admin.tsx` + five focused sub-components under `src/components/admin/`. Pulls voucher store, sessions, funnel, and revenue into one screen with refresh-on-action wiring. Staff can issue vouchers via `issueVoucher(planId)` (separate path from `processPayment` so comp issuance doesn't inflate revenue). Per the brief's "no client-side role checks" rule, **the route is open** until milestone #1 wires server-side staff auth — flagged with a visible "Demo mode — no auth" chip and a loud TODO(live) at the top of the file. |
| 4 | Branding pass per venue | **Done (client-side, ready for backend)** | `src/lib/brand.tsx` exposes a `VENUES` record (4 demo venues), `BrandProvider` mounted in `__root.tsx`, and a `useBrand()` hook. Active venue is selected from `?venue=<slug>`, sessionStorage-sticky thereafter. Venue palette overrides `--primary` at the document root, e-payment selection on `/checkout` flows from `brand.activeEpayment`, and the home header surfaces `brand.name`. Logo URL field exists in the type but isn't rendered yet (no upload pipeline). When milestone #1 lands, `VENUES` becomes a DB lookup and slug resolution can move to a venue-scoped subdomain. |
| 5 | Unify step indicator across `/plans`, `/checkout`, `/validate`, `/result` | **Done** | All subpages now use `totalSteps=4`. `/validate` shows step 2 while checking/invalid and step 4 when valid — same pip count as the purchase flow. See the unified-step-indicator section in `docs/Structure.MD`. |
| 6 | Hook real payment provider | **Blocked on #1** | `processPayment()` rolls a 90% dice. |
| 7 | Hook real SMS provider | **Blocked on #1** | `sendSmsReceipt()` logs to console. |
| 8 | Conversion-funnel analytics | **Done (mock, ready for live provider)** | `src/lib/analytics.ts` adds `trackEvent` (eight strongly-typed event names) + `getFunnelStats` + `getAllEvents`. Events stream to localStorage, cap at 500, auto-tagged with active venue. All five routes are wired: `home_view`, `voucher_submitted`, `voucher_validated`, `plan_picked`, `checkout_submit`, `payment_success`, `payment_failed`, `start_browsing`. Re-exported from `portal-api.ts` so the admin dashboard has one import. Live swap: replace `trackEvent` body with provider SDK (PostHog / Mixpanel / GA4) — call sites unchanged. |

## Constraint compliance

| Constraint | Status | Notes |
|---|---|---|
| No client-side role checks (admin must be server-side) | **N/A yet** | Admin route does not exist. To honour the rule when #3 ships, gating should live in a server function, not a `<RequireRole>` wrapper. |
| **No PII in URLs** (phone never logged in query strings beyond result confirmation) | **Compliant per brief exception** | `src/routes/checkout.tsx:44` puts the phone in `search` when navigating to `/result`, so it appears in the result URL only. The brief explicitly allows this with "never logged in query strings *beyond* the result confirmation" — the result confirmation is exempt. If the policy ever tightens to "no PII in any URL," migrate this to router state or sessionStorage. |
| No layout regressions — Playwright asserts no horizontal overflow at 320/375/768 px | **Compliant** | `tests/e2e/portal.spec.ts` + `playwright.config.ts` exist and assert `scrollWidth ≤ clientWidth + 1` for all five routes. `@playwright/test` is now declared in `package.json` devDependencies, so `bun install && bunx playwright test` runs the check without extra steps. |
| No new colours in components | **Compliant** | All routes reference semantic tokens (`bg-primary`, `text-foreground`, `text-success`, `text-destructive`, `border-border`, etc.). No `#hex` or `rgb(` literals in route or component files. |
| Safe-area aware (`env(safe-area-inset-*)` via `.safe-*`) | **Compliant** | Utilities defined in `src/styles.css:103-108`; applied in `PortalShell` (safe-top + safe-x + safe-bottom spacer) and on `/`'s sticky header + scroll area + footer. `viewport-fit=cover` set in `__root.tsx:74`. |
| ≥ 44×44 px touch targets | **Compliant** | Enforced globally in `src/styles.css:72-78` (`button, input, select, textarea { min-height: 44px }`), and most route buttons go further (`h-12` / `h-14` / `h-16`). |
| Primary CTA in bottom third | **Compliant** | `/plans`, `/validate`, `/result`, `/checkout` all place the main CTA via `mt-2`/`shrink-0` at the bottom of `PortalShell`; `/` uses a sticky-footer "No voucher?" CTA + sticky-header "Connect" CTA. |
| One screen at 320×568 portrait + landscape | **Tested by Playwright when it runs** | Same caveat as the overflow rule — depends on @playwright/test being installed. |

## Other observations worth flagging

- **`src/routes/__root.tsx` is still Lovable boilerplate.** Title "Lovable App", description "Lovable Generated Project", `og:title`, `twitter:site` "@Lovable". Will collide with milestone #4 (branding).
- **TODO marker convention now consistent.** All six markers in `portal-api.ts` normalised to `// TODO(live):`, matching `AdsWidget.tsx` — definition-of-done grep catches every backend swap site.
- **`src/lib/api/example.functions.ts` and `src/lib/config.server.ts` exist** but aren't referenced from the routes. Likely TanStack Start scaffolding to either remove or repurpose when milestone #1 introduces real server functions.
- **`PortalShell` step indicator already supports a configurable `totalSteps`.** Milestone #5 is genuinely a 5-minute change at `validate.tsx:43,55,77` once the unified numbering is decided.
- **Voucher format finalised.** `generateVoucherCode()` issues `XXXX-XXXX-XXXX` (12 chars from a 31-char alphabet that excludes 0/O/1/I/L). `formatVoucherCode()` exists for input normalisation. When the real DB lands, only the *generator* needs to move server-side — the format and validation regex are stable.
- **Mock store added** (`src/lib/mock-store.ts`). Issued vouchers persist to localStorage, redemption sticks, expired-by-time-window detection works. Admin dashboard now has a real data source. Delete this file at milestone #1.
- **validateVoucher returns all four statuses** (`valid | invalid | expired | used`). The `/validate` failure screen renders status-specific titles, headlines, and icons (XCircle / Clock / Ban). Synthetic prefixes (`X…` `E…` `U…`) let testers hit every state without a purchase.
- **processPayment failures vary** across five plausible reasons (declined, insufficient funds, expired card/wallet, network timeout, user cancelled) — selected at random on the 10% fail path.
- **Voucher reuse guard.** A redeemed code re-entered on `/` reports `status: "used"` with the actual redemption timestamp ("Already used on 5/28/2026, 9:14 AM") instead of generic "invalid".

## E-payment abuse protection — completed

| Spec criterion | Shipped |
|---|---|
| Detect & prevent duplicate payment attempts | ✅ `useRef`-based in-flight lock + 2 s debounce on the Pay button (`SUBMISSION_DEBOUNCE_MS`). |
| Prevent rapid repeated submissions | ✅ Same idempotency lock above + the existing `processing` disable. |
| Detect suspicious retry behavior | ✅ `payment-guard.ts` counts failed attempts per (venue, planId) within a 10-minute sliding window. |
| Prevent multiple active unpaid transactions | ✅ `/checkout` checks `findPendingForVenue` on mount + at submit. Cash submissions with an existing pending route to resume instead of issuing a new code. |
| Ensure expired payment references cannot be reused | ✅ Cash refs carry `expiresAt = issuedAt + 15min`. `validateVoucher` returns `status: "expired"` past TTL. `purgeExpired()` housekeeps on app boot. |
| Detect failed transactions | ✅ (pre-existing) |
| Clear failed-payment messaging | ✅ (pre-existing — 5 varied messages) |
| Allow safe retry | ✅ Try again button + clean retry path |
| Failed attempts don't create duplicate records | ✅ (pre-existing — voucher persisted only on success) |
| Detect abandoned / expired payment sessions | ✅ `purgeExpired()` on boot drops past-TTL pendings; lockout's 10-minute window plus 5-minute cooldown bound the session. |
| Display "Multiple payment attempts detected. Please try again later." | ✅ Literal spec copy in `LockoutBanner` (in `checkout.tsx`). |
| Auto-invalidated timeout sessions | ✅ Past-TTL pendings dropped from `findPendingForVenue` + `validateVoucher`. |
| Prevent stuck pending blocking future payments | ✅ Cancel button on resume banner voids; TTL eventually drops abandoned ones. |
| Max 3 attempts | ✅ `MAX_ATTEMPTS = 3` in `payment-guard.ts`. |
| Cooldown after exceeding | ✅ 5-minute lockout (`LOCKOUT_DURATION_MS`) with live `M:SS` countdown banner. |
| Bypass audit — refresh | ✅ Stopped (localStorage survives) |
| Bypass audit — multiple tabs | ✅ Stopped (localStorage shared across same-origin tabs) |
| Bypass audit — incognito mode | ❌ Not stoppable client-side; needs identity (milestone #1) |
| Bypass audit — device switching | ❌ Not stoppable client-side; needs identity (milestone #1) |
| Bypass audit — API replay | n/a — no real API yet; needs server-side idempotency keys at milestone #1 |
| Cash exclusion from limits | ✅ `processPayment` skips first-fail + dice for `method: "cash"`. `/checkout` lockout-check skips for cash. Cash never calls `recordFailedAttempt`. Locked digital tile auto-flips selection to cash. |
| Voucher pending verification (cash can't be redeemed pre-counter) | ✅ Cash refs persist with no `confirmedAt`. `validateVoucher` returns `status: "invalid"` with message "Voucher pending verification." until `confirmVoucher(code)` runs (via the Confirm-payment button on `/result?status=pending`). |
| Confirm-payment button copy + flow | ✅ Spec's literal quote ("I have already made the payment and have my code ready to proceed with voucher submission.") shown above the **Confirm payment** button. Click validates the voucher (not voided / not expired / not redeemed), shows a 600 ms "Verifying…" loading state, sets `confirmedAt`, navigates to success. Error states surface inline if the reference fails validation. |
| Randomized voucher errors | ✅ `VOUCHER_ERROR_MESSAGES` in `portal-api.ts` defines plausible-phrasing pools per status (invalid / expired / used) including the spec list ("Voucher not found", "Voucher inactive", "Voucher locked", "Voucher pending verification", "Voucher already redeemed", "Voucher expired", etc.). First-fail simulation randomizes both status and message so testers see varied UIs. |
| `getAttemptCountSince(planId, sinceMs)` admin helper | ✅ Added to `payment-guard.ts`. Surfaces per-plan failure counts (last hour) in `PaymentAttemptsCard`. |
| Detect existing unpaid transactions | ✅ `findPendingForVenue` + resume banner |
| Allow resume vs new | ✅ Resume button on banner |
| Restore payment instructions / reference codes | ✅ Resume navigates to `/result?status=pending&code=…&planId=…&price=…&method=cash` — same pending UI the user saw originally |
| Prevent duplicate pending for same session | ✅ Submit-time `findPendingForVenue` check short-circuits to resume |

## Store dropdown + Done Paying server check — completed

| Spec criterion | Shipped |
|---|---|
| Dummy list of stores in dropdown | ✅ `src/lib/stores.ts` exports STORES (4 entries: Main Counter, Downtown Branch, Airport Kiosk, Lobby Desk). Each has id + name + address. |
| Dropdown rendered on /checkout (cash) | ✅ Native `<select>` with custom chevron + Store icon, h-14 to match other inputs |
| Store selection required for cash | ✅ Submit button disabled when `method === "cash" && !storeId` |
| Selected store displayed on pending screen | ✅ "Selected store: Main Counter · Ground floor · near the entrance" |
| Selected store shown in operator dialog | ✅ Details grid in ConfirmPaymentDialog shows store name + address |
| "Confirm payment" → "Done Paying" | ✅ Button copy + handler renamed |
| Validates back to server | ✅ Mock-server check via findByPaymentReference inside the 600 ms handler. Real backend swap is a single function call. |
| If valid → proceed to next page | ✅ Navigates to `/result?status=success&code=<voucherCode>` with the cashier-issued voucher code |
| If invalid → show error | ✅ 5 specific error states with distinct copy (not found / cancelled / redeemed / expired / not yet confirmed). `role="alert"` for screen readers. |
| Customer cannot self-confirm | ✅ `confirmAndIssueVoucherForReference` no longer imported by `result.tsx` — the only path to confirmation is `/operator`. |

## Dialog-driven pending payment flow — completed

| Spec criterion | Shipped |
|---|---|
| Remove standalone Generate Voucher block from operator workflow | ✅ `/operator` no longer renders `GenerateVoucher`. The component stays in `/admin` for manual walk-in issuance only. |
| Voucher generation only from pending payment transaction flow | ✅ Only path is: queue row → ConfirmPaymentDialog → Confirm and Generate. |
| Step 1: Open Pending Payment from list | ✅ Row tap calls `onSelectPayment(payment)` |
| Displayed info: PAYMENT REFERENCE, plan, amount, store, mobile, status | ✅ Dialog review panel has all six fields. Status shows "Awaiting confirmation" pill. |
| Step 2: Click "Proceed Payment" | ✅ Row button labelled exactly that |
| Step 3: Opens confirmation dialog | ✅ shadcn Dialog primitive |
| Required checkbox: Payment Received | ✅ Custom checkbox with subtext, gates the Confirm button |
| Confirmation button: "Confirm and Generate" | ✅ Exact label, disabled until checkbox ticked |
| 1. Generate voucher code | ✅ `confirmAndIssueVoucherForReference` issues a fresh voucher code (separate from payment reference) |
| 2. Mark payment as successful | ✅ `confirmedAt` set on the record |
| 3. Associate voucher with transaction | ✅ Same record gets the new `code` field populated |
| 4. Update payment status | ✅ Voucher moves from `pending` filter to `sale` filter |
| 5. Trigger realtime captive portal updates | ✅ `storage` event fires; customer's pending tab transitions to /result?status=success automatically |
| 6. Optionally trigger SMS notification | ✅ `sendSmsReceipt` fires fire-and-forget if `payment.phone` is set |
| 7. Log operator processing activity | ✅ `payment_success` analytics event |
| Reuse existing dialog / modal components | ✅ shadcn Dialog primitive (already in `src/components/ui/dialog.tsx`), QrCode component, Button, same icon library |
| Race protection (state changed between open + submit) | ✅ `findByPaymentReference` re-read inside `onConfirm` before issuing voucher; specific error states ("already confirmed", "voided", "expired", "redeemed") |

## Operator tabs (Pending + Sales) — completed

| Spec criterion | Shipped |
|---|---|
| Operator has two tabs: Sales Dashboard + Pending Payments | ✅ Inline pill tab nav. Default to Pending. |
| Pending Payments: list all pending + matching payment reference | ✅ `PendingPaymentsList` shows queue with reference, plan, amount, phone, age, and expiry countdown |
| Each row can be opened to process the payment | ✅ "Process payment" button pre-fills the GenerateVoucher form below + smooth-scrolls into view |
| Generating voucher closes the sale | ✅ On confirmation: queue row disappears, voucher code shown, Sales Dashboard tab's today-stats and recent-sales list update on next refresh |
| Sales Dashboard: own sales from generated voucher | ✅ Today's revenue + count cards + recent-sales VoucherTable. "Own" in mock = all confirmed cash + admin-issued (single-store assumption — per-operator scoping pending #1 auth) |
| Reuse existing components | ✅ VoucherTable, GenerateVoucher reused. New components (`PendingPaymentsList`, `SalesDashboard`) inherit card/button/icon language from existing ones |

## Operator + two-code architecture — completed

| Spec criterion | Shipped |
|---|---|
| Dedicated `/operator` page separate from `/admin` | ✅ `src/routes/operator.tsx`. Scope: voucher generation + recent cash transactions only. No stats, no funnel, no demo controls. |
| Operator NOT allowed: system settings, analytics, financial reports, pricing, user management, full admin modules | ✅ None of those components mounted on `/operator`. Admin keeps them all. |
| Rename "Reference Code" → PAYMENT REFERENCE | ✅ All customer-facing labels (`/result` pending, ResumeBanner, error messages) say "Payment reference". Cashier panel says the same. Spec's literal instruction quote is shown verbatim on the pending screen. |
| PAYMENT REFERENCE ≠ voucher code | ✅ Two distinct strings per cash transaction. `paymentReference` is the cashier lookup ID; `code` is the redemption credential. Both random, independent. |
| PAYMENT REFERENCE never functions as a voucher | ✅ `findVoucher` only matches `code`. Unconfirmed cash records have `code = ""`. Default-valid fallback removed from `validateVoucher`. A customer typing their reference into `/validate` gets "Voucher not found." |
| Spec user-instruction copy | ✅ Pending screen shows "Proceed to the selected store and provide the PAYMENT REFERENCE to the store operator for payment processing." verbatim. |
| Operator workflow: lookup → review → confirm → enabled-Generate → issue | ✅ Live lookup on every keystroke; matched-payment card shows plan + amount + phone; required Payment Received checkbox gates Generate; on Generate a separate voucher code is issued |
| Reuse existing UI patterns | ✅ Same card / button / icon / SMS-chip patterns as the rest of the app. No new modals. |

## Cashier cash workflow — completed

| Spec criterion | Shipped |
|---|---|
| Reference number — optional input | ✅ `GenerateVoucher` has Payment reference number field with paste-from-clipboard button |
| Reference number — manual input | ✅ Free-form input, formatted via `formatVoucherCode()` on every keystroke |
| Reference number — fast lookup | ✅ Live lookup against `findVoucher()` on every change (no debounce — localStorage reads are cheap) |
| Reference number — validate existing pending transaction | ✅ Lookup checks: not voided, not already confirmed, not redeemed, not expired, must be `CASH-` |
| Reference number — prevent duplicate processing | ✅ `confirmVoucher()` returns false if voucher's state changed since lookup; race surfaces as inline error |
| Payment Received required checkbox | ✅ Generate button disabled until checkbox ticked. Loud subtext explains the operational purpose. |
| Voucher generation locked behind checkbox | ✅ `canGenerate = paymentReceived && (refIsEmpty \|\| linkedMode)` |
| Linked mode — confirm pending instead of new | ✅ When linked, `confirmVoucher()` is called instead of `issueVoucher()`. No duplicate voucher created. |
| Linked mode — update portal session | ✅ `confirmedAt` set in localStorage. Customer's tab picks it up via `storage` event (or 3 s poll). |
| Linked mode — sync voucher status | ✅ Customer pending screen flips to "Payment Processing" → "/result?status=success" automatically |
| Linked mode — trigger SMS | ✅ `sendSmsReceipt()` fires fire-and-forget if `matched.phone` is set |
| Standalone mode — manual voucher | ✅ When reference field is blank: free plan picker + `issueVoucher()` (existing behavior) |
| Plan auto-selected when linked | ✅ Plan locks to `matched.planId`; other tiles are visibly disabled |
| Captive portal real-time update — Pending Payment | ✅ Existing pending screen with reference + amount + plan |
| Captive portal real-time update — Payment Processing | ✅ New transient state shown when `storage` event fires (cashier confirmed). Loader2 spinner, "Activating your voucher…" copy, 800 ms before navigation |
| Captive portal real-time update — Payment Successful | ✅ Auto-navigation to `/result?status=success` after the Processing beat |
| Captive portal real-time update — SMS Notification Sent | ✅ Success-side SMS confirmation chip already exists (Sending… → Sent ✓) |
| Realtime sync between admin + portal | ✅ within the same browser (storage event + poll). ❌ across devices — needs backend (websocket / SSE) |
| Reuse existing UI patterns | ✅ Card layout, button styles, status pills, QR component, SMS chip — all reused. No new modal patterns introduced. |
| Risk: voucher generation without payment confirmation | ✅ Checkbox-required gate |
| Risk: duplicate voucher generation | ✅ Linked mode confirms existing voucher; doesn't create new. Race detection on `confirmVoucher()` return. |
| Risk: broken transaction synchronization | ⚠️ Within same browser, robust. Cross-device requires backend. |
| Risk: stale pending portal sessions | ✅ TTL purge (15 min default) + storage-event sync |

Admin observability for the above: `PaymentAttemptsCard` on `/admin`
surfaces failed-attempt counts (last hour / last 24 h), a per-plan
breakdown for the last hour (uses `getAttemptCountSince`), and lists any
(venue, planId) combos currently in lockout with remaining-ms countdown.
Reset Everything wipes the strike records along with the voucher store
and event log.

## Mobile / browser compatibility — verified

| Concern | Mitigation in place |
|---|---|
| iOS Safari input zoom on focus | `font-size: 16px` floor on `input/select/textarea` in `styles.css` |
| iOS Safari variable viewport (toolbar) | `min-h-dvh` everywhere (not `min-h-screen`) |
| Safe areas (notch / home indicator) | `.safe-*` utilities backed by `env(safe-area-inset-*)`, with `viewport-fit=cover` meta |
| Safari flexbox truncation bugs | `min-w-0` on every flex child with truncating text; `min-h-0` on column scrollers |
| Horizontal overflow | `overflow-x: hidden` on body + Playwright assert at 320 / 375 / 768 px |
| Touch targets | Global `min-height: 44 px` on every interactive element |
| Modal / dropdown rendering edge cases | No modals or dropdowns in the customer flow currently |
| Keyboard overlay (mobile) | Sticky form on `/` stays above the keyboard; default browser behaviour scrolls focused inputs into view |

## UX polish, a11y, layout, hygiene — completed

- **Paste-from-clipboard button** on `/` next to the voucher input. Uses `navigator.clipboard.readText()`, with a small "couldn't read clipboard" hint on permission denial.
- **Auto-formatted voucher input** — `formatVoucherCode()` from `portal-api.ts` runs on every change, normalising to `XXXX-XXXX-XXXX` as the user types.
- **Share button on `/result`** — Web Share API with the existing Copy button as fallback. Renders only when `navigator.share` is available.
- **Cash flow distinction** — `/checkout` Pay button reads "Get reference code" when method is Cash, phone field is disabled (paper receipt). Submission routes to `/result?status=pending` with a "Pay at counter" + reference QR screen and an "I've paid" button that transitions to `/result?status=success`.
- **QR on `/validate` valid** — parity with `/result` success.
- **Plan info on `/validate` valid** — plan name + duration shown via `PlanDuration` badge.
- **Countdown timer** — `PlanDuration` component shows static "X of WiFi" pre-redemption; ticks live (`Xh Ym left` / `Xm Ys left`) when `redeemedAt` is set.
- **Async `getPlans()` with skeleton** — `/plans` uses `getPlans()` (300ms simulated latency) with 3 animated placeholder tiles during the load.
- **SMS-receipt latency simulation** — `/result` success shows "Sending receipt to…" with a spinner, then flips to "Sent ✓" after 1.4s.
- **First-attempt-fail simulation** — voucher submission and payment both fail on the first attempt per browser tab so testers see both paths.
- **ARIA on step indicator** — `PortalShell` adds `role="progressbar"`, `aria-valuemin`, `aria-valuemax`, `aria-valuenow`, `aria-valuetext`, and hides the decorative pips from screen readers.
- **Contrast sweep** — every `text-foreground/60..80` reference replaced with `text-muted-foreground` (the proper token).
- **Playwright vertical-fit assertion** — `portal.spec.ts` now asserts `scrollHeight ≤ innerHeight + 12 px` in addition to the horizontal check, and exercises `/admin` and `/result?status=pending`. `beforeEach` pre-sets the first-attempt flags for deterministic runs.
- **Hygiene decision** — `src/lib/api/example.functions.ts` and `src/lib/config.server.ts` retained as scaffolding (well-commented templates for milestone #1's `createServerFn` work, not dead code).

## Suggested order if you want to start moving

1. **Decide milestone #1's stack** (Lovable Cloud vs. plain Supabase vs. self-hosted Postgres). Everything labelled "Blocked on #1" unblocks the moment the DB exists.
2. **Quick wins that don't depend on backend** (~1 hour total):
   - Milestone #5: unify the step indicator.
   - Milestone #2: drop a QR component on `/result` — pure client work, just needs a small library or inline SVG renderer.
   - Branding boilerplate: replace "Lovable App" / "SkyNet" with a single `BRAND` constant pulled from one source.
   - Add `@playwright/test` to devDependencies so the overflow test runs in CI.
3. **Resolve the phone-in-URL ambiguity** before #1 ships — if the answer is "no PII in URLs ever," migrate `/result` state from `useSearch` to router state or session storage.
