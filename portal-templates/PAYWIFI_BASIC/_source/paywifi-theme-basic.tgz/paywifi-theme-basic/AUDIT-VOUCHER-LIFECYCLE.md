# PayWiFi — Voucher Lifecycle & Payment Flow Audit

**Date:** 2026-05-28  
**Scope:** All customer-facing and operator-facing voucher flows  
**Status:** Draft — pending implementation

---

## Table of Contents

1. [Flow Overview](#1-flow-overview)
2. [Flow A — Digital Payments](#2-flow-a--digital-payments-gcash--qr-ph--maya)
3. [Flow B — Cash at Counter](#3-flow-b--cash-at-counter)
4. [Flow C — Admin Manual Issue](#4-flow-c--admin-manual-issue)
5. [Flow D — Voucher Validation & Redemption](#5-flow-d--voucher-validation--redemption)
6. [State Machine Reference](#6-state-machine-reference)
7. [Bugs — Breaking Issues](#7-bugs--breaking-issues)
8. [Gaps — Degraded Experience](#8-gaps--degraded-experience)
9. [UX Issues — Layout & Clarity](#9-ux-issues--layout--clarity)
10. [Action Items](#10-action-items)
11. [Recommendations](#11-recommendations)

---

## 1. Flow Overview

The system implements four distinct voucher lifecycle paths:

| Flow | Entry | Exit | Key Risk |
|------|-------|------|----------|
| A — Digital | `/checkout` (GCash/QR PH/Maya) | `/result?success` | 3-strike lockout, no phone field |
| B — Cash | `/checkout` → operator confirms | `/result?success` (auto-navigate) | 15-min expiry, no countdown |
| C — Admin manual | `/admin` GenerateVoucher | Code shown inline | Credit check only |
| D — Validate | `/` enter code → `/validate` | Start browsing | No plan details shown |

All vouchers share a common localStorage store (`paywifi:vouchers:v2`). The cash path uses a two-code architecture: a **payment reference** (for the cashier) and a **voucher code** (for WiFi redemption) — these are intentionally different strings.

---

## 2. Flow A — Digital Payments (GCash / QR PH / Maya)

```
/ (home)
  └─► /plans         (pick plan)
        └─► /checkout (select method, optional phone for cash only)
              ├─► processPayment()
              │     ├─ 90% success: addVoucher + recordPendingDigital (5-min TTL)
              │     └─ 10% / 3-strike fail → recordFailedAttempt
              │
              ├─► SUCCESS → /result?status=success&code=...
              │     └─ clearPendingDigitalPayment(transactionId)
              │     └─ sendSmsReceipt() if phone present
              │     └─ "Start browsing" → redeemVoucher(code)
              │
              └─► FAIL → /result?status=failed&message=...
                    └─ "Try again" → /checkout?plan=X
                    └─ 3-strike lockout: auto-switch to cash on checkout
```

**Abuse protection:** 3 digital failures on the same venue+plan triggers a lockout (duration configurable). Cash is never locked out. Lock clears on any successful payment.

---

## 3. Flow B — Cash at Counter

```
/checkout (method=cash)
  └─► Store picker (required)
  └─► Phone field (optional, for SMS receipt)
  └─► processPayment()
        └─ generatePaymentReference() → 6-digit zero-padded
        └─ addVoucher({ code: "", paymentReference, expiresAt: now+15min })
        └─► /result?status=pending
              │
              ├─ Display: amount due, store location, QR of ref#, phone edit
              ├─ Poll every 3s + storage event listener for confirmedAt
              ├─ "I've paid" → manual check → navigate to success if confirmed
              └─ Cancel → voidVoucher → /plans
              │
              └─► Operator (/operator) sees pending in queue
                    └─ ConfirmPaymentDialog
                          ├─ "Payment received" checkbox
                          ├─ confirmAndIssueVoucherForReference()
                          │     ├─ Credit check (deductCredits)
                          │     ├─ generateVoucherCode()
                          │     └─ store.confirmAndIssueVoucher() → sets code + confirmedAt
                          ├─ sendSmsReceipt() if phone
                          └─ Customer poll detects confirmedAt → navigates to success
```

**15-minute TTL:** Payment reference expires if operator does not confirm in time. Operator queue filters out expired references.

---

## 4. Flow C — Admin Manual Issue

```
/admin → GenerateVoucher form
  └─► Select plan
  └─► issueVoucher(planId)
        ├─ Credit check: balance >= plan.price
        │     ├─ FAIL → { ok: false, reason: "insufficient_credits", balance, required }
        │     └─ OK  → deductCredits + generateVoucherCode + addVoucher(transactionId: "ADMIN-...")
        └─► Show issued code inline (no navigation)
```

Admin-issued vouchers are identified by `transactionId.startsWith("ADMIN-")` and appear in the sales dashboard.

---

## 5. Flow D — Voucher Validation & Redemption

```
/ (home) → enter code → /validate?code=XXXX-XXXX-XXXX
  └─► validateVoucher(code)
        ├─ consumeFirstAttempt() — first-fail simulation if flag set
        ├─ findVoucher(code) lookup
        │     ├─ voidedAt        → "This reference was cancelled"
        │     ├─ expiresAt+!redeemedAt+expired → "Payment reference expired"
        │     ├─ CASH-transactionId+!confirmedAt → "Pending verification"
        │     ├─ redeemedAt+within duration → "Already used — time remaining"
        │     ├─ redeemedAt+expired → "Time has run out"
        │     └─ OK → { ok: true }
        └─► Valid → success screen → "Start browsing"
              └─ redeemVoucher(code) → sets redeemedAt: now()
              └─ external redirect (google.com in demo)
```

**Note:** The `paymentReference` field is NOT searchable via `findVoucher()`. Unconfirmed cash records have `code: ""` — the lookup correctly misses them, preventing premature redemption.

---

## 6. State Machine Reference

### Voucher States

| State | `code` | `confirmedAt` | `redeemedAt` | `voidedAt` | `expiresAt` |
|-------|--------|---------------|--------------|------------|-------------|
| Cash pending | `""` | — | — | — | now+15min |
| Cash confirmed | `"XXXX-..."` | set | — | — | — |
| Digital issued | `"XXXX-..."` | — | — | — | — |
| Redeemed (active) | `"XXXX-..."` | — | set | — | — |
| Redeemed (expired) | `"XXXX-..."` | — | set | — | redeemedAt+duration |
| Voided | any | — | — | set | — |

### Payment Reference TTL

- **Generated:** `expiresAt = Date.now() + 15 * 60 * 1000`
- **Confirmed:** `confirmedAt` written, expiry becomes irrelevant
- **Expired (unconfirmed):** treated as invalid by operator queue filter and validate route

---

## 7. Bugs — Breaking Issues

### BUG-01 — Cash expiry: no customer recovery path

**Severity:** High  
**File:** `src/routes/result.tsx` — `PendingView`, `onCheckPayment()`

**Problem:** When a 15-minute payment reference expires, `onCheckPayment()` shows an error message but the only exit is "Cancel this payment" which calls `voidVoucher()` and navigates to `/plans`. The customer must pick their plan from scratch.

**Impact:** Any customer who waits more than 15 minutes (slow queue, distracted) loses their session entirely with no shortcut back.

**Fix:**
```tsx
// In onCheckPayment(), on expiry detection:
if (stored.expiresAt && !stored.confirmedAt && Date.now() >= stored.expiresAt) {
  if (paymentReference) voidVoucher(paymentReference);
  navigate({ to: "/checkout", search: { plan: planId ?? "" } }); // ← skip re-picking plan
  return;
}
```
Also wire the cancel button to do the same when expiry is detected.

---

### BUG-02 — Insufficient credits: silent failure in operator confirm dialog

**Severity:** High  
**File:** `src/lib/portal-api.ts` — `confirmAndIssueVoucherForReference()`, `src/components/operator/ConfirmPaymentDialog.tsx`

**Problem:** `confirmAndIssueVoucherForReference()` returns `null` on credit shortage. The dialog shows "Could not generate voucher — state changed. Try again." — the operator has no idea they are out of credits and will retry indefinitely.

**Impact:** Operator cannot serve the customer. Customer waits at the counter while operator retries a broken flow.

**Fix:** Change return type to a union:
```ts
// portal-api.ts
type ConfirmResult =
  | { ok: true; code: string }
  | { ok: false; reason: "insufficient_credits"; balance: number; required: number }
  | { ok: false; reason: "not_found" | "already_confirmed" | "expired" };

export function confirmAndIssueVoucherForReference(ref: string): ConfirmResult { ... }
```
Then in `ConfirmPaymentDialog`:
```tsx
if (!result.ok && result.reason === "insufficient_credits") {
  return fail(`Insufficient credits (balance: ${result.balance} cr, need: ${result.required} cr). Reload credits in the Credits tab.`);
}
```

---

## 8. Gaps — Degraded Experience

### GAP-03 — No expiry countdown on the pending screen

**Severity:** Medium  
**File:** `src/routes/result.tsx` — `PendingView`

**Problem:** The customer sitting at the counter has no indication that their payment reference expires in 15 minutes. `PendingPaymentGate` shows a countdown ("expires in Xm") but the actual `/result?pending` screen does not.

**Fix:** Add a live countdown component below the payment reference:
```tsx
// Show: "Reference expires in 8:42" — turns red at ≤2 minutes
// On expiry: auto-show inline error + "Rebook same plan" button
```
Use `expiresAt` from `findByPaymentReference(paymentReference)` (re-read on mount).

---

### GAP-04 — No phone field for digital payments

**Severity:** Medium  
**File:** `src/routes/checkout.tsx`

**Problem:** The phone/mobile field only renders when `method === "cash"`. Digital payments (GCash, QR PH, Maya) also call `sendSmsReceipt()` but `phone` is always `undefined`, so the SMS never fires.

**Impact:** Customers paying digitally never receive an SMS receipt, even though the infrastructure supports it.

**Fix:** Move the phone field above the payment method selector, visible for all methods:
```tsx
// Optional for all methods — not required for form submission
{/* Phone for SMS receipt — all methods */}
<label>Mobile number (optional — for SMS receipt)</label>
<Input type="tel" value={phone} onChange={...} placeholder="09xxxxxxxxx" />
```

---

### GAP-05 — Validate screen shows no plan details on success

**Severity:** Medium  
**File:** `src/routes/validate.tsx`

**Problem:** After entering a voucher code, the success state confirms "Valid!" but shows no plan name, duration, or time remaining. The customer cannot verify what they paid for.

**Fix:** After `validateVoucher()` returns `ok: true`, look up the voucher record and plan:
```tsx
const voucher = findVoucher(code);
const plan = voucher ? getPlan(voucher.planId) : undefined;
const timeRemaining = voucher?.redeemedAt
  ? Math.max(0, voucher.redeemedAt + voucher.durationMinutes * 60_000 - Date.now())
  : null;
```
Show a plan card (name, duration, speed) and a time-remaining badge.

---

### GAP-06 — SuccessView: QR code takes priority over readable voucher code

**Severity:** Medium  
**File:** `src/routes/result.tsx` — `SuccessView`

**Problem:** The customer success screen shows a 120×120px QR code above the voucher code text (`text-lg`, below the QR). WiFi captive portals almost never scan a QR from a customer's phone screen — the code is typed. The QR wastes prime vertical space and pushes the readable code below the fold on small screens.

**Fix:** Promote the voucher code to hero:
```tsx
<p className="font-mono font-black text-4xl tracking-[0.2em]">{code}</p>
// QR behind a toggle:
<button onClick={() => setShowQr(v => !v)}>Show QR code</button>
{showQr && <QrCode value={code} size={120} />}
```

---

### GAP-07 — Digital pending resume in PendingPaymentGate lacks code field guard

**Severity:** Low  
**File:** `src/components/PendingPaymentGate.tsx` — `onResume` for digital kind

**Problem:** When a digital pending record is found, resume navigates to `status=success` without confirming `record.code` is populated. In current implementation the code is always set for digital records, but the guard is absent.

**Fix:** Add an assertion before navigating:
```tsx
if (!r.code) {
  // Payment still processing — clear stale record and let through
  clearPendingDigitalPayment(r.transactionId);
  onClear();
  return;
}
navigate({ to: "/result", search: { status: "success", code: r.code, ... } });
```

---

## 9. UX Issues — Layout & Clarity

### UX-08 — Pending screen overflows on small phones (iPhone SE / 375×667)

**Severity:** Medium  
**File:** `src/routes/result.tsx` — `PendingView`

**Problem:** The pending screen stacks: amount hero + store card + QR card + phone edit card + footer CTA buttons. On a 667px-tall screen (iPhone SE, many Android budget phones), the "I've paid" CTA is below the fold. The most important action is invisible without scrolling.

**Fix:**
- Reduce QR size: 108px → 80px, remove border padding
- Collapse phone edit row to a single compact line (edit icon only, expand inline on tap)
- Footer in `PortalShell` is already `shrink-0` — confirm it is sticky relative to the scroll container, not the page
- Consider merging store card and QR card into one card (store name + ref# + QR in one block)

---

### UX-09 — Failed view: three equal-weight buttons create decision paralysis

**Severity:** Low  
**File:** `src/routes/result.tsx` — `FailedView`

**Problem:** Three stacked buttons of similar visual weight: "Try again" (primary), "Choose a different plan" (secondary), "Back to portal home" (secondary). The last two overlap in purpose and create unnecessary choice.

**Current:**
```
[Try again]                    ← h-16 primary
[Choose a different plan]      ← h-12 secondary
[Back to portal home]          ← h-11 secondary muted
```

**Fix:**
```
[Try again]                    ← h-16 primary (link to /checkout?plan=X)
[Choose a different plan →]    ← text link, no button chrome
[Back to portal ↗]             ← ghost/muted, smallest
```

---

### UX-10 — Plans page has no "already connected" indicator

**Severity:** Low  
**File:** `src/routes/plans.tsx`

**Problem:** A customer with an active voucher session can navigate to `/plans` and accidentally purchase again. `PendingPaymentGate` only intercepts unpaid pending payments — not active redeemed sessions.

**Fix:** On `/plans` mount, check `getActiveSessions()` filtered by venue. If an active session exists, show a non-blocking banner:
```
✓ You're currently connected — 1h 23m remaining on [Plan Name]
  [Buy another anyway]
```
This requires passing the venue slug to the plans page (already available via `useBrand()`).

---

## 10. Action Items

### Priority 1 — Fix immediately (breaking bugs)

| # | Item | File(s) | Effort |
|---|------|---------|--------|
| A1 | Fix cash expiry recovery: navigate to `/checkout?plan=X` instead of `/plans` | `result.tsx` | S |
| A2 | Fix operator credit shortage: typed return from `confirmAndIssueVoucherForReference()` + actionable error in dialog | `portal-api.ts`, `ConfirmPaymentDialog.tsx` | M |

### Priority 2 — High-impact UX (degraded but not blocking)

| # | Item | File(s) | Effort |
|---|------|---------|--------|
| B1 | Add live expiry countdown to pending screen; auto-rebook CTA on expiry | `result.tsx` | M |
| B2 | Add optional phone field for digital payment methods at checkout | `checkout.tsx` | S |
| B3 | Promote voucher code to hero on success screen; QR behind toggle | `result.tsx` | S |
| B4 | Reduce pending screen height: smaller QR, compact phone row, merged cards | `result.tsx` | S |

### Priority 3 — Polish (good to have)

| # | Item | File(s) | Effort |
|---|------|---------|--------|
| C1 | Show plan details + time remaining on validate success screen | `validate.tsx` | S |
| C2 | Add code field guard to digital pending resume in PendingPaymentGate | `PendingPaymentGate.tsx` | XS |
| C3 | Simplify failed view buttons: one primary, one text link, one ghost | `result.tsx` | XS |
| C4 | Add "already connected" banner on plans page for active sessions | `plans.tsx` | M |

**Effort key:** XS < 30 min · S < 2 hrs · M < 4 hrs · L < 1 day

---

## 11. Recommendations

### R1 — Extend the cash payment reference TTL or make it configurable

15 minutes is aggressive for a walk-to-counter flow, especially in busy venues or when the operator is handling other customers. Consider:
- Default TTL of 30 minutes
- Admin-configurable per venue
- Display the TTL prominently on the pending screen from the start

### R2 — Add a "resend SMS" button on the success screen

If the SMS receipt failed or the customer gave the wrong number, there is no recovery. A "Resend to different number" option on the success screen — rate-limited to once — would significantly reduce support requests.

### R3 — Centralise the `confirmAndIssueVoucherForReference` return type

The function currently returns `string | null`. This pattern has already caused one silent bug (credit shortage). Adopt the same `{ ok: true; ... } | { ok: false; reason: string; ... }` pattern used by `issueVoucher()` and `processPayment()` for consistency and future-proofing.

### R4 — Introduce a voucher "preview" state before checkout completes

Currently the customer only sees the amount after payment. Consider a one-screen summary ("You're buying: Plan X · ₱XX · 24hrs — Pay with GCash") before the payment fires, matching native e-commerce UX patterns and reducing accidental purchases.

### R5 — Persist venue slug on the pending screen URL

The pending screen at `/result?status=pending` does not carry the venue slug. If the user refreshes or is redirected from `PendingPaymentGate`, the `useBrand()` hook falls back to `sessionStorage`, which may differ on a new browser tab. Pass `venue` as a search param through the cash flow.

### R6 — Rate-limit the "I've paid" check button

`onCheckPayment()` has an `inFlightRef` guard for concurrent clicks but no cooldown between successful calls. An impatient customer can spam the button. Add a 5-second cooldown between checks with a visible countdown.

### R7 — Operator credit shortage alert on dashboard load

Rather than discovering the credit shortage mid-confirmation, surface a proactive warning on the operator dashboard: "Low credits — X remaining. Reload now to avoid interruptions." The threshold already exists (`balance < 50` shows the `!` badge) — add a blocking banner at `balance < 10`.

### R8 — Partner / operator registration (planned feature)

The current store list (`src/lib/stores.ts`) is hardcoded. The planned partner registration feature should:
1. Write approved registrations to a `paywifi:partner-stores:v1` localStorage key (mock)
2. Merge dynamic stores with static `STORES` in `getStore()` and the checkout dropdown
3. Gate appearance in the dropdown on `status === "approved"`
4. Provide an admin UI to approve/reject pending registrations

---

*Generated by lifecycle audit — 2026-05-28. All file references relative to `src/`.*
